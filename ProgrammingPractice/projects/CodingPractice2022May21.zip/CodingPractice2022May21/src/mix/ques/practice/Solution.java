package mix.ques.practice;

class Solution {
	
	public static void main(String[] args) {
		int[] arr = {2,0,6,6};
		String res = largestTimeFromDigits(arr);
		System.out.println("RES:"+res);
	}
    public static String largestTimeFromDigits(int[] arr) {
        int len = arr.length;
        int st1 =-1;
        int st2 = -1;
        int hour =-1;
        for(int i=0; i<len ; i++){
            for(int j=i+1 ;j<len;j++){
                int num1 = Integer.valueOf(arr[i]+""+arr[j]);
                int num2 = Integer.valueOf(arr[j]+""+arr[i]);
                System.out.println(num1+"   "+num2+"   "+hour);
                if(num1<=23 && num2<=23){
                    if(hour<num1 && hour<num2){
                        if(num1>num2){
                            hour = num1;
                        }else{
                            hour = num2;
                        }
                        st1 = i;
                        st2 = j; 
                    }else if(hour < num1){
                        hour = num1 ;
                        st1 = i;
                        st2 = j; 
                    }else if(hour<num2){
                        hour = num2;
                        st1 = i;
                        st2 = j; 
                    }
                }else if(num1<=23 && num2>23){
                    if(hour<num1){
                        hour = num1;
                        st1 = i;
                        st2 = j;    
                    }
                }else if(num1>23 && num2<=23){
                    if(hour<num2){
                        hour = num2;
                        st1 = i;
                        st2 = j;    
                    }
                }
            }
        }
        
        if(hour==-1) return "";
        
        System.out.println("hour:-"+hour);
        int min1 = -1;
        int min2 = -1;
        int minutes = -1;
         for(int i=0; i<len ; i++){
             if(i!=st1 && i !=st2){
                 if(min1 == -1){
                     min1 =i;
                 }else{
                     min2 =i;
                 }
             }
         }
        
                int num1 = Integer.valueOf(arr[min1]+""+arr[min2]);
                int num2 = Integer.valueOf(arr[min2]+""+arr[min1]);
                if(num1<=59 && num2<=59){
                    if(minutes<num1 && minutes<num2){
                        if(num1>num2){
                            minutes = num1;
                        }else{
                            minutes = num2;
                        }
                    }else if(minutes < num1){
                        minutes = num1 ;
                       
                    }else if(minutes<num2){
                        minutes = num2;
                    }
                }else if(num1<=59){
                    if(minutes<num1){
                        minutes = num1;
                    }
                }else if(num2<=59){
                    if(minutes<num2){
                        minutes = num2;
                    }
                }
                
                
                System.out.println(hour +"  aaa "+minutes );
        if(minutes==-1) return "";
        
        
        String hourres = (hour==0)?"00":hour+"" ;
        
        hourres = (hourres.length()==1) ? "0"+hourres :hourres;
        
        String minres = (minutes==0)?"00":minutes+"" ;
        
        minres = (minres.length()==1)?"0"+minres:minres;
        return hourres+":"+minres;
    }
}