package gfg.heap;

/**
 * 
 * https://www.geeksforgeeks.org/why-is-binary-heap-preferred-over-bst-for-priority-queue/
 * https://www.geeksforgeeks.org/binomial-heap-2/
 * https://www.geeksforgeeks.org/fibonacci-heap-set-1-introduction/
 * 
 * Array = {1, 3, 5, 4, 6, 13, 10, 9, 8, 15, 17}

Corresponding Complete Binary Tree is:
                 1
              /     \
            3         5
         /    \     /  \
        4      6   13  10
       / \    / \
      9   8  15 17
      
https://www.geeksforgeeks.org/building-heap-from-array/

 * @author rajeevkumar.pal
 *
 */
public class BuildMaxHeapFromArr {

	public static void main(String[] args) {
		// Binary Tree Representation
        // of input array
        //            1
        //         /      \
        //       3        5
        //     /   \       / \
        //  4       6  13 10
        // / \    /  \
        // 9  8  15   17
        int arr[] = { 1, 3, 5, 4, 6, 13, 10, 9, 8, 15, 17 };
  
        int n = arr.length;
  
        buildHeap(arr, n);
  
        printHeap(arr, n);
        
        sortHeap(arr,n);
        
        printHeap(arr, n);
	}

	private static void sortHeap(int[] arr, int n) {
		// TODO Auto-generated method stub
		System.out.println("Heap created !");
		for(int i=n-1;i > 0;i--){
			int  lastnum =arr[i];
			arr[i] = arr[0];
			arr[0] = lastnum ;
			heapify(arr ,0 ,i); 
		}
	}

	private static void buildHeap(int[] arr, int n) {
		int i= (n/2) -1 ;
		
		for(;i>=0;i--) {
			heapify(arr,i, n);
		}
		
	}
	
	private static void heapify(int[] arr,int i ,int n) {
		int left = 2*i + 1;
		int right = 2*i + 2;
		int largest =i;
		
		if(right < n && arr[largest] < arr[right]) {
			largest = right;
		}
		
		if(left < n && arr[largest] < arr[left]) {
			largest = left;
		}
		
		if(largest!=i) {
			int  temp = arr[i];
			arr[i] = arr[largest];
			arr[largest] = temp;
			
			heapify(arr, largest, n);
		}
		
	}
	
	
	private static void printHeap(int[] arr, int n) {
		// TODO Auto-generated method stub
		 System.out.println("Array representation of Heap is:");
		  
		 for (int i = 0; i < n; ++i)
		      System.out.print(arr[i] + " ");
		  
		        System.out.println();
	}
}
// kth largest element use priorityqueue .
