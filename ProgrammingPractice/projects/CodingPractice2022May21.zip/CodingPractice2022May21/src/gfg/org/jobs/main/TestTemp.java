package org.jobs.main;

import java.util.ArrayList;
import java.util.List;

import org.jobs.CalcLowestCostFcsSetThatsFulfulsOrderItemsBySplitingItemAndQuantity;
import org.model.FCQuantitySplitSubsetDto;
import org.model.FullfilmentCenter;
import org.model.Item;

public class TestTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long x =System.currentTimeMillis();  
		
		Item item1 = new Item("a", 1);
		Item item2 = new Item("b", 18);
		Item item3 = new Item("c", 3);
		Item item4 = new Item("d", 1);
		List<Item> items = new ArrayList<>();
		items.add(item1);
		items.add(item2);
		items.add(item3);
		items.add(item4);
		
		
		Item item12 = new Item("a", 100);
		Item item13 = new Item("b", 1);
		Item item14 = new Item("e", 20);
		List<Item> items1 = new ArrayList<>();
		items1.add(item12);
		items1.add(item13);
		items1.add(item14);
		FullfilmentCenter fc1 = new FullfilmentCenter(1234,5 ,items1);
		
		Item item15 = new Item("a", 80);
		Item item16 = new Item("b", 10);
		Item item17 = new Item("f", 50);
		List<Item> items2 = new ArrayList<>();
		items2.add(item15);
		items2.add(item16);
		items2.add(item17);
		FullfilmentCenter fc2 = new FullfilmentCenter(1235,10 ,items2);
		
		
		Item item18 = new Item("b", 7);
		Item item19 = new Item("c", 3);
		List<Item> items3 = new ArrayList<>();
		items3.add(item18);
		items3.add(item19);
		FullfilmentCenter fc3 = new FullfilmentCenter(1236,15 ,items3);
		
		
		Item item21 = new Item("a", 10);
		Item item22 = new Item("b", 5);
		Item item23 = new Item("c", 2);
		Item item24 = new Item("d", 1);
		List<Item> items4 = new ArrayList<>();
		items4.add(item21);
		items4.add(item22);
		items4.add(item23);
		items4.add(item24);
		FullfilmentCenter fc4 = new FullfilmentCenter(1237,20 ,items4);
		
		
		Item item25 = new Item("g", 100);
		List<Item> items5 = new ArrayList<>();
		items5.add(item25);
		FullfilmentCenter fc5 = new FullfilmentCenter(1238,4 ,items5);
		
		
		
		Item item26 = new Item("c", 10);
		Item item27 = new Item("j", 110);
		Item item28 = new Item("g", 40);
		Item item29 = new Item("d", 40);
		Item item30 = new Item("a", 10);
		Item item31 = new Item("b", 10);
		List<Item> items6 = new ArrayList<>();
		items6.add(item26);
		items6.add(item27);
		items6.add(item28);
		items6.add(item29);
		items6.add(item30);
		items6.add(item31);
		FullfilmentCenter fc6 = new FullfilmentCenter(1239,30 ,items6);
		
		
		FullfilmentCenter[] fcs = new FullfilmentCenter[6];
		fcs[0] = fc1;
		fcs[1] = fc2;
		fcs[2] = fc3;
		fcs[3] = fc4;
		fcs[4] = fc5;
		fcs[5] = fc6;
		
		FCQuantitySplitSubsetDto result = CalcLowestCostFcsSetThatsFulfulsOrderItemsBySplitingItemAndQuantity.findFcsSet(items, fcs);
		
		System.out.println("Result :- "+result.toString());
	
		long y =System.currentTimeMillis();
		
		System.out.println("Time taken -:"+(y-x));
	
		for(int i=0;i < fcs.length;i++) {
			
			for(int j=i;j>=0;j--) {
				
			}
		}
	
	
	
		
		
	}

}
