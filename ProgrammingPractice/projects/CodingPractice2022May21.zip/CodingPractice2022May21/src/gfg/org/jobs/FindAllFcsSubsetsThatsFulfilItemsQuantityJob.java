package org.jobs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.Callable;

import org.model.FCQuantitySplitSubsetDto;
import org.model.FullfilmentCenter;
import org.model.Item;


public class FindAllFcsSubsetsThatsFulfilItemsQuantityJob implements Callable<Map<String ,TreeSet<FCQuantitySplitSubsetDto>>>{

	private FullfilmentCenter[] fcs=null;
	List<Item> items=null;
	int fcSize =0;
	static Map<Integer , Integer> FCsMap=null;
	public FindAllFcsSubsetsThatsFulfilItemsQuantityJob(FullfilmentCenter[] fcs , int fcSize , List<Item> items, Map<Integer , Integer> FCsMap) {
		this.fcs = fcs;
		this.fcSize = fcSize;
		this.items = items;
		this.FCsMap=FCsMap;
	}
	
	@Override
	public Map<String, TreeSet<FCQuantitySplitSubsetDto>> call() throws Exception {
		
		Map<String ,TreeSet<FCQuantitySplitSubsetDto>> eachItemsFcsSubset = new HashMap<>();
		
		for(Item it:items) {
			int itemqty = it.getQuantity();
			String itemId = it.getItemId();
			FCQuantitySplitSubsetDto fcSubSetList = new FCQuantitySplitSubsetDto();
			
			TreeSet<FCQuantitySplitSubsetDto> resFcSubsetGroup  = new TreeSet<>();
			findFcHasEqualGivenItemQty1(fcs, fcs.length , it ,fcSubSetList , itemqty , resFcSubsetGroup);
			System.out.println(resFcSubsetGroup + " , item id : "+itemId+" , item Quantity : "+itemqty); 
			//System.out.println();
			
			eachItemsFcsSubset.put(itemId, resFcSubsetGroup);
		}
		
		return eachItemsFcsSubset;
	}
	
	private static void findFcHasEqualGivenItemQty(FullfilmentCenter[] fcs ,int n ,Item it, FCQuantitySplitSubsetDto fcSubSetList , int itemqty ,TreeSet<FCQuantitySplitSubsetDto> resFcSubsetGroup ) {
	    System.out.println("findFcHasEqualGivenItemQty----------recursion n-"+n+" :item: "+it+" itemqty "+itemqty+"  "+fcSubSetList);
		if (itemqty == 0) {
	    	resFcSubsetGroup.add(fcSubSetList);
	        return;
	    }
	    if (n == 0)
	        return;
		
	    findFcHasEqualGivenItemQty(fcs, n-1,it ,fcSubSetList, itemqty ,resFcSubsetGroup);

	    FCQuantitySplitSubsetDto dto =new FCQuantitySplitSubsetDto(fcSubSetList);
	    boolean flag = false;
	    int qty = 0;
		FullfilmentCenter	ffcenter = fcs[n-1] ;
		List<Item> itemlist =ffcenter.getItems();
		// redue to logn
		
		for(Item item : itemlist) {
			  if(item.getItemId().equals(it.getItemId())) {
			    	qty = item.getQuantity();
			    	flag = true;
			    	break;
			  }
		}
		if(flag) {
			dto.getFcIdSet().add(ffcenter.getFcId());
			dto.setTotalDistance(dto.getTotalDistance()+FCsMap.get(ffcenter.getFcId()));
		}
	    int resQty = (itemqty - qty)<0 ?0:(itemqty - qty) ;
	  
		
	   findFcHasEqualGivenItemQty(fcs, n-1 , it,dto,resQty ,resFcSubsetGroup);
	   System.out.println("after calc");
	   
	}
	
	
	// dp[i][j] is going to store true if sum j is
		// possible with array elements from 0 to i.
		static boolean[][] dp;
		
		static void display(ArrayList<Integer> v)
		{
		System.out.println(v);
		}
		
		// A recursive function to print all subsets with the
		// help of dp[][]. Vector p[] stores current subset.
		//static void printSubsetsRec(int arr[], int i, int sum,
		//ArrayList<Integer> p)
		
		public static void getSubsetRecursive(FullfilmentCenter[] fcs ,int i ,Item it, FCQuantitySplitSubsetDto fcSubSetList , int itemqty ,TreeSet<FCQuantitySplitSubsetDto> resFcSubsetGroup)
		{
	        if(itemqty==0){
	        	resFcSubsetGroup.add(new FCQuantitySplitSubsetDto(fcSubSetList));
	        	fcSubSetList.getFcIdSet().clear();
				fcSubSetList.setTotalDistance(0);
				return;
	        }
	        
			if (i == 0 && itemqty != 0 && dp[0][itemqty]){
				FullfilmentCenter	ffcenter = fcs[i] ;
				fcSubSetList.getFcIdSet().add(ffcenter.getFcId());
				fcSubSetList.setTotalDistance(fcSubSetList.getTotalDistance()+FCsMap.get(ffcenter.getFcId()));
				resFcSubsetGroup.add(new FCQuantitySplitSubsetDto(fcSubSetList));
				fcSubSetList.getFcIdSet().clear();
				fcSubSetList.setTotalDistance(0);
				return;
			}
		
			if (dp[i-1][itemqty]){
				FCQuantitySplitSubsetDto b = new FCQuantitySplitSubsetDto(fcSubSetList);
				getSubsetRecursive(fcs, i-1,it,b ,itemqty, resFcSubsetGroup);
			}
			
			if (itemqty >= FCsMap.get(fcs[i].getFcId()) && dp[i-1][itemqty-FCsMap.get(fcs[i].getFcId())]){
				fcSubSetList.getFcIdSet().add(fcs[i].getFcId());
				fcSubSetList.setTotalDistance(fcSubSetList.getTotalDistance()+FCsMap.get(fcs[i].getFcId()));
				
				getSubsetRecursive(fcs, i-1,it,fcSubSetList ,itemqty - FCsMap.get(fcs[i].getFcId()), resFcSubsetGroup);
			}
			
	      if ( FCsMap.get(fcs[i].getFcId())>itemqty){
	    	  fcSubSetList.getFcIdSet().add(fcs[i].getFcId());
			  fcSubSetList.setTotalDistance(fcSubSetList.getTotalDistance()+FCsMap.get(fcs[i].getFcId()));
			  getSubsetRecursive(fcs, i-1,it,fcSubSetList ,0, resFcSubsetGroup);
			}
	      
		}
		
		static void findFcHasEqualGivenItemQty1(FullfilmentCenter[] fcs ,int n ,Item it, FCQuantitySplitSubsetDto fcSubSetList , int itemqty ,TreeSet<FCQuantitySplitSubsetDto> resFcSubsetGroup)
		{
			if (n == 0 || itemqty < 0)
			return;
		
			dp = new boolean[n][itemqty + 1];
			for (int i=0; i<n; ++i)
			{
				dp[i][0] = true;
			}
		
			if (FCsMap.get(fcs[0].getFcId()) <= itemqty)
				dp[0][FCsMap.get(fcs[0].getFcId())] = true;
		
			for (int i = 1; i < n; ++i)
				for (int j = 0; j < itemqty + 1; ++j) {
					
					dp[i][j] = (FCsMap.get(fcs[i].getFcId()) <= j) ? (dp[i-1][j] || dp[i-1][j-FCsMap.get(fcs[i].getFcId())]): true;
				}
			if (dp[n-1][itemqty] == false)
			{
				System.out.println("There are no subsets with" +
													" sum "+ itemqty);
				return;
			}
		
			getSubsetRecursive(fcs, n-1, it,fcSubSetList,itemqty,resFcSubsetGroup);
		}
	
}
