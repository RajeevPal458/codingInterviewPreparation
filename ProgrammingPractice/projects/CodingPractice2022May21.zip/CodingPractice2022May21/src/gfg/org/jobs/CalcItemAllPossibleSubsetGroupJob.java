package org.jobs;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class CalcItemAllPossibleSubsetGroupJob implements Callable<List<List<List<String>>>>{

	private String[] itemIds =null;
	private int itemcount=0;
	public CalcItemAllPossibleSubsetGroupJob(String[] itemIds , int size){
		this.itemIds = itemIds;
		this.itemcount = size ;
	}
	@Override
	public List<List<List<String>>> call() throws Exception {
		// TODO Auto-generated method stub
		List<List<List<String>>> resItemSubsetGroup = new ArrayList<>();
		for(int i=1 ; i<=itemcount ; i++) {
			partitionsItemListInKSubsets(itemIds, itemcount, i,resItemSubsetGroup);
			
			 System.out.println("partitionsItemListInKSubsets----------subsets");
		}
		
		return resItemSubsetGroup;
	}
	
	static void partitionsItemListInKSubsets(String arr[], int N, int K ,List<List<List<String>>> resItemSubsetGroup){
	    List<List<String>> v = new ArrayList<>();
	    //System.out.println("partitionsItemListInKSubsets----------recursion item subsets");
	    for(int i = 0; i < K; i++)
	      v.add(new ArrayList<>());
	
	    if (K == 0 || K > N)
	    {
	      //System.out.println("subset Not possible");
	    }
	    else
	    {
	       PartitionSub(arr, 0, N, K, 0, v,resItemSubsetGroup);
	    }
	    
	  }

	 static void PartitionSub(String arr[], int i,
	                           int N, int K, int nos,
	                           List<List<String>> v , List<List<List<String>>> resItemSubsetGroup){
	    
		 if (i >= N)
	    {
	      if (nos == K)
	      {
	       List<List<String>> lls = new ArrayList<>();
	       
	    	  for(List<String> ls:v) {
	    		  
	    		  List<String> lsnew = new ArrayList<>(ls);
	    		  
	    		  lls.add(lsnew);
			  }
	    	 
	       resItemSubsetGroup.add(lls);
	      }
	      return ;
	    }
	 
	    for (int j = 0; j < K; j++)
	    {
	      if (v.get(j).size() > 0)
	      {
	        v.get(j).add(arr[i]);
	        PartitionSub(arr, i + 1, N, K, nos, v ,resItemSubsetGroup);
	        v.get(j).remove(v.get(j).size()-1);
	      }
	      else
	      {
	        v.get(j).add(arr[i]);
	        PartitionSub(arr, i + 1, N, K, nos + 1, v , resItemSubsetGroup);
	        v.get(j).remove(v.get(j).size()-1);
	        break;
	      }
	    }
	  }

}
