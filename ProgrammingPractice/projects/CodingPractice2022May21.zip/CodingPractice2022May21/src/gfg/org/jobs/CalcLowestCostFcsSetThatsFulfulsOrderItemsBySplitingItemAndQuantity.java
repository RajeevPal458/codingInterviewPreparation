package org.jobs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.model.FCQuantitySplitSubsetDto;
import org.model.FullfilmentCenter;
import org.model.Item;

public class CalcLowestCostFcsSetThatsFulfulsOrderItemsBySplitingItemAndQuantity {

	static Map<Integer , Integer> FCsMap = new HashMap<>();
	public static  FCQuantitySplitSubsetDto findFcsSet(List<Item> items , FullfilmentCenter[] fcs){
		
		int itemsCount = items.size();
		String[] arr = new String[itemsCount] ;
		for(int i=0 ; i<items.size() ; i++) {
			arr[i] = items.get(i).getItemId();
		}
		
		for(FullfilmentCenter fc:fcs) {
			FCsMap.put(fc.getFcId(), fc.getDistance());
		}
		
		List<List<List<String>>> resItemSubsetGroup = new ArrayList<>();
		Map<String, TreeSet<FCQuantitySplitSubsetDto>> eachItemsFcsSubset = new HashMap<>();
		// call job1
		ExecutorService service =Executors.newFixedThreadPool(2);
		
		Future<List<List<List<String>>>> future1 = service.submit(new CalcItemAllPossibleSubsetGroupJob(arr , itemsCount ));
		
		
		Future<Map<String, TreeSet<FCQuantitySplitSubsetDto>>> future2= service.submit(new FindAllFcsSubsetsThatsFulfilItemsQuantityJob(fcs , fcs.length, items ,FCsMap));
		
		service.shutdown();
		
		try {
			resItemSubsetGroup = future1.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			eachItemsFcsSubset = future2.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for(Map.Entry<String, TreeSet<FCQuantitySplitSubsetDto>> entryset :eachItemsFcsSubset.entrySet()) {
			System.out.print("subsets for item Id :-"+entryset.getKey()+"  subset group: -");
			for(FCQuantitySplitSubsetDto ls :entryset.getValue()) {
					System.out.print(ls.toString()+" ");
			}
			System.out.println();
		}
			
		
		System.out.println("item split compbinations:- ");
		for(List<List<String>> lls :resItemSubsetGroup) {
			for(List<String> ls:lls) {
				System.out.print(ls+" ");
			}
			System.out.println();
		}
		
		// call job 2
		FCQuantitySplitSubsetDto resultFCs = null;
		resultFCs = createOrderFromStoreWithLessCost(items ,fcs ,resItemSubsetGroup ,eachItemsFcsSubset);
		
		
		return resultFCs;
		
	}
	

	private static FCQuantitySplitSubsetDto createOrderFromStoreWithLessCost(List<Item> items, FullfilmentCenter[] fcs,
			List<List<List<String>>> resItemSubsetGroup,
			Map<String, TreeSet<FCQuantitySplitSubsetDto>> eachItemsFcsSubset){
		// TODO Auto-generated method stub
		FCQuantitySplitSubsetDto resultFcSubset =null;
		Map<String, FCQuantitySplitSubsetDto> preCalcItemSet = new HashMap<>();
		for(List<List<String>> itemIdsSubsetGroup:resItemSubsetGroup) {
			
			FCQuantitySplitSubsetDto resSubsetForGroup =new FCQuantitySplitSubsetDto();
			for(List<String> itemSubset:itemIdsSubsetGroup ) {
				//System.out.println("------find subsets -----");
				FCQuantitySplitSubsetDto currFcSubsetGroup = null;
				String strkey = itemSubset.toString();
				if(preCalcItemSet.containsKey(strkey)) {
					currFcSubsetGroup =preCalcItemSet.get(strkey);
				}else {
					currFcSubsetGroup = fulfillSplitOrderInMinCost(itemSubset ,eachItemsFcsSubset , preCalcItemSet);
					preCalcItemSet.put(strkey, currFcSubsetGroup);
				}
				
				if(currFcSubsetGroup!=null && !currFcSubsetGroup.getFcIdSet().isEmpty()) {
					resSubsetForGroup.setTotalDistance(resSubsetForGroup.getTotalDistance() + currFcSubsetGroup.getTotalDistance());
					resSubsetForGroup.getFcIdSet().addAll(currFcSubsetGroup.getFcIdSet());
				}else {
					resSubsetForGroup = null;
					break;
				}
			}
			
			
			if(resSubsetForGroup!=null && !resSubsetForGroup.getFcIdSet().isEmpty()) {
				//resultFcSubset = filterLowestCostSubsetGroup(resultFcSubset , resSubsetForGroup);
				if(resultFcSubset!=null) {
					if( resSubsetForGroup.getTotalDistance() < resultFcSubset.getTotalDistance()) {
						resultFcSubset = resSubsetForGroup;
					}
				}else {
					resultFcSubset = resSubsetForGroup;
				}
			}else {
				System.out.println("This SubsetGroup not valid !");
			}
			
			System.out.println(":cost on split of size :"+ itemIdsSubsetGroup.size()+"     "+resSubsetForGroup.getTotalDistance());
		}
		
		System.out.println("Lowest cost subset group :");
		
		
		return resultFcSubset;
		
	}
	
	private static FCQuantitySplitSubsetDto fulfillSplitOrderInMinCost(List<String> subsetOne,
			Map<String ,TreeSet<FCQuantitySplitSubsetDto>>  eachItemsFcsSubset ,Map<String, FCQuantitySplitSubsetDto> preCalcItemSet ) {
		// TODO Auto-generated method stub Map<itemId , set of subsets of fcs>
		
		
		if(subsetOne ==null || subsetOne.isEmpty()) return null;
		
		//System.out.println("current subset- "+subsetOne);
		
		TreeSet<FCQuantitySplitSubsetDto> preIntersectionResult = new TreeSet<>();
		List<String> list = new ArrayList<String>();
		FCQuantitySplitSubsetDto lowCostSubset2 =null;
		String strkey ="";
		for(int i=0 ; i < subsetOne.size() ; i++) {
			String itemId =subsetOne.get(i);
			list.add(itemId);
			strkey = list.toString();
			
			TreeSet<FCQuantitySplitSubsetDto> subsetgroup = eachItemsFcsSubset.get(itemId);
			preIntersectionResult =findIntersectionSubSetGroups(preIntersectionResult ,subsetgroup );
			
			if(preIntersectionResult==null || preIntersectionResult.isEmpty())  return null;
			
			FCQuantitySplitSubsetDto lowCostSubset1=subsetgroup.first();
			List<String> list1 = new ArrayList<String>();
			list1.add(itemId);
			String strkey2 = list1.toString();
			if(!preCalcItemSet.containsKey(strkey2)){
				preCalcItemSet.put(strkey2, lowCostSubset1);
			}
			
			if(i!=0) {
				lowCostSubset2 = preIntersectionResult.first();
				preCalcItemSet.put(strkey, lowCostSubset2);
			}
		}
		return lowCostSubset2;
		
	}
	

	private static TreeSet<FCQuantitySplitSubsetDto> findIntersectionSubSetGroups(TreeSet<FCQuantitySplitSubsetDto> preIntersectionResult,
			TreeSet<FCQuantitySplitSubsetDto> subsetgroup) {
		// TODO Auto-generated method stub
		if(preIntersectionResult==null || preIntersectionResult.isEmpty()) return subsetgroup;
		TreeSet<FCQuantitySplitSubsetDto> result = new TreeSet<>();
		
		for(FCQuantitySplitSubsetDto preIntersectList : preIntersectionResult) {
			int dist = preIntersectList.getTotalDistance();
			Set<Integer> idSet = preIntersectList.getFcIdSet();
			
			for(FCQuantitySplitSubsetDto subsetGroupList : subsetgroup) {
				int dist1 = subsetGroupList.getTotalDistance();
				Set<Integer> idSet1 = subsetGroupList.getFcIdSet();
				
				Set<Integer> currresult =null;
				int distres =0;
				
				if(idSet1.containsAll(idSet)) {
					 currresult =idSet1;
					 distres = dist1;
				}else if( idSet.containsAll(idSet1)) {
					 currresult =idSet;
					 distres = dist;
				}
				
				if(currresult!=null && !currresult.isEmpty()) {
					FCQuantitySplitSubsetDto dto = new FCQuantitySplitSubsetDto();
					dto.setFcIdSet(currresult);
					dto.setTotalDistance(distres);
					result.add(dto);
				}
			}
		}
		
		
		return result;
	}


}
