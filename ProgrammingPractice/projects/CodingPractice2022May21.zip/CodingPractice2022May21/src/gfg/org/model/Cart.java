package org.model;

import java.util.List;

public class Cart {

	private int customerId;
	private List<Item> items;
	public Cart(int customerId, List<Item> items) {
		super();
		this.customerId = customerId;
		this.items = items;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "Cart [customerId=" + customerId + ", items=" + items + "]";
	}
	
}
