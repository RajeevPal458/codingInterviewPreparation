package org.model;

import java.util.List;

public class FullfilmentCenter implements Comparable<FullfilmentCenter>{

	private int fcId;
	private int distance;
	private List<Item> items;
	public FullfilmentCenter(int fcId,int distance , List<Item> items) {
		super();
		this.fcId = fcId;
		this.distance = distance;
		this.items = items;
	}
	public FullfilmentCenter() {
		// TODO Auto-generated constructor stub
	}
	public int getFcId() {
		return fcId;
	}
	public void setFcId(int fcId) {
		this.fcId = fcId;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	

	@Override
	public int compareTo(FullfilmentCenter obj) {
		int dist = obj.getDistance();
		// TODO Auto-generated method stub
		if(this.distance > dist )
			return +1;
		else if(this.distance < dist )
			return -1;
		return 0;
	}
	@Override
	public String toString() {
		return "FullfilmentCenter [fcId=" + fcId + ", distance=" + distance + ", items=" + items + "]";
	}
}
