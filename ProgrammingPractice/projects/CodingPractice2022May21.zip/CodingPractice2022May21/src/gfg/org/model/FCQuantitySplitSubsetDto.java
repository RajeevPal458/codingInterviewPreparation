package org.model;

import java.util.HashSet;
import java.util.Set;

public class FCQuantitySplitSubsetDto implements Comparable<FCQuantitySplitSubsetDto>{

	private Set<Integer> fcIdSet = new HashSet<>();
	private int totalDistance;
	


	public FCQuantitySplitSubsetDto() {
		super();
		
	}
	
	public FCQuantitySplitSubsetDto(Set<Integer> fcIdSet, int totalDistance) {
		super();
		this.fcIdSet = fcIdSet;
		this.totalDistance = totalDistance;
	}



	public FCQuantitySplitSubsetDto(FCQuantitySplitSubsetDto fcSubSetList) {
		// TODO Auto-generated constructor stub
		this.fcIdSet=new HashSet<>(fcSubSetList.getFcIdSet());
		this.totalDistance = fcSubSetList.getTotalDistance();
	}

	public Set<Integer> getFcIdSet() {
		return fcIdSet;
	}



	public void setFcIdSet(Set<Integer> fcIdSet) {
		this.fcIdSet = fcIdSet;
	}



	public int getTotalDistance() {
		return totalDistance;
	}



	public void setTotalDistance(int totalDistance) {
		this.totalDistance = totalDistance;
	}


	@Override
	public String toString() {
		return "[" + fcIdSet + " , " + totalDistance + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(obj instanceof FCQuantitySplitSubsetDto) {
			FCQuantitySplitSubsetDto dto = (FCQuantitySplitSubsetDto)obj;
			if(this.fcIdSet.size() == dto.getFcIdSet().size()  &&  this.totalDistance == dto.getTotalDistance()) {
				return true;
			}
			
		}
		return false;
	}

	@Override
	public int compareTo(FCQuantitySplitSubsetDto o) {
		// TODO Auto-generated method stub
		if(this.getTotalDistance() > o.getTotalDistance() || this.fcIdSet.size() > o.getFcIdSet().size())
			return +1;
		else if(this.getTotalDistance() < o.getTotalDistance() || this.fcIdSet.size() < o.getFcIdSet().size()) {
			return -1;
		}else {
			return 0;
		}
	}
	
}
