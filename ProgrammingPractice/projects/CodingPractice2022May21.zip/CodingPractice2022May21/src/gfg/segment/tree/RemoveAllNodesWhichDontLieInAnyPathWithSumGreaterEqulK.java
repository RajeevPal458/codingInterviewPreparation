package gfg.segment.tree;
/**
 * https://www.geeksforgeeks.org/remove-all-nodes-which-lie-on-a-path-having-sum-less-than-k/
 * 
 * Consider the following Binary Tree
          1 
      /      \
     2        3
   /   \     /  \
  4     5   6    7
 / \    /       /
8   9  12      10
   / \           \
  13  14         11
      / 
     15 

For input k = 20, the tree should be changed to following
(Nodes with values 6 and 8 are deleted)
          1 
      /      \
     2        3
   /   \        \
  4     5        7
   \    /       /
    9  12      10
   / \           \
  13  14         11
      / 
     15 
 * @author rajeevkumar.pal
 *
 */
public class RemoveAllNodesWhichDontLieInAnyPathWithSumGreaterEqulK {

	// A utility function to get
	// maximum of two integers
	static int max(int l, int r)
	{
	    return (l > r ? l : r);
	}
	 
	// A Binary Tree Node
	static class Node
	{
	    int data;
	    Node left, right;
	};
	 
	static class INT
	{
	    int v;
	INT(int a)
	{
	    v = a;
	}
	}
	 
	// A utility function to create
	// a new Binary Tree node with
	// given data
	static Node newNode(int data)
	{
	    Node node = new Node();
	    node.data = data;
	    node.left = node.right = null;
	    return node;
	}
	 
	// print the tree in LVR
	// (Inorder traversal) way.
	static void print(Node root)
	{
	    if (root != null)
	    {
	        print(root.left);
	        System.out.print(root.data + " ");
	        print(root.right);
	    }
	}
	// Driver Code
	public static void main(String args[])
	{
	    int k = 20;
	    Node root = newNode(1);
	    root.left = newNode(2);
	    root.right = newNode(3);
	    root.left.left = newNode(4);
	    root.left.right = newNode(5);
	    root.right.left = newNode(6);
	    root.right.right = newNode(7);
	    root.left.left.left = newNode(8);
	    root.left.left.right = newNode(9);
	    root.left.right.left = newNode(12);
	    root.right.right.left = newNode(10);
	    root.right.right.left.right = newNode(11);
	    root.left.left.right.left = newNode(13);
	    root.left.left.right.right = newNode(14);
	    root.left.left.right.right.left = newNode(15);
	 
	    System.out.println("Tree before truncation\n");
	    print(root);
	 
	    root = prune(root, k); // k is 45
	 
	    System.out.println("\n\nTree after truncation\n");
	    print(root);
	}

	private static Node prune(Node root, int k) {
		// TODO Auto-generated method stub
		if(root ==null)
			return null;
		
		root.left = prune(root.left, k-root.data);
		root.right = prune(root.right, k-root.data);
		
		if(root.left==null && root.right==null && k > root.data)
			return null;
		
		return root;
	}

}
