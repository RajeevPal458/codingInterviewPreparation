package org.test.java9;

public class TesterJava9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
