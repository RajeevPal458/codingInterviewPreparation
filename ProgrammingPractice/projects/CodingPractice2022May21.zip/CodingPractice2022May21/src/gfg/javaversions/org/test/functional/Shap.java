package org.test.functional;

public interface Shap {
	
	default void applycolor() {
		// TODO Auto-generated method stub

	}
	default void applycolor1() {
		// TODO Auto-generated method stub

	}
	static void applycolor2() {
		// TODO Auto-generated method stub

	}
	static void applycolor3() {
		// TODO Auto-generated method stub
	}
}
