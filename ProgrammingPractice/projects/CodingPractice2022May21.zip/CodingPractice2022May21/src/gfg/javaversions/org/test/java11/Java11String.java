package org.test.java11;
/**
 * 
 * @author rajeevkumar.pal
 * 
 *
 */
public class Java11String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Rajeevkumarpal";
		
	}

}
