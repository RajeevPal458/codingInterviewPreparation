package org.test.java10;

public class TesterJava10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		var name = "Rajeev" ;
	}

}
