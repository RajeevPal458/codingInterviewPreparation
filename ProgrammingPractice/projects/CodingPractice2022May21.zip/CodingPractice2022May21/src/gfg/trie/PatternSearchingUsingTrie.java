package gfg.trie;
/**
 * Pattern Searching using a Trie of all Suffixes
 * https://www.geeksforgeeks.org/pattern-searching-using-trie-suffixes/
 * @author rajeevkumar.pal
 *
 */
public class PatternSearchingUsingTrie {
dsfdfs
}
