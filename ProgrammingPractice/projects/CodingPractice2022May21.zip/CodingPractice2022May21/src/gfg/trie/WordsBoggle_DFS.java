package gfg.trie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordsBoggle_DFS {
	// Let the given dictionary be following
		static final String dictionary[] = { "GEEKS", "FOR", "QUIZ", "GUQ", "EE" };
		static final int n = dictionary.length;
		static final int M = 3, N = 3;

		private static int[] rw = {1,0,1,-1,-1,-1,0,1};
		private static int[] cl = {0,1,1,0,1,-1,-1,-1};
		
		// A given function to check if a given string is present in
		// dictionary. The implementation is naive for simplicity. As
		// per the question dictionary is given to us.
		static boolean isWord(String str)
		{
			// Linearly search all words
			for (int i = 0; i < n; i++)
				if (str.equals(dictionary[i]))
					return true;
			return false;
		}

		// A recursive function to print all words present on boggle
		static void findWordsUtil(char boggle[][], boolean visited[][], int i,
								int j, String str)
		{
			// Mark current cell as visited and append current character
			// to str
			visited[i][j] = true;
			str = str + boggle[i][j];

			// If str is present in dictionary, then print it
			if (isWord(str))
				System.out.println(str);

			// Traverse 8 adjacent cells of boggle[i][j]
			for (int row = i - 1; row <= i + 1 && row < M; row++)
				for (int col = j - 1; col <= j + 1 && col < N; col++)
					if (row >= 0 && col >= 0 && !visited[row][col])
						findWordsUtil(boggle, visited, row, col, str);

			// Erase current character from string and mark visited
			// of current cell as false
			str = "" + str.charAt(str.length() - 1);
			visited[i][j] = false;
		}

		// Prints all words present in dictionary.
		static void findWords(char boggle[][])
		{
			// Mark all characters as not visited
			boolean visited[][] = new boolean[M][N];

			// Initialize current string
			String str = "";

			// Consider every character and look for all words
			// starting with this character
			for (int i = 0; i < M; i++)
				for (int j = 0; j < N; j++)
					findWordsUtil(boggle, visited, i, j, str);
		}
		/*3,3
		 * 
		 *     1 2 3 4
		 *     2 6 7 8
		 *     3 4 5 6
		 *     5 6 7 8
		 */
		
		public static void doself(char[][] boggle ,String[] dictionary ) {
			
			int row = boggle.length;
			int col = boggle[0].length;
			
			class Pair{
				int r;
				int c;
				
				Pair(int r,int c){
					this.r=r;
					this.c=c;
				}

				@Override
				public String toString() {
					return "Pair [r=" + r + ", c=" + c + "]";
				}
				
			}
			Map<Character, List<Pair>> map = new HashMap<Character, List<Pair>>();
			
			System.out.println("row:-"+row +" col:-"+col);
			for(int i=0;i<row;i++) {
				for(int j=0;j<col;j++) {
					List<Pair> pair = map.getOrDefault(boggle[i][j], new ArrayList<Pair>());
					pair.add(new Pair(i, j));
					map.put(boggle[i][j], pair);
				}
			}
			
			boolean[][] visited = new boolean[row][col];
			
			for(int i=0;i<dictionary.length;i++) {
				String word = dictionary[i];
				if(map.containsKey(word.charAt(0))) {
					List<Pair> pairs = map.get(word.charAt(0));
					
					for(Pair pair:pairs) {
						if(dfsUtill(word,1,pair.r,pair.c,visited,boggle)) {
							System.out.println("word exist:-"+word);
							break;
						}
					}
				}
			}
			
			
		}

		private static boolean dfsUtill(String word, int i, int r, int c,boolean[][] visited,char[][] boggle) {
			// TODO Auto-generated method stub
			if(i==word.length()) return true;
			
			char ch = word.charAt(i);
			
			for(int j = 0;j<rw.length;j++) {
				if(isSafe(r+rw[j], c+cl[j], visited)) {
					visited[r+rw[j]][c+cl[j]] =true;
					if((ch==boggle[r+rw[j]][c+cl[j]] ) && dfsUtill(word, i+1, r+rw[j], c+cl[j], visited, boggle)) {
						return true;
					}
					visited[r+rw[j]][c+cl[j]] =false;
					System.out.println(boggle[r+rw[j]][c+cl[j]]);
				}
			}
			return false;
		}

		// function to check that current location
		// (i and j) is in matrix range
		static boolean isSafe(int i, int j, boolean visited[][])
		{
			return (i >= 0 && i < M && j >= 0
					&& j < N && !visited[i][j]);
		}
		
		// Driver program to test above function
		public static void main(String args[])
		{
			char boggle[][] = { { 'G', 'I', 'Z' },
								{ 'U', 'E', 'K' },
								{ 'Q', 'S', 'E' } };

			System.out.println("Following words of dictionary are present");
			//findWords(boggle);
			doself(boggle, dictionary);
		}
}

