package gfg.trie;

import java.util.HashSet;

public class CountDistinctSubstringInAString {

	static class TrieNode {
        TrieNode children[];
        boolean isEnd;
 
        TrieNode()
        {
            this.children = new TrieNode[26];
            this.isEnd = false;
        }
    }
 
    static TrieNode root = new TrieNode();
 
    static void insert(String str)
    {
        TrieNode cur = root;
        for (char ch : str.toCharArray()) {
            int idx = ch - 'a';
 
            if (cur.children[idx] == null)
                cur.children[idx] = new TrieNode();
 
            cur = cur.children[idx];
        }
        cur.isEnd = true;
    }
    /*a a a b c
     * 12
     *               a      b c
     *               a   b  c
     *               a b c
     *               b c
     *               c
     */
 
    public static int distinctSubstringCount(String str)
    {
        // will hold the count of unique substrings
        int cnt = 0;
        for (int i = 0; i <= str.length(); i++) {
            // start from root of trie each time as new
            // starting point
            TrieNode temp = root;
            for (int j = i; j < str.length(); j++) {
                char ch = str.charAt(j);
                // when char not present add it to the trie
                if (temp.children[ch - 'a'] == null) {
                    temp.children[ch - 'a']
                        = new TrieNode();
                    temp.isEnd = true;
                    cnt++;
                }
                // move on to the next char
                temp = temp.children[ch - 'a'];
            }
        }
        System.out.println("Total count of substring :-"+cnt);
        return cnt;
    }
	// Function to return the count of
	// valid sub-Strings
	static void printSubStrings(String s)
	{
	 
	    // To store distinct output subStrings
	    HashSet<String> us = new HashSet<String>();
	 
	    // Traverse through the given String and
	    // one by one generate subStrings beginning
	    // from s[i].
	    for (int i = 0; i < s.length(); ++i)
	    {
	 
	        // One by one generate subStrings ending
	        // with s[j]
	        String ss = "";
	        for (int j = i; j < s.length(); ++j)
	        {
	            ss = ss + s.charAt(j);
	            us.add(ss);
	        }
	    }
	 
	    // Print all subStrings one by one
	    for (String str : us)
	        System.out.print(str + " ");
	}
	 
	// Driver code
	public static void main(String[] args)
	{
	    String str = "aaabc";
	    distinctSubstringCount(str);
	}
	
}
