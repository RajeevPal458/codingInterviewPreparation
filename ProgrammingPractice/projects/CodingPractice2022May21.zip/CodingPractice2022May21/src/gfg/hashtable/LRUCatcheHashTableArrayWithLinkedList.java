package gfg.hashtable;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.BlockingQueue;

public class LRUCatcheHashTableArrayWithLinkedList {

	static BlockingQueue<String> str=null;
	
	public static void main(String[] args) {
		try {
			str.take();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	class Node {
		  int key;
		  int value;
		  Node pre;
		  Node next;

		  public Node(int key, int value)
		  {
		    this.key = key;
		    this.value = value;
		  }
		}
	
	  private Node[] table;
	  private int capacity, count;
	  private Node head, tail;

	  public LRUCatcheHashTableArrayWithLinkedList(int capacity)
	  {
	    this.capacity = capacity;
	    map = new HashMap<>();
	    head = new Node(0, 0);
	    tail = new Node(0, 0);
	    head.next = tail;
	    tail.pre = head;
	    head.pre = null;
	    tail.next = null;
	    count = 0;
	  }

}
