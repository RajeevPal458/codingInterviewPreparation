package gfg.hashtable;
/**
 * https://www.enjoyalgorithms.com/blog/implement-least-recently-used-cache
 * 
 * @author rajeevkumar.pal
 *
 */
public class LRUusingHashTable {

	public static void main(String args[]) {
	      String Str = new String("Hi");
	      System.out.println("Hashcode for Str :" + new LRUusingHashTable());
	   }
}
