package org.leet.code.goldmansachs;

//Find the maximum sum path between two leaves in a binary tree
//https://www.techiedelight.com/find-maximum-sum-path-between-two-leaves-in-a-binary-tree/
//https://www.codingninjas.com/codestudio/library/find-the-maximum-path-sum-between-two-leaves-of-a-binary-tree
public class FindTheMaxSumPathBetTwoLeavesBinaryTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
