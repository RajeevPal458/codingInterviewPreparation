package org.leet.code.goldmansachs;

//https://practice.geeksforgeeks.org/problems/trapping-rain-water-1587115621/1
public class TrappingRainWaterProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
