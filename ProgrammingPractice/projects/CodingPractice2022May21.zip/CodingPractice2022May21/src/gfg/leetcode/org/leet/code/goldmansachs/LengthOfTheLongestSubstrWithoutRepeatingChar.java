package org.leet.code.goldmansachs;

//Length of the longest substring without repeating characters

public class LengthOfTheLongestSubstrWithoutRepeatingChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "geeksforgeeks";
	    System.out.println("The input string is " + str);
	 
	    int len = longestUniqueSubsttr(str);
	     
	    System.out.println("The length of the longest " +
	                       "non-repeating character " +
	                       "substring is " + len);
	}

	private static int longestUniqueSubsttr(String str) {
		// TODO Auto-generated method stub
		return 0;
	}

}
