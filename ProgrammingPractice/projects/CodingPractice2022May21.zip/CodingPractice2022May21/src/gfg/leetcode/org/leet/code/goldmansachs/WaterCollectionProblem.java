package org.leet.code.goldmansachs;

//https://practice.geeksforgeeks.org/problems/amount-of-water1348/1
public class WaterCollectionProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
