package org.leet.code.goldmansachs;

//https://www.geeksforgeeks.org/median-of-two-sorted-arrays/
public class MedianOfTwoSortedArraysOfSameSize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
