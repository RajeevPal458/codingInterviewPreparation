package org.leet.code.goldmansachs;

public class Employee {

	@Override
	public String toString() {
		return "Employee [name=" + name + "]";
	}

	private String name;
}
