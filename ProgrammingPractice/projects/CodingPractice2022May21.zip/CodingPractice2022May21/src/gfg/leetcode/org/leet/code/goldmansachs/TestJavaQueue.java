package org.leet.code.goldmansachs;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class TestJavaQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> queueA = new LinkedList<Integer>();
		Queue<Integer> queueB = new PriorityQueue<Integer>();
	
		queueA.add(1);
		System.out.println( queueA);
		
		
	}

}
