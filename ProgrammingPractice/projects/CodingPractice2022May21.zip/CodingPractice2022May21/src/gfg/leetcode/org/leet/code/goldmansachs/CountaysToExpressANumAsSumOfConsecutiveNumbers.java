package org.leet.code.goldmansachs;

public class CountaysToExpressANumAsSumOfConsecutiveNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
