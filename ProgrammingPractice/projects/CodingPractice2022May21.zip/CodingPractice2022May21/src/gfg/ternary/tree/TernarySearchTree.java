package gfg.ternary.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * https://www.geeksforgeeks.org/ternary-search-tree/
 * https://www.geeksforgeeks.org/data-structure-dictionary-spell-checker/
 * @author rajeevkumar.pal
 *
 */
public class TernarySearchTree {
	private static TSTNode root = null;;
	private static List<String> alist =null;
	public static void main(String[] args) {
		
	    char cat[] = "cat".toCharArray();
	    char cats[] = "cats".toCharArray();
	    char up[] = "up".toCharArray();;
	    char bug[] = "bug".toCharArray();
	    char bu[] = "bu".toCharArray();
	    
	    tstInsert(cat);
	    tstInsert(cats);
	    tstInsert(up);
	    tstInsert(bug);
	 
	    System.out.println("Following is traversal of ternary search tree");
	    
	    traverseTST(root);
	 
	    System.out.println("\nFollowing are search results for cats, bu and cat respectively");
	    
	    String str =(searchTST(cats)) ? "Found" : "Not Found";
	    System.out.println(Arrays.toString(cats)+"::"+str);
	    
	    str =(searchTST(bu)) ? "Found":"Not Found";
	    System.out.println(Arrays.toString(bu)+"::"+str);
	    
	    str =(searchTST(cat)) ? "Found\n": "Not Found";
	 
	    System.out.println(Arrays.toString(cat)+"::"+str);
	}
	

	static class TSTNode{
		char ch;
		boolean end;
		TSTNode left;
		TSTNode mid;
		TSTNode right;
		
		public TSTNode() {
			super();
		}

		public TSTNode(char ch, boolean end ) {
			this.ch = ch;
			this.end = end;
			this.left = null;
			this.mid = null;
			this.right = null;
		}

		@Override
		public String toString() {
			return "TSTNode [ch=" + ch + ", end=" + end + ", left=" + left + ", mid=" + mid + ", right=" + right + "]";
		}
		
		
	}

	

	private static void tstInsert(char[] cat) {
		root =tstInsertChar(root, cat,0,cat.length);
	}
	
	private static TSTNode tstInsertChar(TSTNode root , char[] cat,int i,int len) {
		
		 if(root==null) {
			 root = new TSTNode(cat[i],false);
		 }
		
		
		if(root.ch > cat[i])
			root.left= tstInsertChar(root.left,cat,i,len);
		
		else if(root.ch < cat[i])
			root.right=tstInsertChar(root.right,cat,i,len);
		else {
			if (i + 1 < len)
                root.mid = tstInsertChar(root.mid, cat, i + 1,len);
            else
                root.end = true;
		}
		return root;
	}
	
	private static void traverseTST(TSTNode root) {
		 alist = new ArrayList<String>();
		traverseTSTUtill(root, "");
       
		System.out.println(alist);
	}
	/** function to traverse tree **/
    private static void traverseTSTUtill(TSTNode r, String str)
    {
        if (r != null)
        {
        	traverseTSTUtill(r.left, str);
 
            str = str + r.ch;
            if (r.end)
            	alist.add(str);
 
            traverseTSTUtill(r.mid, str);
            str = str.substring(0, str.length() - 1);
 
            traverseTSTUtill(r.right, str);
        }
    }
	
	private static boolean searchTST(char[] cat) {
		// TODO Auto-generated method stub
		if(root==null) {
			return false;
		}
		return searchTSTUtill(root, cat,0,cat.length);
	}
	
	private static boolean searchTSTUtill(TSTNode root,char[] ch,int i ,int len) {
		 if(root==null) {
			 return false;
		 }
		if(root.ch > ch[i])
			return searchTSTUtill(root.left,ch,i,len);
		
		else if(root.ch < ch[i])
			return searchTSTUtill(root.right,ch,i,len);
		else {
			if (root.end && i == len-1)
				return true;
			else if ( i == len-1)
				return false;
			
            else
            	return searchTSTUtill(root.mid, ch, i + 1,len);
		}
	}
	/**
	  * 
	  *    
	  *         c 
	  *      b  a u
	  *      u  t p
	  *      g s
	  */
	 /** function to delete a word **/
    public void delete(String word)
    {
        delete(root, word.toCharArray(), 0);
    }
    /** function to delete a word **/
    private void delete(TSTNode r, char[] word, int ptr)
    {
        if (r == null)
            return;
 
        if (word[ptr] < r.ch)
            delete(r.left, word, ptr);
        else if (word[ptr] > r.ch)
            delete(r.right, word, ptr);
        else
        {
            /** to delete a word just make isEnd false **/
            if (r.end && ptr == word.length - 1)
                r.end = false;
 
            else if (ptr + 1 < word.length)
                delete(r.mid, word, ptr + 1);
        } 
        
    }
    
 /**
  * 
  *    
  *         c 
  *      b  a u
  *      u  t p
  *      g s
  */

}
