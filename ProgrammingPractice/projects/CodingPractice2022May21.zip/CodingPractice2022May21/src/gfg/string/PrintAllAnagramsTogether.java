package gfg.string;

import java.util.Arrays;

/**
 * Given a sequence of words, print all anagrams together
 * https://www.geeksforgeeks.org/given-a-sequence-of-words-print-all-anagrams-together/
 * 
 * 
 * @author rajeevkumar.pal
 *
 */
public class PrintAllAnagramsTogether {

	static class Pair implements Comparable<Pair>{
		String str;
		int index;
		@Override
		public int compareTo(Pair o) {
			// TODO Auto-generated method stub
			return this.str.compareTo(o.str);
		}
		@Override
		public String toString() {
			return "Pair [str=" + str + ", index=" + index + "]";
		}
		
		
		
	}
	public static void main(String[] args) {
		String[] arr = {"cat", "dog", "tac", "god", "act"};
		printAnagramTogether(arr);
	}
	
	public static void printAnagramTogether(String[] arr) {
		
		Pair[] pairarr = new Pair[arr.length];
		
		for(int i=0;i<arr.length;i++) {
			
			Pair pair = new Pair();
			pair.index=i;
			char[] charr = arr[i].toCharArray(); 
			Arrays.sort(charr);
			pair.str= new String(charr);
			
			pairarr[i] = pair;
			
		}
		Arrays.sort(pairarr);
		
		//System.out.println(Arrays.toString(pairarr));
		
		for(int i=0;i<pairarr.length;i++) {
			
			System.out.print(arr[pairarr[i].index]+" ");
		}
		
	}
}
