package gfg.string;

/**
 * Length of the longest substring without repeating characters
 * 
 * Method 1 (Simple : O(n3)): We can consider all substrings one by one and check for each substring whether it contains all unique characters or not. 
 * There will be n*(n+1)/2 substrings. Whether a substring contains all unique characters or not can be checked in linear time by scanning 
 * it from left to right and keeping a map of visited characters.
 * 
 * Method 2 (Better : O(n2)) The idea is to use window sliding. Whenever we see repetition, we remove the previous occurrence and slide the window.
 * Time Complexity: O(n^2) since we are traversing each window to remove all repetitions.

Auxiliary Space: O(1)

Method 3 ( Linear Time ): Using this solution the problem can be solved in linear time using the window sliding technique. Whenever we see repetition, 
we remove the window till the repeated string.



 * @author rajeevkumar.pal
 *
 */
public class LongestSubStringWithNoDuplicates {

	public static int longestUniqueSubsttr(String str)
	{
	    int n = str.length();
	     
	    // Result
	    int res = 0;
	     
	    for(int i = 0; i < n; i++)
	    {
	         
	        // Note : Default values in visited are false
	        boolean[] visited = new boolean[256];
	         
	        for(int j = i; j < n; j++)
	        {
	             
	            // If current character is visited
	            // Break the loop
	            if (visited[str.charAt(j)] == true)
	                break;
	 
	            // Else update the result if
	            // this window is larger, and mark
	            // current character as visited.
	            else
	            {
	                res = Math.max(res, j - i + 1);
	                visited[str.charAt(j)] = true;
	            }
	        }
	 
	        // Remove the first character of previous
	        // window
	        visited[str.charAt(i)] = false;
	    }
	    return res;
	}
	
	public static int longestUniqueSubsttr1(String str)
    {
        String test = "";
 
        // Result
        int maxLength = -1;
 
        // Return zero if string is empty
        if (str.isEmpty()) {
            return 0;
        }
        // Return one if string length is one
        else if (str.length() == 1) {
            return 1;
        }
        for (char c : str.toCharArray()) {
            String current = String.valueOf(c);
 
            // If string already contains the character
            // Then substring after repeating character
            if (test.contains(current)) {
                test = test.substring(test.indexOf(current)
                                      + 1);
            }
            test = test + String.valueOf(c);
            maxLength = Math.max(test.length(), maxLength);
        }
 
        return maxLength;
    }
	 
	// Driver code
	public static void main(String[] args)
	{
	    String str = "geeksforgeeks";
	    System.out.println("The input string is " + str);
	 
	    int len = longestUniqueSubsttr(str);
	    System.out.println("The length of the longest " +
	                       "non-repeating character " +
	                       "substring is " + len);
	}
	
}
