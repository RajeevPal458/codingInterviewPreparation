package gfg.string;

/**
 * Minimum rotations required to get the same string
 * https://www.geeksforgeeks.org/minimum-rotations-required-get-string/
 * 
 * @author rajeevkumar.pal
 *
 */
public class MinRotationRequiredToGetSanmeString {

	public static void main (String[] args) {
		String string = "aaaa";//baba  abab
		System.out.println("Rotation required :- "+findRotations1(string));;
	}
	
	public static int  findRotations1(String string) {
		
		String check = new String(string);
	    int count =0;
	    int r;
		for(r = 1; r <= string.length() ; r++)
		{
			
			// checking the input after each rotation
			check = check.substring(1, string.length())+check.substring(0, 1);
		    count++;
			// following if statement checks if input is
			// equals to check , if yes it will print r and
			// break out of the loop
			if(check.equals(string)){
				break;
			}
		}
		return count;
	}
	// Returns count of rotations to get the
    // same string back.
    static int findRotations(String str)
    {
        // tmp is the concatenated string.
        String tmp = str + str;
        int n = str.length();
     
        for (int i = 1; i <= n; i++)
        {
            // substring from i index of original
            // string size.
             
            String substring = tmp.substring(
                      i, i+str.length());
     
            // if substring matches with original string
            // then we will come out of the loop.
            if (str.equals(substring))
                return i;
        }
        return n;
    }
}
