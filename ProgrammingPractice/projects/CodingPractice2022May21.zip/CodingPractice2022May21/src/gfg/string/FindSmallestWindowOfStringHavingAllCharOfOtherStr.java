package gfg.string;

import java.util.Arrays;

/**
 * Find the smallest window in a string containing all characters of another string
 * https://www.geeksforgeeks.org/find-the-smallest-window-in-a-string-containing-all-characters-of-another-string/
Input: string = “this is a test string”, pattern = “tist” 
Output: Minimum window is “t stri” 
Explanation: “t stri” contains all the characters of pattern.

Input: string = “geeksforgeeks”, pattern = “ork” 
Output: Minimum window is “ksfor”
 * @author rajeevkumar.pal
 *
 */
public class FindSmallestWindowOfStringHavingAllCharOfOtherStr {

	public static void main(String[] args) {
		String str = "this is a test string";
		String pattern = "tist";
		
		smallestWindow(str.toCharArray(),pattern,str);
	}

	private static void smallestWindow(char[] arr, String pattern,String str) {
		
		int minres=Integer.MAX_VALUE;
		String resstr="";
		boolean[] visit = new boolean[arr.length];
		boolean[] visit2 = null;
		boolean  flag=true;
		while (flag) {
			int min = Integer.MAX_VALUE;
			int max = Integer.MIN_VALUE;
			visit2 = new boolean[arr.length];
			for(char ch:pattern.toCharArray()) {
				int ind =-1;
				for(int i=0;i<arr.length;i++) {
					
					if(ch==arr[i] && !visit[i] && !visit2[i]) {
						ind=i;
						visit2[i]=true;
						break;
					}
				}
				if(ind<0) {
					flag=false;
					break;
				}
				System.out.println("index : "+ind);
				if(ind <min) {
					min = ind;
				}
				if(ind>max) {
					max =ind;
				}
				
			}
			System.out.println(min+" : "+max);
			if(minres > (max-min+1) && flag) {
				minres = max-min+1;
				resstr=str.substring(min,max+1);
				System.out.println(resstr+"-----");
			}
			if(flag) {
				visit[min]=true;
			}else {
			}
		}
		System.out.println("Result : "+minres +":::"+resstr);
	}
}
