package gfg.string;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

/**
 * Write a function to check whether two given strings are anagram of each other or not. An anagram of a string is another string that contains the same characters, 
 * only the order of characters can be different. For example, “abcd” and “dabc” are an anagram of each other.
 * 
 * 
 * @author rajeevkumar.pal
 *
 */
public class CheckWhetherTwoStringsAnagram {

	/* function to check whether two strings are
    anagram of each other */
    static boolean areAnagram(char[] str1, char[] str2)
    {
        // Get lengths of both strings
        int n1 = str1.length;
        int n2 = str2.length;
 
        // If length of both strings is not same,
        // then they cannot be anagram
        if (n1 != n2)
            return false;
 
        // Sort both strings
        Arrays.sort(str1);
        Arrays.sort(str2);
 
        // Compare sorted strings
        for (int i = 0; i < n1; i++)
            if (str1[i] != str2[i])
                return false;
 
        return true;
    }
    
    static int NO_OF_CHARS = 256;
    
    /* function to check whether two strings
    are anagram of each other */
    static boolean areAnagram2(char str1[], char str2[])
    {
        // Create 2 count arrays and initialize
        // all values as 0
        int count1[] = new int[NO_OF_CHARS];
        Arrays.fill(count1, 0);
        int count2[] = new int[NO_OF_CHARS];
        Arrays.fill(count2, 0);
        int i;
 
        // For each character in input strings,
        // increment count in the corresponding
        // count array
        for (i = 0; i < str1.length && i < str2.length;
             i++) {
            count1[str1[i]]++;
            count2[str2[i]]++;
        }
 
        // If both strings are of different length.
        // Removing this condition will make the program
        // fail for strings like "aaca" and "aca"
        if (str1.length != str2.length)
            return false;
 
        // Compare count arrays
        for (i = 0; i < NO_OF_CHARS; i++)
            if (count1[i] != count2[i])
                return false;
 
        return true;
    }
 
 // function to check if two strings
 // are anagrams of each other
 static boolean areAnagram3(char[] str1,
                           char[] str2)
 {
      
     // Create a count array and initialize
     // all values as 0
     int[] count = new int[NO_OF_CHARS];
     int i;
  
     // If both strings are of different
     // length. Removing this condition
     // will make the program fail for
     // strings like "aaca" and "aca"
     if (str1.length != str2.length)
         return false;
    
     // For each character in input strings,
     // increment count in the corresponding
     // count array
     for(i = 0; i < str1.length; i++)
     {
         count[str1[i]]++;
         count[str2[i]]--;
     }
  
     // See if there is any non-zero
     // value in count array
     for(i = 0; i < NO_OF_CHARS; i++)
         if (count[i] != 0)
         {
             return false;
         }
     return true;
 }

 public static boolean isAnagram(String a, String b)
 {
     // Check if length of both strings is same or not
     if (a.length() != b.length()) {
         return false;
     }
     // Create a HashMap containing Character as Key and
     // Integer as Value. We will be storing character as
     // Key and count of character as Value.
     HashMap<Character, Integer> map = new HashMap<>();
     // Loop over all character of String a and put in
     // HashMap.
     for (int i = 0; i < a.length(); i++) {
         // Check if HashMap already contain current
         // character or not
         if (map.containsKey(a.charAt(i))) {
             // If contains increase count by 1 for that
             // character
             map.put(a.charAt(i),
                     map.get(a.charAt(i)) + 1);
         }
         else {
             // else put that character in map and set
             // count to 1 as character is encountered
             // first time
             map.put(a.charAt(i), 1);
         }
     }
     // Now loop over String b
     for (int i = 0; i < b.length(); i++) {
         // Check if current character already exists in
         // HashMap/map
         if (map.containsKey(b.charAt(i))) {
             // If contains reduce count of that
             // character by 1 to indicate that current
             // character has been already counted as
             // idea here is to check if in last count of
             // all characters in last is zero which
             // means all characters in String a are
             // present in String b.
             map.put(b.charAt(i),
                     map.get(b.charAt(i)) - 1);
         }
     }
     // Extract all keys of HashMap/map
     Set<Character> keys = map.keySet();
     // Loop over all keys and check if all keys are 0.
     // If so it means it is anagram.
     for (Character key : keys) {
         if (map.get(key) != 0) {
             return false;
         }
     }
     // Returning True as all keys are zero
     return true;
 }
 
    /* Driver Code*/
    public static void main(String args[])
    {
        char str1[] = { 't', 'e', 's', 't' };
        char str2[] = { 't', 't', 'e', 'w' };
       
        // Function Call
        if (areAnagram(str1, str2))
            System.out.println("The two strings are"
                               + " anagram of each other");
        else
            System.out.println("The two strings are not"
                               + " anagram of each other");
    }

}
