package gfg.string;


/**
 * 
Write a program to print all permutations of a given string
Below are the permutations of string ABC. 
ABC ACB BAC BCA CBA CAB

 * @author rajeevkumar.pal
 *
 */
public class PermutationsOfGivenString {

	public static void main(String[] args) 
    { 
        String str = "ABC"; 
        int n = str.length(); 
        PermutationsOfGivenString permutation = new PermutationsOfGivenString(); 
        
        //permutation.permute(str, 0, n-1); 
        
        
        permute(str, "");
    } 
	
	
	static void permute(String s , String answer)
	{   
	    if (s.length() == 0)
	    {
	        System.out.print(answer + "  ");
	        return;
	    }
	      
	    for(int i = 0 ;i < s.length(); i++)
	    {
	        char ch = s.charAt(i);
	        String left_substr = s.substring(0, i);
	        String right_substr = s.substring(i + 1);
	        String rest = left_substr + right_substr;
	        permute(rest, answer + ch);
	    }
	}
	
  
    /** 
    * permutation function 
    * @param str string to calculate permutation for 
    * @param l starting index 
    * @param r end index 
    */
    private void permute(String str, int start, int end) 
    { 
        if (start == end) 
            System.out.println(str); 
        else
        { 
            for (int i = start; i <= end; i++) 
            { 
                str = swap(str,start,i); 
                permute(str, start+1, end); 
                str = swap(str,start,i); 
            } 
        } 
    } 
  
    /** 
    * Swap Characters at position 
    * @param a string value 
    * @param i position 1 
    * @param j position 2 
    * @return swapped string 
    */
    public String swap(String a, int i, int j) 
    { 
        char temp; 
        char[] charArray = a.toCharArray(); 
        temp = charArray[i] ; 
        charArray[i] = charArray[j]; 
        charArray[j] = temp; 
        return String.valueOf(charArray); 
    }
	
}
