package gfg.string;

import java.util.HashMap;
import java.util.Map;

/**
 * https://www.tutorialspoint.com/program-to-find-minimum-swaps-required-to-make-given-anagram-in-python
 * https://www.codingninjas.com/codestudio/problem-details/minimum-swaps-to-make-two-strings-equal_1376440
 * @author rajeevkumar.pal
 *
 */
public class FindMinimumSwapsRequiredToMakeGivenAnagram {
	
	public static void main1(String[] args) {
				String S = "kolkata" ;
				String T = "katloka";
				System.out.println(CountSteps2(S.toCharArray(), T.toCharArray(),0));
	}
	
	// Driver code
	public static void main(String[] args)
	{
	    String s1 = "kolkata";
	    String s2 = "katloka";
	    			//adcb
	    			// abcd
	 
	    
	    int size = s2.length();
	 
	    // If both the strings are anagrams
	    // of each other then only they
	    // can be made equal
	    if (isAnagram(s1, s2))
	        System.out.println(CountSteps2(s1.toCharArray(), s2.toCharArray(), 0));
	    else
	        System.out.println(-1);
	}

	private static int CountSteps(char[] s, char[] t, int size) {
		// TODO Auto-generated method stub
		int count =0;
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		
		for(int i=0;i<s.length;i++) {
			char ch = s[i];
			int j;
			map.put(ch, map.getOrDefault(ch, 0)+1);
			int charcount = map.get(ch);
			for(j=0;j<t.length;j++) {
				if(ch==t[j] && charcount==1) {
					break;
				}
				if(ch==t[j]) {
					charcount--;
				}
			}
			if(i!=j) {
				swap(t , i,j);
				count++;
			}
		}
		return count;
	}

	private static boolean isAnagram(String s1, String s2) {
		// TODO Auto-generated method stub
		int[] temp = new int[26];
		if(s1.length()!=s2.length()) return false;
		
		for(int i=0;i<s1.length();i++) {
			temp[s1.charAt(i)-'a']++;
			temp[s2.charAt(i)-'a']--;
		}
		
		for(int i=0;i<26;i++) {
			if(temp[i]!=0) return false;
		}
			
		return true;
	}

	private static int CountSteps2(char[] s, char[] t, int i) {
		// TODO Auto-generated method stub
		if(i>=s.length)
			return 0;
		if(s[i]==t[i])
			return CountSteps(s, t, i+1);
		char x = t[i];
		int ret = Integer.MAX_VALUE;
		for(int j=i+1 ; j< t.length ; j++ ) {
			if(x == s[j]) {
				swap(s ,i ,j);
				ret = Math.min(ret, 1+CountSteps(s, t, i+1));
				swap(s, i, j);
			}
		}
		return ret;
	}

	private static void swap(char[] s, int i, int j) {
		// TODO Auto-generated method stub
		System.out.println("i "+i+" ,j "+j);
		char temp = s[i];
		s[i] = s[j];
		s[j] = temp;
	}

	
}
