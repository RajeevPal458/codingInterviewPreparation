package gfg.string;

public class FindAStringIsInterleavedOfTwoOtherString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = "katreena";
		String str2 = "kareena";
		String str3 = "katkareereenana";
		
		System.out.println(str2IsSuffleOfStr1AndStr2(str1,str2,str3));;
	}

	private static boolean str2IsSuffleOfStr1AndStr2(String str1, String str2, String str3) {
		// TODO Auto-generated method stub
		int len1 = str1.length();
		int len2 = str2.length();
		int len3 = str3.length();
		if(len1+len2!=len3) return false;
		
		int ind1=0;
		int ind2=0;
		int ind3=0;
		
		for(int i=ind3;i<len3;i++) {
			char ch = str3.charAt(i);
			
			if(ind1 < len1 && ch==str1.charAt(ind1)) {
				ind1++;
			}else if(ind2 < len2 && ch==str2.charAt(ind2)) {
				ind2++;
			}else {
				return false;
			}
		}
		return true;
	}

}
