package gfg.string;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Check if two strings are k-anagrams or not
 * https://www.geeksforgeeks.org/check-two-strings-k-anagrams-not/
 * 
 * Given two strings of lowercase alphabets and a value k, the task is to find if two strings are K-anagrams of each other or not.
Two strings are called k-anagrams if following two conditions are true. 

Both have same number of characters.
Two strings can become anagram by changing at most k characters in a string.

Input:  str1 = "anagram" , str2 = "grammar" , k = 3
Output:  Yes
Explanation: We can update maximum 3 values and 
it can be done in changing only 'r' to 'n' 
and 'm' to 'a' in str2.


 * @author rajeevkumar.pal
 *
 */
public class CheckIfTwoStringsAre_k_AnagramsOrNot {
	static final int MAX_CHAR = 26;
	
	// Function to check that string is k-anagram or not
    static boolean arekAnagrams(String str1, String str2,
                                                 int k)
    {
        // If both strings are not of equal
        // length then return false
        int n = str1.length();
        if (str2.length() != n)
            return false;
 
        int[] count1 = new int[MAX_CHAR];
        int[] count2 = new int[MAX_CHAR];
        int count = 0;
        
        // Store the occurrence of all characters
        // in a hash_array
        for (int i = 0; i < n; i++)
            count1[str1.charAt(i) - 'a']++;
        for (int i = 0; i < n; i++)
            count2[str2.charAt(i) - 'a']++;
 
        // Count number of characters that are
        // different in both strings
        for (int i = 0; i < MAX_CHAR; i++)
            if (count1[i] > count2[i])
                count = count + Math.abs(count1[i] -
                                          count2[i]);
 
        // Return true if count is less than or
        // equal to k
        return (count <= k);
    }
 
 // or not
    static boolean areKAnagrams(String str1, String str2,
                                                  int k)
    {
        // If both strings are not of equal
        // length then return false
        int n = str1.length();
        if (str2.length() != n)
            return false;
      
        int[] hash_str1 = new int[MAX_CHAR];
      
        // Store the occurrence of all characters
        // in a hash_array
        for (int i = 0; i < n ; i++)
            hash_str1[str1.charAt(i)-'a']++;
      
        // Store the occurrence of all characters
        // in a hash_array
        int count = 0;
        for (int i = 0; i < n ; i++)
        {
            if (hash_str1[str2.charAt(i)-'a'] > 0)
                hash_str1[str2.charAt(i)-'a']--;
            else
                count++;
      
            if (count > k)
                return false;
        }
      
        // Return true if count is less than or
        // equal to k
        return true;
    }
 // Function to check k
 // anagram of two strings
 public static boolean kAnagrams(String str1,
                                 String str2, int k)
 {
     int flag = 0;
      
     List<Character> list = new ArrayList<>();
      
     // First Condition: If both the
     // strings have different length ,
     // then they cannot form anagram
     if (str1.length() != str2.length())
         System.exit(0);
      
     // Converting str1 to Character Array arr1
     char arr1[] = str1.toCharArray();
      
     // Converting str2 to Character Array arr2
     char arr2[] = str2.toCharArray();
      
     // Sort arr1 in increasing order
     Arrays.sort(arr1);
      
     // Sort arr2 in increasing order
     Arrays.sort(arr2);
      
     // Iterate till str1.length()
     for (int i = 0; i < str1.length(); i++)
     {
          
         // Condition if arr1[i] is
         // not equal to arr2[i]
         // then add it to list
         if (arr1[i] != arr2[i])
         {
             list.add(arr2[i]);
         }
     }
      
     // Condition to check if
     // strings for K-anagram or not
     if (list.size() <= k)
         flag = 1;
  
     if (flag == 1)
         return true;
     else
         return false;
 }
  
    // Driver code
    public static void main(String args[])
    {
        String str1 = "anagram";
        String str2 = "grammar";
        int k = 2;
        if (arekAnagrams(str1, str2, k))
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}
