package gfg.matrix;

import java.util.Arrays;

/**
 * Maximum sum rectangle in a 2D matrix | DP-27
 * Given a 2D array, find the maximum sum subarray in it. For example, in the following 2D array, 
 * the maximum sum subarray is highlighted with blue rectangle and sum of this subarray is 29.
 * 
 * The Naive Solution for this problem is to check every possible rectangle in the given 2D array. This solution requires 6 nested loops –  

4 for start and end coordinate of the 2 axis O(n4)
and 2 for the summation of the sub-matrix O(n2).
The overall time complexity of this solution would be O(n6).

Efficient Approach – 
Kadane’s algorithm for 1D array can be used to reduce the time complexity to O(n^3). The idea is to fix the left and right columns one by one 
and find the maximum sum contiguous rows for every left and right column pair.

 * @author rajeevkumar.pal
 *
 */
public class MaximumSumRectangleInA2DMatrixDP {

	static class Top{
		int top;
	}
	static class Down{
		int down;
	}
	public static int kadanes(int[] arr,Top t,Down d){
		int curSum,maxSum=arr[0],prevSum=arr[0];
		t.top=0;d.down=0;
		for(int i=1;i<arr.length;i++){
			curSum=arr[i];
			if((curSum+prevSum)<=curSum &&(maxSum<=curSum)){
				maxSum=curSum;prevSum=curSum;
				t.top=i;d.down=i;
			}
			else if((curSum+prevSum)<=prevSum || (curSum+prevSum)<maxSum){
				prevSum=(curSum+prevSum);
			}
			else {
				d.down=i;
				prevSum=curSum+prevSum;
				maxSum=prevSum;
			}
		}
		return maxSum;
	}
	public static void findMaxSum(int[][] arr,int M,int N){
		int[] dp=new int[M];
		Top t=new Top();
			t.top=0;
		Down d=new Down();
		d.down=0;
		int currMaxSum=0;
		int globalMaxSum=0;
		
		int finalLeft =0;
		int finalRight = 0;
		int finalTop = 0;
		int finalBottom = 0;
		for(int left=0;left<N;left++){
			Arrays.fill(dp,0);
			for(int right=left;right<N;right++){
				
				for(int row=0;row<M;row++){
					dp[row]+=arr[row][right];
				}
				
				currMaxSum=kadanes(dp, t, d);
				
				if(globalMaxSum<currMaxSum){
					globalMaxSum=currMaxSum;
					 finalLeft = left;
		             finalRight = right;
		             finalTop = t.top;
		             finalBottom = d.down;
				}
				
				System.out.println("finalLeft:"+finalLeft+": finalRight :"+finalRight+": finalTop :"+finalTop+":finalBottom:"+finalBottom);
				System.out.println();
			}
		}
		
		System.out.println("Maximum Sum is:"+globalMaxSum);
		System.out.println("TopLeft:"+finalLeft+" TopRight:"+finalTop);
		System.out.println("DownLeft:"+finalRight+" DownRight:"+finalBottom);
		
		// for 1D sub arra
	}
	
	 // Function to find maximum sum rectangular
    // submatrix
    private static int maxSumRectangle(int[][] mat)
    {
        int m = mat.length;
        int n = mat[0].length;
        int preSum[][] = new int[m + 1][n];
 
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                preSum[i + 1][j] =
                   preSum[i][j] + mat[i][j];
            }
        }
 
        int maxSum = -1;
        int minSum = Integer.MIN_VALUE;
        int negRow = 0, negCol = 0;
        int rStart = 0, rEnd = 0, cStart = 0, cEnd = 0;
        for (int rowStart = 0;
             rowStart < m;
             rowStart++)
        {
            for (int row = rowStart; row < m; row++)
            {
                int sum = 0;
                int curColStart = 0;
                for (int col = 0; col < n; col++)
                {
                    sum += preSum[row + 1][col]
                           - preSum[rowStart][col];
                    if (sum < 0) {
                        if (minSum < sum) {
                            minSum = sum;
                            negRow = row;
                            negCol = col;
                        }
                        sum = 0;
                        curColStart = col + 1;
                    }
                    else if (maxSum < sum)
                    {
                        maxSum = sum;
                        rStart = rowStart;
                        rEnd = row;
                        cStart = curColStart;
                        cEnd = col;
                    }
                }
            }
        }
 
        // Printing final values
        if (maxSum == -1) {
            System.out.println("from row - " + negRow
                               + " to row - " + negRow);
            System.out.println("from col - " + negCol
                               + " to col - " + negCol);
        }
        else {
            System.out.println("from row - " + rStart
                               + " to row - " + rEnd);
            System.out.println("from col - " + cStart
                               + " to col - " + cEnd);
        }
        return maxSum == -1 ? minSum : maxSum;
    }
    
 // Function to find maximum sum submatrix
    static void maxSubmatrixSum(int[][] matrix)
    {
       
        // Stores the number of rows
        // and columns in the matrix
        int r = matrix.length;
        int c = matrix[0].length;
     
        // Stores maximum submatrix sum
        int maxSubmatrix = 0;
     
        // Take each row as starting row
        for (int i = 0; i < r; i++) {
     
            // Take each column as the
            // starting column
            for (int j = 0; j < c; j++) {
     
                // Take each row as the
                // ending row
                for (int k = i; k < r; k++) {
     
                    // Take each column as
                    // the ending column
                    for (int l = j; l < c; l++) {
     
                        // Stores the sum of submatrix
                        // having topleft index(i, j)
                        // and bottom right index (k, l)
                        int sumSubmatrix = 0;
     
                        // Iterate the submatrix
                        // row-wise and calculate its sum
                        for (int m = i; m <= k; m++) {
                            for (int n = j; n <= l; n++) {
                                sumSubmatrix += matrix[m][n];
                            }
                        }
     
                        // Update the maximum sum
                        maxSubmatrix
                            = Math.max(maxSubmatrix,
                                  sumSubmatrix);
                    }
                }
            }
        }
     
        // Print the answer
        System.out.println(maxSubmatrix);
    }
 
    
	public static void main(String[] args) {
		 int[][] M= {	{1, 2, -1, -4, -20},
                 		{-8, -3, 4, 2, 1},
                 		{3, 8, 10, 1, 3},
                 		{-4, -1, 1, 7, -6}
                	};
		 
		 int[][] mat = {
					 		{0, -2, -7, 0 },  
					 		{ 9, 2, -6, 2 }, 
					 		{ -4, 1, -4, 1 }, 
					 		{ -1, 8, 0, -2}
		 				};

		// findMaxSum(M,4,5);
		 
		 maxSumSubMatrix(mat);

	}
	private static void maxSumSubMatrix(int[][] mat) {
		// TODO Auto-generated method stub
		int[] col = new int[2];
		int rl = mat.length;
		int cl = mat[0].length;
		int[] arr = new int[cl];
		int rowst =0;
		int rowed =0;
		int reMax = Integer.MIN_VALUE;
		
		for(int k=0;k<rl;k++) {
			int[] row = new int[cl];
			int start=k;
			for(int i=k;i<rl;i++) {
				
				for(int j=0;j<cl;j++) {
					row[j] +=mat[i][j];
				}
				
				int[] subarr = new int[2];
				int currMax = MaxSubArray(row, subarr);
				if(reMax<currMax) {
					rowst = start;
					rowed=i;
					reMax = currMax;
					col = subarr;
				}
			}
		}
		System.out.println("row start "+rowst+" end "+rowed);
		System.out.println("col start "+col[0]+" end "+col[1]);
	}
	
	public static int MaxSubArray(int[] arr ,int[] subarr) {
		int start =0;
		int end = 0;
		int maxSum = Integer.MIN_VALUE;
		int currsum=arr[0];
		
		int s=0;
		for(int i=1;i<arr.length;i++) {
			if(arr[i]+currsum > arr[i]) {
				currsum +=arr[i];
			}else {
				s=i;
				currsum =arr[i];
			}
			
			if(maxSum <currsum) {
				start =s;
				end=i;
				maxSum = currsum;
			}
		}
		subarr[0] = start;
		subarr[1] = end;
		return maxSum;
	}
}
