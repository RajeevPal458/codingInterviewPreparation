package gfg.matrix;

import java.util.Stack;

public class LargestRectangularAreaInHistogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int[] arr ={6, 2, 5, 4, 5, 1, 6};
        
        maxRectangularArea(arr);
        
	}

	private static void maxRectangularArea(int[] arr) {
		// TODO Auto-generated method stub
		int n=arr.length;
		int maxRactangle=0;
		Stack<Integer> stack = new Stack<Integer>();
		int i=0;
		while (i<n) {
			
			if (stack.isEmpty() || arr[stack.peek()] <= arr[i]) {
				stack.push(i++);
			}else {
				int top = stack.pop();
				int currBarRactangle = arr[top] * (stack.isEmpty()?i:i-stack.peek()-1);
				if(currBarRactangle > maxRactangle) {
					maxRactangle = currBarRactangle;
				}
			}
			
		}
		
		while (!stack.isEmpty()) {
			int top = stack.pop();
			int currBarRactangle = arr[top] * (stack.isEmpty()?i:i-stack.peek()-1);
			if(currBarRactangle > maxRactangle) {
				maxRactangle = currBarRactangle;
			}
		}
		
		System.out.println(maxRactangle);
	}
	

}
