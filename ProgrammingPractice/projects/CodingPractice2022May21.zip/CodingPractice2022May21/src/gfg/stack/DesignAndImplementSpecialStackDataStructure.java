package gfg.stack;

/**
 * Design and Implement Special Stack Data Structure | Added Space Optimized Version
 * https://www.geeksforgeeks.org/design-and-implement-special-stack-data-structure/
 * Question: Design a Data Structure SpecialStack that supports all the stack operations like 
 * push(), pop(), isEmpty(), isFull() and an additional operation getMin() which should return minimum element from the SpecialStack.
 *  All these operations of SpecialStack must be O(1). To implement SpecialStack, you should only use standard Stack data structure and 
 *  no other data structure like arrays, list, . etc. 


 * @author rajeevkumar.pal
 *
 */
public class DesignAndImplementSpecialStackDataStructure {

}
