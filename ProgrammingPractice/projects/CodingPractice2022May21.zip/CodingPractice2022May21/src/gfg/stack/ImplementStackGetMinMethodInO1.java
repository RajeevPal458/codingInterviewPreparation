package gfg.stack;

import java.util.Stack;

/**
 * https://www.geeksforgeeks.org/design-a-stack-that-supports-getmin-in-o1-time-and-o1-extra-space/
 * 
 * @author rajeevkumar.pal
 *
 */
//Java implementation of SpecialStack
//Note : here we use Stack class for
//Stack implementation

import java.util.Stack;

/* A class that supports all the
stack operations and one additional
operation getMin() that returns
the minimum element from stack at
any time. This class inherits from
the stack class and uses an
auxiliary stack that holds minimum
elements */

class SpecialStack extends Stack<Integer> {
	Stack<Integer> min = new Stack<>();

	/* SpecialStack's member method to
insert an element to it. This method
	makes sure that the min stack is
also updated with appropriate minimum
	values */
	void push(int x)
	{
		if (isEmpty() == true) {
			super.push(x);
			min.push(x);
		}
		else {
			super.push(x);
			int y = min.pop();
			min.push(y);
			if (x < y)
				min.push(x);
			else
				min.push(y);
		}
	}

	/* SpecialStack's member method to
insert an element to it. This method
	makes sure that the min stack is
also updated with appropriate minimum
	values */
	public Integer pop()
	{
		int x = super.pop();
		min.pop();
		return x;
	}

	/* SpecialStack's member method to get
minimum element from it. */
	int getMin()
	{
		int x = min.pop();
		min.push(x);
		return x;
	}

	/* Driver program to test SpecialStack
methods */
	public static void main(String[] args)
	{
		SpecialStack s = new SpecialStack();
		s.push(10);
		s.push(20);
		s.push(30);
		System.out.println(s.getMin());
		s.push(5);
		System.out.println(s.getMin());
	}
}
//This code is contributed by Sumit Ghosh


public class ImplementStackGetMinMethodInO1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MinStack s=new ImplementStackGetMinMethodInO1().new MinStack();
	      s.push(-1);
	      s.push(10);
	      s.push(-4);
	      s.push(0);
	      System.out.println(s.getMin());
	      System.out.println(s.pop());
	      System.out.println(s.pop());
	      System.out.println(s.getMin());
	}
	
	class MinStack {
	    Stack<Node> s;
	      
	    class Node{
	        int val;
	        int min;
	        public Node(int val,int min){
	            this.val=val;
	            this.min=min;
	              
	        }
	          
	    }
	  
	    /** initialize your data structure here. */
	    public MinStack() {
	        this.s=new Stack<Node>();
	    }
	    public void push(int x) {
	        if(s.isEmpty()){
	            this.s.push(new Node(x,x));
	        }else{
	            int min=Math.min(this.s.peek().min,x);
	            this.s.push(new Node(x,min));
	        }    
	    }   
	    public int pop() {
	      
	            return this.s.pop().val;   
	    }
	    public int top() {
	          
	            return this.s.peek().val;   
	    }
	     public int getMin() {
	          
	            return this.s.peek().min;    
	    }
	}
	  

}
