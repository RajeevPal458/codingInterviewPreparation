package gfg.stack;

import java.util.ArrayDeque;
import java.util.Deque;

public class CheckForBalancedBrackets {

	// Function to check
	// if parentheses are balanced
	public static boolean isBalanced(String exp)
	{
	     
	    // Initialising variables
	    boolean flag = true;
	    int count = 0;
	     
	    // Traversing the expression
	    for(int i = 0; i < exp.length(); i++)
	    {
	        if (exp.charAt(i) == '(')
	        {
	            count++;
	        }
	        else
	        {
	             
	            // It is a closing parenthesis
	            count--;
	        }
	        if (count < 0)
	        {
	             
	            // This means there are
	            // more Closing parenthesis
	            // than opening ones
	            flag = false;
	            break;
	        }
	    }
	     
	    // If count is not zero,
	    // It means there are
	    // more opening parenthesis
	    if (count != 0)
	    {
	        flag = false;
	    }
	    return flag;
	}
	
	// function to check if brackets are balanced
    static boolean areBracketsBalanced(String expr)
    {
        // Using ArrayDeque is faster than using Stack class
        Deque<Character> stack
            = new ArrayDeque<Character>();
 
        // Traversing the Expression
        for (int i = 0; i < expr.length(); i++)
        {
            char x = expr.charAt(i);
 
            if (x == '(' || x == '[' || x == '{')
            {
                // Push the element in the stack
                stack.push(x);
                continue;
            }
 
            // If current character is not opening
            // bracket, then it must be closing. So stack
            // cannot be empty at this point.
            if (stack.isEmpty())
                return false;
            char check;
            switch (x) {
            case ')':
                check = stack.pop();
                if (check == '{' || check == '[')
                    return false;
                break;
 
            case '}':
                check = stack.pop();
                if (check == '(' || check == '[')
                    return false;
                break;
 
            case ']':
                check = stack.pop();
                if (check == '(' || check == '{')
                    return false;
                break;
            }
        }
 
        // Check Empty Stack
        return (stack.isEmpty());
    }
	 
	// Driver code
	public static void main(String[] args)
	{
	    String exp1 = "((()))()()";
	     
	    if (isBalanced(exp1))
	        System.out.println("Balanced");
	    else
	        System.out.println("Not Balanced");
	     
	    String exp2 = "())((())";
	     
	    if (isBalanced(exp2))
	        System.out.println("Balanced");
	    else
	        System.out.println("Not Balanced");
	}
}
