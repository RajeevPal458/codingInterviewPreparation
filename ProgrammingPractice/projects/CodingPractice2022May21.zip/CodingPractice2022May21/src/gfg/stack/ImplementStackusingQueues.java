package gfg.stack;

/**
 * https://www.geeksforgeeks.org/implement-stack-using-queue/
 * @author rajeevkumar.pal
 *
 */
public class ImplementStackusingQueues {

}
