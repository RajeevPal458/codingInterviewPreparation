package gfg.custom.collection.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 
 * class BoundedBlockingQueue {
    private List<Integer> queue;
    private int capacity;
    public BoundedBlockingQueue(int capacity) {
        this.capacity = capacity;
        this.queue = new LinkedList<>();
    }

    public synchronized void enqueue(int element) throws InterruptedException {
        while(this.size() == capacity) wait();
        queue.add(element);
        notifyAll();
    }

    public synchronized int dequeue() throws InterruptedException {
        while(queue.isEmpty()) wait();
        int res = queue.remove(0);
        notifyAll();
        return res;
    }

    public int size() {
        return queue.size();
    }
}
 * @author rajeevkumar.pal
 *
 *
 *import java.util.*;
 2 
 3 class BoundedBlockingQueue {
 4     private ReentrantLock lock = new ReentrantLock();
 5     private Condition full = lock.newCondition();
 6     private Condition empty = lock.newCondition();
 7     private int [] que;
 8     private int head = 0;
 9     private int tail = 0;
10     private int size = 0;
11     
12     public BoundedBlockingQueue(int capacity) {
13         que = new int[capacity];    
14     }
15     
16     public void enqueue(int element) throws InterruptedException {
17         lock.lock();
18         try{
19             while(size == que.length){
20                 full.await();
21             }
22             
23             que[tail++] = element;
24             tail %= que.length;
25             size++;
26             empty.signal();
27         }finally{
28             lock.unlock();
29         }
30     }
31     
32     public int dequeue() throws InterruptedException {
33         lock.lock();
34         try{
35             while(size == 0){
36                 empty.await();
37             }
38             
39             int res = que[head++];
40             head %= que.length;
41             size--;
42             full.signal();
43             return res;
44         }finally{
45             lock.unlock();
46         }
47     }
48     
49     public int size() {
50         lock.lock();
51         try{
52             return this.size;
53         }finally{
54             lock.unlock();
55         }
56     }
57 }
 */
public class ArrayBlockingQueueImpl {

	private BlockingQueue<String> queue=null;
	private Object[] itemArr = null; 
	private int rear = -1;
	private int front= -1;
	private int capecity ;
	public ArrayBlockingQueueImpl(int capecity) {
		itemArr = new Object[capecity];
		this.capecity = capecity;
	}
	
	public String peek() {
		String value="";
		try {
			synchronized (this) {
				if(front==capecity) {
					front =-1;
					rear = -1;
				}
				while (front==-1) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				value =(String)itemArr[front];
				this.notifyAll();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}
	
	public  boolean add(String value) {
		boolean flag = true;
		try {
			synchronized (this) {
				if(rear==capecity-1 && front == capecity) {
					front =-1;
					rear=-1;
				}
				while (rear==capecity-1) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				if(front==-1) {
					front=0;
				}
				rear = rear+1;
				itemArr[rear] = value;
				
				this.notifyAll();
			}
		} catch (Exception e) {
			flag=false;
			e.printStackTrace();
		}
			
		return flag;
	}

	public String take() {
		
		String val ="";
		try {
			synchronized (this) {
				
				while (front==-1||front==rear+1) {
					try {
						this.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				val = (String)itemArr[front];
				itemArr[front] = -1;
				front = front+1;
				this.notifyAll();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return val;
	}
	
	static class Response{
		String result;
		String operation;
		
		public Response() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Response(String result, String operation) {
			super();
			this.result = result;
			this.operation = operation;
		}
		public String getResult() {
			return result;
		}
		public void setResult(String result) {
			this.result = result;
		}
		public String getOperation() {
			return operation;
		}
		public void setOperation(String operation) {
			this.operation = operation;
		}
		
	}
	
	public static void main(String[] args) {
		ArrayBlockingQueueImpl queue = new ArrayBlockingQueueImpl(12);
		ExecutorService service =Executors.newCachedThreadPool();
		List<Future<Response>> resList = new ArrayList<Future<Response>>();
		try {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					while (true) {
						double rand = Math.random();
						
						boolean flag =queue.add(rand+"");
						System.out.println("Adding to queue:-"+flag);
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}).start();
			
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					while (true) {
						String val =queue.peek();
						System.out.println("get from queue:-"+val);
						try {
							Thread.sleep(3000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}).start();
			
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					while (true) {
						String val =queue.take();
						System.out.println("remove from queue:-"+val);
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}).start();

		} catch (Exception e) {
			System.err.println("exception on submit multiple request :-"+e);
		}finally {
			service.shutdown();
		}
		
		for(Future<Response> res:resList) {
			try {
				Response response = res.get();
				System.out.println(response.getResult()+"  -- "+response.getOperation());
				System.out.println("-----------");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	
	
	
	
}
