package gfg.custom.collection.impl;

import java.util.Map;

import gfg.custom.collection.impl.MyLinkedHashMapArr.CounterCell;
import gfg.custom.collection.impl.MyLinkedHashMapArr.ForwardingNode;
import gfg.custom.collection.impl.MyLinkedHashMapArr.Node;

public class LinkedHashMapArray {



class MyLinkedHashMapArr {
	static final int MOVED     = -1; // hash for forwarding nodes
    static final int TREEBIN   = -2; // hash for roots of trees
    static final int RESERVED  = -3; // hash for transient reservations
    static final int HASH_BITS = 0x7fffffff; // usable bits of normal node hash
	
    /**
     * The array of bins. Lazily initialized upon first insertion.
     * Size is always a power of two. Accessed directly by iterators.
     */
    transient volatile Node<Object,Object>[] table;

    /**
     * The next table to use; non-null only while resizing.
     */
    private transient volatile Node<Object,Object>[] nextTable;

    /**
     * Base counter value, used mainly when there is no contention,
     * but also as a fallback during table initialization
     * races. Updated via CAS.
     */
    private transient volatile long baseCount;

    /**
     * Table initialization and resizing control.  When negative, the
     * table is being initialized or resized: -1 for initialization,
     * else -(1 + the number of active resizing threads).  Otherwise,
     * when table is null, holds the initial table size to use upon
     * creation, or 0 for default. After initialization, holds the
     * next element count value upon which to resize the table.
     */
    private transient volatile int sizeCtl;

    /**
     * The next table index (plus one) to split while resizing.
     */
    private transient volatile int transferIndex;

    /**
     * Spinlock (locked via CAS) used when resizing and/or creating CounterCells.
     */
    private transient volatile int cellsBusy;

    /**
     * Table of counter cells. When non-null, size is a power of 2.
     */
    private transient volatile CounterCell[] counterCells;
    
	static class Node<Object,Object>{
		final int hash;
        final Object key;
        volatile Object val;
        volatile Node<Object,Object> next;

        Node(int hash, Object key, Object val, Node<Object,Object> next) {
            this.hash = hash;
            this.key = key;
            this.val = val;
            this.next = next;
        }

        public final Object getKey()       { return key; }
        public final Object getValue()     { return val; }
        public final int hashCode()   { return key.hashCode() ^ val.hashCode(); }
        public final String toString(){ return key + "=" + val; }
        public final Object setValue(Object value) {
            throw new UnsupportedOperationException();
        }
        

        /**
         * Virtualized support for map.get(); overridden in subclasses.
         */
        Node<Object,Object> find(int h, Object k) {
            Node<Object,Object> e = this;
            if (k != null) {
                do {
                	Object ek;
                    if (e.hash == h &&
                        ((ek = e.key) == k || (ek != null && k.equals(ek))))
                        return e;
                } while ((e = e.next) != null);
            }
            return null;
        }
	}
	
	static final int spread(int h) {
        return (h ^ (h >>> 16)) & HASH_BITS;
    }
	
	public Object get(Object key) {
		 int h = spread(key.hashCode());
		 Node<Object,Object>[] tab;
		 Node<Object,Object> e = table[h];
		 int eh;
		 Node<Object,Object> p;
		 Object ek;
		 int n;
	        if ( (tab = table) != null && (n = tab.length) > 0 && e!=null ) {
	            if ((eh = e.hash) == h) {
	                if ((ek = e.key) == key || (ek != null && key.equals(ek)))
	                    return e.val;
	            }
	            else if (eh < 0)
	                return (p = e.find(h, key)) != null ? p.val : null;
	            while ((e = e.next) != null) {
	                if (e.hash == h &&
	                    ((ek = e.key) == key || (ek != null && key.equals(ek))))
	                    return e.val;
	            }
	        }
	        return null;
	    }
	
	public boolean containsKey(Object key) {
        return get(key) != null;
    }
	
	/**
     * Maps the specified key to the specified value in this table.
     * Neither the key nor the value can be null.
     *
     * <p>The value can be retrieved by calling the {@code get} method
     * with a key that is equal to the original key.
     *
     * @param key key with which the specified value is to be associated
     * @param value value to be associated with the specified key
     * @return the previous value associated with {@code key}, or
     *         {@code null} if there was no mapping for {@code key}
     * @throws NullPointerException if the specified key or value is null
     */
    public Object put(Object key, Object value) {
        return putVal(key, value, false);
    }

    /** Implementation for put and putIfAbsent */
    final Object putVal(Object key, Object value, boolean onlyIfAbsent) {
    	
        if (key == null || value == null) throw new NullPointerException();
        
        int hash = spread(key.hashCode());
        
        int binCount = 0;
        
        for (Node<Object,Object>[] tab = table;;) {
        	Node<Object,Object> f = (tab==null)?null:tab[hash]; int n, i = (n - 1) & hash, fh;
            if (tab == null || (n = tab.length) == 0)
                tab = initTable();
            else if ((f) == null) {
                    break;                   // no lock when adding to empty bin
            }
            else if ((fh = f.hash) == MOVED)
                tab = helpTransfer(tab, f);
            else {
            	Object oldVal = null;
                synchronized (f) {
                    if (tabAt(tab, i) == f) {
                        if (fh >= 0) {
                            binCount = 1;
                            for (Node<Object,Object> e = f;; ++binCount) {
                                K ek;
                                if (e.hash == hash &&
                                    ((ek = e.key) == key ||
                                     (ek != null && key.equals(ek)))) {
                                    oldVal = e.val;
                                    if (!onlyIfAbsent)
                                        e.val = value;
                                    break;
                                }
                                Node<Object,Object> pred = e;
                                if ((e = e.next) == null) {
                                    pred.next = new Node<Object,Object>(hash, key,
                                                              value, null);
                                    break;
                                }
                            }
                        }
                        else if (f instanceof TreeBin) {
                            Node<Object,Object> p;
                            binCount = 2;
                            if ((p = ((TreeBin<Object,Object>)f).putTreeVal(hash, key,
                                                           value)) != null) {
                                oldVal = p.val;
                                if (!onlyIfAbsent)
                                    p.val = value;
                            }
                        }
                    }
                }
                if (binCount != 0) {
                    if (binCount >= TREEIFY_THRESHOLD)
                        treeifyBin(tab, i);
                    if (oldVal != null)
                        return oldVal;
                    break;
                }
            }
        }
        addCount(1L, binCount);
        return null;
    }

    /**
     * Copies all of the mappings from the specified map to this one.
     * These mappings replace any mappings that this map had for any of the
     * keys currently in the specified map.
     *
     * @param m mappings to be stored in this map
     */
    public void putAll(Map<? extends K, ? extends V> m) {
        tryPresize(m.size());
        for (Map.Entry<? extends K, ? extends V> e : m.entrySet())
            putVal(e.getKey(), e.getValue(), false);
    }
	
    
    private final Node<Object,Object>[] initTable() {
    	Node<Object,Object>[] tab; int sc;
        while ((tab = table) == null || tab.length == 0) {
            if ((sc = sizeCtl) < 0)
                Thread.yield(); // lost initialization race; just spin
            else if (U.compareAndSwapInt(this, SIZECTL, sc, -1)) {
                try {
                    if ((tab = table) == null || tab.length == 0) {
                        int n = (sc > 0) ? sc : DEFAULT_CAPACITY;
                        @SuppressWarnings("unchecked")
                        Node<Object,Object>[] nt = (Node<Object,Object>[])new Node<?,?>[n];
                        table = tab = nt;
                        sc = n - (n >>> 2);
                    }
                } finally {
                    sizeCtl = sc;
                }
                break;
            }
        }
        return tab;
    }
    
    static final class CounterCell {
        volatile long value;
        CounterCell(long x) { value = x; }
    }

    final long sumCount() {
        CounterCell[] as = counterCells; CounterCell a;
        long sum = baseCount;
        if (as != null) {
            for (int i = 0; i < as.length; ++i) {
                if ((a = as[i]) != null)
                    sum += a.value;
            }
        }
        return sum;
    }
    
    final Node<Object,Object>[] helpTransfer(Node<Object,Object>[] tab, Node<Object,Object> f) {
        Node<Object,Object>[] nextTab; int sc;
        if (tab != null && (f instanceof ForwardingNode) &&
            (nextTab = ((ForwardingNode<Object,Object>)f).nextTable) != null) {
            int rs = resizeStamp(tab.length);
            while (nextTab == nextTable && table == tab &&
                   (sc = sizeCtl) < 0) {
                if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                    sc == rs + MAX_RESIZERS || transferIndex <= 0)
                    break;
                if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1)) {
                    transfer(tab, nextTab);
                    break;
                }
            }
            return nextTab;
        }
        return table;
    }
    
    final class ForwardingNode<Object,Object> extends Node<Object,Object> {
        final Node<Object,Object>[] nextTable;
        ForwardingNode(Node<Object,Object>[] tab) {
            super(MOVED, null, null, null);
            this.nextTable = tab;
        }
    }
}
