package gfg.custom.collection.impl;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ConcurrentHashMap.CounterCell;
import java.util.concurrent.ConcurrentHashMap.ForwardingNode;
import java.util.concurrent.ConcurrentHashMap.Node;
import java.util.concurrent.ConcurrentHashMap.Traverser;
import java.util.concurrent.ConcurrentHashMap.TreeBin;

import gfg.hashtable.ConcurrentHashTableUsingArray;

/**
 * If thread-safety is required and list scans can be tolerated, use Java's 
 * ConcurrentLinkedQueue and HashTable.
 * 
 * class LRUCache {
    class Node {
        int key;
        int value;
        Node next;
        Node prev;
        
        public Node(int key, int value) {
            this.key = key;
            this.value = value;
            next = null;
            prev = null;
        }
    }
    
    private ConcurrentHashMap<Integer, Node> map;
    private AtomicInteger size;
    private int capacity;
    private Node head, tail;
    private ReentrantLock lock;
    
    public LRUCache(int capacity) {
        map = new ConcurrentHashMap<>();
        size = new AtomicInteger();
        this.capacity = capacity;
        head = new Node(0, 0);
        tail = new Node(0, 0);
        head.prev = tail;
        tail.next = head;
        lock = new ReentrantLock();
    }
    
    public int get(int key) {
        if (map.containsKey(key)) {
            Node node = map.get(key);
            removeNode(key);
            addNode(key, node.value);
            return node.value;
        } else {
            return -1;
        }
    }
    
    public void put(int key, int value) {
        if (map.containsKey(key)) {
            removeNode(key);
            addNode(key, value);
        } else {
            addNode(key, value);
        }
    }
    
    // Remove the Node from DLL
    private void removeNode(int key) {
        lock.lock();
        try {
            Node node = map.get(key);
            node.prev.next = node.next;
            node.next.prev = node.prev;

            size.decrementAndGet(); 
            map.remove(node.key);
        } finally {
            lock.unlock();
        }
    }
    
    // Add the Node at the head of DLL
    private void addNode(int key, int value) {
        lock.lock();
        try {
            Node node = new Node(key, value);

            node.prev = head.prev;
            head.prev = node;
            node.prev.next = node;
            node.next = head;

            map.put(key, node);
            size.incrementAndGet(); 
            if (size.get() > capacity) {
                removeNode(tail.next.key);
            }
        } finally {
            lock.unlock();
        }
    }
}

**
 * Your LRUCache object will be instantiated and called as such:
 * LRUCache obj = new LRUCache(capacity);
 * int param_1 = obj.get(key);
 * obj.put(key,value);
 *
 * @author rajeevkumar.pal
 *
 */


/**
 * class LRUCache {
    
    // Double ended list Node
    class DeListNode {
        int key;
        int value;
        DeListNode prev;
        DeListNode next;
    }

    private final AtomicInteger size;
    private final int capacity;

    // It can be generalised too
    private final Map<Integer, DeListNode> cache;
    
    // Head and Tail of the DLL
    private final DeListNode head;
    private final DeListNode tail;
    
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    
    public LRUCache(int capacity) {
        this.capacity = capacity;
        this.size = new AtomicInteger();
        this.cache = new ConcurrentHashMap<>();
        this.head = new DeListNode();
        this.tail = new DeListNode();
        this.head.next = tail;
        this.tail.prev = head;
    }
    
    public int get(int key) {
        this.lock.readLock().lock();
        DeListNode node = cache.getOrDefault(key, null);
        this.lock.readLock().unlock();

        if (node != null) {
            // moving the key to the front of the DLL
            moveToHead(node);
            return node.value;
        }

        return -1;
    }
    
    public void put(int key, int value) {
        this.lock.readLock().lock();
        DeListNode currNode = cache.get(key);
        this.lock.readLock().unlock();
        if (currNode != null) {
            currNode.value = value;
            moveToHead(currNode);
            return;
        }

        DeListNode node = new DeListNode();
        node.key = key;
        node.value = value;
        cache.put(key, node);
        addToHead(node);

        if (size.incrementAndGet() > this.capacity) {
            DeListNode nodeToRemove = this.tail.prev;
            removeNode(nodeToRemove);
            cache.remove(nodeToRemove.key);
            size.decrementAndGet();
        }
    }
    
    private void removeNode(final DeListNode node) {
        this.lock.writeLock().lock();
        try {
            DeListNode prev = node.prev;
            DeListNode next = node.next;
            
            prev.next = next;
            next.prev = prev;
        } finally {
            this.lock.writeLock().unlock();
        }
    }
    
    private void addToHead(final DeListNode node) {
        this.lock.writeLock().lock();
        try {
            node.prev = this.head;
            node.next = this.head.next;
            
            this.head.next.prev = node;
            this.head.next = node;
        } finally {
            this.lock.writeLock().unlock();
        }
    }
    
    private void moveToHead(final DeListNode node) {
        removeNode(node);
        addToHead(node);
    }
}
 * @author rajeevkumar.pal
 *
 */

/**
 * This is a classic design problem. While the overall approach is not too complex, but I think the interviewer wants to see how we approach the problem, and why we choose the data structures.
Best way to execute the problem is break it down to several functions so that the public functions end up being simple. This way we are writing small segments of testable code, and it is also easier to catch mistakes during programming. This also helps if we are short of time, we can just say what a function does and move on (if the interviewer thinks that is okay).

Another comment: the eviction logic can be kept simple, if we first insert the value and then execute eviction as an optional step depending on the current cache size.

The operations should all take constant time, and space is O(n), linearly proportional to the input size.

Commented code below.

class LRUCache {
    // A double link list fits our purpose since we can
    // adjust the list (insert/delete) from any node with constant time complexity
    class Node {
        int key;
        int val;
        Node next;
        Node prev;
        
        public Node(int key, int val) {
            this.key = key;
            this.val = val;
            next = null;
            prev = null;
        }
    }
    
    // This map contains reference to node corresponding to a given key
    // Helps us search in the node in const time
    // We also track size of the cache with size of the map itself
    Map<Integer, Node> keyMap;
    // Initially these two nodes point to each other
    Node first; // Sentinel first node
    Node last; // Sentinel last node
    final int capacity; // Capacity of the cache
    
    // Any key inserted will be inserted at the FRONT of the list
    private Node insertAtFront(int key, int val) {
        Node node = new Node(key, val);
        // This node needs to point to the first sentinel node
        // Also, it points to the node that the first sentinel node
        // currently points at
        // Same adjustment needs to be made to the node it is now pointing to
        // Then the first sentinel node will point to this node
        
        Node temp = first.next;
        first.next = node;
        node.prev = first;
        node.next = temp;
        temp.prev = node;
        return node;
        
    }
    
    // Any key accessed will need to be moved to the FRONT of the list
    private void moveToFront(Node node) {
        // Here, we do total 6 adjustments
        // Node needs to point to the first sentinel node and vice-versa
        // Node points to the node first sentinel was pointing to and vice-versa
        // What node pointed to "before" will point to what was after the node, and vice-versa
        node.prev.next = node.next;
        node.next.prev = node.prev;
        Node temp = first.next;
        first.next = node;
        node.prev = first;
        node.next = temp;
        temp.prev = node;
    }
    
    // If the cache is full, then a node will need to be EVICTED
    private Node deleteFromLast() {
        if (last.prev == first) {
            // Safety check: do not delete sentinel nodes!
            return null;
        }
        Node node = last.prev;
        node.prev.next = last;
        last.prev = node.prev;
        return node;
    }
    
    public LRUCache(int capacity) {
        this.capacity = capacity;
        keyMap = new HashMap<>();
        first = new Node(-1, -1);
        last = new Node(-1, -1);
        first.next = last;
        last.prev = first;
    }
    
    public int get(int key) {
        // Use hashtable to access the node in O(1) complexity
        if (!keyMap.containsKey(key)) {
            return -1;
        }
        Node node = keyMap.get(key);
        // Since the node is accessed, needs to be moved to front
        moveToFront(node);
        return node.val;
    }
    
    public void put(int key, int value) {
        // Update the LinkList and Hashtable
        if (keyMap.containsKey(key)) {
            // Node exists, so same as access
            Node node = keyMap.get(key);
            node.val = value;
            moveToFront(node);
        }
        else {
            // New node needs to be created
            keyMap.put(key, insertAtFront(key, value));
        }
        
        // Evict a node if necessary
        if (keyMap.size() > capacity) {
            Node node = deleteFromLast();
            keyMap.remove(node.key);
        }
    }
}
 * @author rajeevkumar.pal
 *
 */


/**
 * 
 * LRU cache. When cache is full, evict stalest entry.
 * 
 * Phones - cache of files...a cache miss could mean an expensive network call. 
 * 
 * The cache itself is a doubly linked list where items at the tail get evicted first.
 * So new items are inserted into the head of the list.
 * 
 * Need a hash table mapping keys to Nodes for quick lookup.
 * 
 * Can't use java's LinkedList because for efficient removal we must update pointers
 * directly on Nodes returned from the map.
 * 
 * If thread-safety is required and list scans can be tolerated, use Java's 
 * ConcurrentLinkedQueue and HashTable.
 *
public class LRUCache {
	private Map<Integer, Node> map;
	private Node head; // dummy "fence" head
	private Node tail; // dummy "fence" tail
	private int capacity;

	public LRUCache(int capacity) {
		this.capacity = capacity;
		map = new HashMap<Integer, Node>();
		head = new Node(-1, -1);
		tail = new Node(-1, -1);
		head.next = tail; 
		tail.prev = head; 
	}
	
	public int get(int key) {
		if( !map.containsKey(key) ) {
			return -1;
		}
		Node n = map.get(key);
		promoteToHead(n);
		return n.val;
	}
	
	public void set(int key, int value) {
		Node n;
		// update existing Node; does not alter cache size
		if( map.containsKey(key) ) {
			n = map.get(key);
			n.val = value;   // map.get(n.key) will now return node with new val
			promoteToHead(n);
			
			return;
		}
		if( map.size() == capacity ) {
			Node last = tail.prev;
			map.remove(last.key);
			remove(last);
		}
		n = new Node(key, value);
		addFirst(n);
		map.put(key, n);
	}


	private void promoteToHead(Node n) {
		if( head != n ) {
			remove(n);
			addFirst(n);
		}
	}

	private void remove(Node n) {
		n.prev.next = n.next;
		n.next.prev = n.prev;
	}

	
	private void addFirst(Node n) {
		// first insert looks like:
		//  -1 <-> -1
		//  -1 <-> n <-> -1
		Node temp = head.next;
		head.next = n;
		n.prev = head;
		n.next = temp;
		n.next.prev = n;
	}
	
	public void printCache() throws Exception {
		if( head.next == tail ) {
			throw new Exception("empty cache!");
		}
		Node n = head.next;
		System.out.print("[ ");
		while( n != tail ) {
			System.out.print(n.val + " ");
			n = n.next;
		}
		System.out.println("]");
	}
	
	public class Node {
    	int key;
    	int val;
    	Node prev;
    	Node next;
    		
    	public Node(int key, int val) {
    		this.key = key;
    		this.val = val;
    	}
    }
}
 * @author rajeevkumar.pal
 *
 */
public class MyLinkedHashMap {
	private LinkedHashMap<Integer, Integer> map = new LinkedHashMap<>();
	private ConcurrentHashMap<String, String> conmap;
	private HashMap<String, String> hashmap;
	private Hashtable<String, String> hashtable;
	private ConcurrentSkipListMap<String, String> conskipMap;
	private ConcurrentSkipListSet<String> conskipSet;
	private ConcurrentHashTableUsingArray conhashtable;
	private ConcurrentLinkedDeque<String> conLinedQue;
	private ArrayBlockingQueue<String> arrblockingqueue;
	
	
	int val = -1;// variable to store key value
	int cap;

	public MyLinkedHashMap(int capacity) {
	    cap = capacity;// initializing capacity as cap
	}


	public int get(int key) {
	    
	    if(map.containsKey(key))
	    {
	        val = map.get(key);// storing value of key
	        map.remove(key);// if key found remove & enter key once again as it becomes MRU key
	        map.put(key, val);
	    }
	    else val = -1;
	    return val;
	}

	public void put(int key, int value) {
	    if(!map.containsKey(key))
	    {
	        if(map.size() >= cap)// if size >= cap, remove 1st key & put new key into map
	        {
	            for(Map.Entry<Integer, Integer> mapElement : map.entrySet())// removing 1st key(LRU) from map
	            {
	                map.remove((int)mapElement.getKey());
	                break;
	            }
	        }
	        map.put(key, value);// if !(size >= cap), simply put new key into map
	    }
	    else// if map already contains key then just update new value into key
	    {
	        map.remove(key);
	        map.put(key, value);
	    }
	}
}
}