package gfg.ola.practice.series;

import java.util.Arrays;

public class LargestAppleSequenceByReplacingOsByAs {

	public static void main(String[] args) {
		String arr = "AAOOOAO" ;
		int m=2;
		findLargestSequenceOfAs(arr.toCharArray(),0,m);
		System.out.println(largestSequence(arr.toCharArray()));
	}

	private static void findLargestSequenceOfAs(char[] arr,int i , int m) {
		// TODO Auto-generated method stub
		if(i==arr.length)
			return;
		if(m==0) {
			System.out.println(largestSequence(arr)+"::"+Arrays.toString(arr));
			return;
		}
		
		findLargestSequenceOfAs(arr,i+1 ,m);
		
		if(arr[i]=='O') {
			arr[i] ='A';
			findLargestSequenceOfAs(arr,i+1, m-1);
			arr[i] ='O';
		}
	}
	//AAOOOAO
	public static int largestSequence(char[] arr) {
		int asMaxlen=Integer.MIN_VALUE;
		int osMaxLen = Integer.MIN_VALUE;
		
		int currAs=0;
		int currOs=0;
		
		for(char ch:arr) {
			if(ch=='A') {
				currAs++;
				if(asMaxlen<currAs) {
					asMaxlen = currAs;
				}
				currOs=0;
			}else {
				currOs++;
				if(osMaxLen<currOs) {
					osMaxLen = currOs;
				}
				currAs=0;
			}
		}
		return (asMaxlen > osMaxLen)?asMaxlen:osMaxLen;
		
	}
}
