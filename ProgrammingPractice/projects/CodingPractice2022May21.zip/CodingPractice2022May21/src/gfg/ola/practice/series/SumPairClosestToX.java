package gfg.ola.practice.series;

import java.util.Arrays;

/**
 * 
 * @author rajeevkumar.pal
 *
 */
public class SumPairClosestToX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N = 6, X = 54;
		int arr[] = {10, 22, 28, 29, 30, 40};
		System.out.println(Arrays.toString(sumClosest(arr,X)));
	}
	
	public static int[] sumClosest(int[] arr, int x) {
	       int[] ans =new int[2];
	       int low=0,high=arr.length-1,diff=Integer.MAX_VALUE;
	       while(low<high){
	           int currdiff=x-(arr[low]+arr[high]);
	           if(diff>Math.abs(currdiff)){
	               ans[0]=arr[low];
	               ans[1]=arr[high];
	               diff=Math.abs(currdiff);
	           }
	           if(currdiff==0)
	               break;
	           if(currdiff>0)
	               low++;
	           if(currdiff<0)
	               high--;
	       }
	       return ans;
	 }
	
	// Prints the pair with sum closest to x
    static void printClosest(int arr[], int n, int x)
    {
        int res_l=0, res_r=0;  // To store indexes of result pair
  
        // Initialize left and right indexes and difference between
        // pair sum and x
        int l = 0, r = n-1, diff = Integer.MAX_VALUE;
  
        // While there are elements between l and r
        while (r > l)
        {
            // Check if this pair is closer than the closest pair so far
            if (Math.abs(arr[l] + arr[r] - x) < diff)
            {
               res_l = l;
               res_r = r;
               diff = Math.abs(arr[l] + arr[r] - x);
            }
  
            // If this pair has more sum, move to smaller values.
            if (arr[l] + arr[r] > x)
               r--;
            else // Move to larger values
               l++;
        }
  
    System.out.println(" The closest pair is "+arr[res_l]+" and "+ arr[res_r]);
}

	
}
//finding maximum sum of
//a subarray of size k       sliding window 