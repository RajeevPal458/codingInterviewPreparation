package gfg.ola.practice.series;

/**
 * Given Bots of type A and B where bot A can only move left and bot B can move right only 
 * and these can't cross over each other and # sign represented as empty so now convert first String to second.
 * @author rajeevkumar.pal
 *
 */
public class ConvertFirstStringToSecondString {

	public static void main(String[] args) {
		String str1 ="####B#A#";
		String str2 ="##BA####";
		
		int m = str1.length();
		int n = str2.length();
		System.out.println(moveRobots(str1.toCharArray(),str2.toCharArray()));
		
		System.out.println(moveRobots(str1,str2));
		
	}

	static String moveRobots(char[] s1, char[] s2){
        // code here 
        int i=0,j=0,n=s1.length;
        while(i<n && j<n){
            if(s1[i]=='#'){
                i++;
            }
           else if(s2[j]=='#'){
                j++;
            }
             else if(s1[i]!=s2[j]){
                return "No";
            }else if(s1[i]=='B' && s2[j]=='B' && i>j){
                return "No";
            }else if(s1[i]=='A' && s2[j]=='A' && i<j){
                return "No";
            }else{
                i++;
                j++;
            }
        }
        return "Yes";
    }
	
	//String str1 ="####B#A#";
	//String str2 ="##BA####";
	public static String moveRobots(String s1, String s2){
        if(!reduce(s1).equals(reduce(s2)))
            return "No";
        int n=s1.length();
        int c=0;
        for(int i=n-1;i>=0;i--)
        {
            if(s1.charAt(i)=='A')
                c++;
            if(s2.charAt(i)=='A')
                c--;
            if(c<0)
                return "No";
        }
        c=0;
        for(int i=0;i<n;i++)
        {
            if(s1.charAt(i)=='B')
                c++;
            if(s2.charAt(i)=='B')
                c--;
            if(c<0)
                return "No";
        }
        return "Yes";
    }
	
	
	//Minimum number of deletions and insertions to transform one string into another
	/**
	 * Given two strings ‘str1’ and ‘str2’ of size m and n respectively. The task is to remove/delete and insert the minimum number of characters 
	 * from/in str1 to transform it into str2. It could be possible that the same character needs to be removed/deleted from 
	 * one point of str1 and inserted to some another point.
	 * Input : 
		str1 = "heap", str2 = "pea" 
		Output : Minimum Deletion = 2 and Minimum Insertion = 1

Simple Approach:

A simple approach is to consider all subsequences of str1 and for each subsequence calculate minimum deletions and insertions so as to transform it into str2. A very complex method and the time complexity of this solution is exponential.
 

Efficient Approach:

An efficient approach uses the concept of finding the length of the longest common subsequence of the given two sequences.

Algorithm: 

str1 and str2 be the given strings.
m and n be their lengths respectively.
len be the length of the longest common subsequence of str1 and str2
minimum number of deletions minDel = m – len
minimum number of Insertions minInsert = n – len
* @param s1
	 * @return
	 */
	// Returns length of length common
    // subsequence for str1[0..m-1],
    // str2[0..n-1]
    static int lcs(String str1, String str2, int m, int n)
    {
        int L[][] = new int[m + 1][n + 1];
        int i, j;
 
        // Following steps build L[m+1][n+1] in
        // bottom up fashion. Note that L[i][j]
        // contains length of LCS of str1[0..i-1]
        // and str2[0..j-1]
        for (i = 0; i <= m; i++) {
            for (j = 0; j <= n; j++) {
                if (i == 0 || j == 0)
                    L[i][j] = 0;
 
                else if (str1.charAt(i - 1)
                         == str2.charAt(j - 1))
                    L[i][j] = L[i - 1][j - 1] + 1;
 
                else
                    L[i][j] = Math.max(L[i - 1][j],
                                       L[i][j - 1]);
            }
        }
 
        // L[m][n] contains length of LCS
        // for X[0..n-1] and Y[0..m-1]
        return L[m][n];
    }
    int dp[][] =null;
    public int lcs1(String s1, String s2, int i, int j)
    {
        if (i == 0 || j == 0) {
            return 0;
        }
        if (dp[i][j] != -1) {
            return dp[i][j];
        }
        if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
            return dp[i][j] = 1 + lcs(s1, s2, i - 1, j - 1);
        }
        else {
            return dp[i][j] = Math.max(lcs(s1, s2, i, j - 1),
                                  lcs(s1, s2, i - 1, j));
        }
    }
 
    // function to find minimum number
    // of deletions and insertions
    static void printMinDelAndInsert(String str1,
                                     String str2)
    {
        int m = str1.length();
        int n = str2.length();
 
        int len = lcs(str1, str2, m, n);
 
        System.out.println("Minimum number of "
                           + "deletions = ");
        System.out.println(m - len);
 
        System.out.println("Minimum number of "
                           + "insertions = ");
        System.out.println(n - len);
    }
 
    // Driver code
    public static void main1(String[] args)
    {
        String str1 = new String("heap");
        String str2 = new String("pea");
       
          // Function Call
        printMinDelAndInsert(str1, str2);
    }
    
    /**----------------------------------------------------------------------------------------
     * 
     * Check if it is possible to transform one string to another
     * Given two strings s1 and s2(call letters in uppercase). Check if it is possible to convert s1 to s2 by performing following operations.
		1. Make some lowercase letters uppercase. 
		2. Delete all the lowercase letters. 
Input : s1 = daBcd s2 = ABC 
Output : yes
Explanation : daBcd -> dABCd -> ABC  
Convert a and b at index 1 and 3 to 
upper case, delete the rest those are 
lowercase. We get the string s2. 

     * @param s1
     * @return
     */

 // function to check if a string can be
    // converted to another string by
    // performing following operations
    static boolean check(String s1, String s2)
    {
        // calculates length
        int n = s1.length();
        int m = s2.length();
      
        boolean dp[][]=new boolean[n + 1][m + 1];
        for (int i = 0; i <= n; i++) 
        {
            for (int j = 0; j <= m; j++)
            {
                dp[i][j] = false;
            }
        }
        // mark 1st position as true
        dp[0][0] = true;
      
        // traverse for all DPi, j
        for (int i = 0; i < s1.length(); i++)
        {
            for (int j = 0; j <= s2.length(); j++)
            {
      
                // if possible for to convert i 
                // characters of s1 to j characters
                // of s2
                if (dp[i][j]) {
      
                    // if upper_case(s1[i])==s2[j]
                    // is same
                    if (j < s2.length() && 
                        (Character.toUpperCase(s1.charAt(i)) == s2.charAt(j)))
                        dp[i + 1][j + 1] = true;
      
                    // if not upper then deletion is 
                    // possible
                    if (!Character.isUpperCase(s1.charAt(i)))
                        dp[i + 1][j] = true;
                }
            }
        }
      
        return (dp[n][m]);
    }
      
    // driver code
    public static void main2(String args[])
    {
        String s1 = "daBcd";
        String s2 = "ABC";
      
        if (check(s1, s2))
            System.out.println("YES");
        else
            System.out.println("NO");
      
    }
    
    public static String reduce(String s1){
        StringBuffer s=new StringBuffer();
        for(int i=0;i<s1.length();i++){
            if(s1.charAt(i)!='#')
                s.append(s1.charAt(i));
        }
        return s.toString();
    }
}
