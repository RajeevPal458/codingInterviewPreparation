package gfg.tree;

import gfg.tree.RootToLeafPathSum.Node;

public class FindSiblingNodeOfGivenNodeValueInBinaryTree {

	// Structure of
		// binary tree node
		static class Node
		{
		    int val;
		    Node left, right;
			@Override
			public String toString() {
				return "Node [val=" + val + ", left=" + left + ", right=" + right + "]";
			}
		    
		};
		 
		// Function to create new node
		static Node newNode(int data)
		{
		    Node temp = new Node();
		    temp.val = data;
		    temp.left = temp.right = null;
		    return temp;
		}
		
		private static Node findSiblingOf(Node root, int i) {
			// TODO Auto-generated method stub
			if(root ==null) return null;
			
			if(root.left!=null && root.left.val==i) {
				return root.right;
			}
			if(root.right!=null && root.right.val==i) {
				return root.left;
			}
			
			Node sibling = findSiblingOf(root.left, i);
			if(sibling==null) {
				sibling = findSiblingOf(root.right, i);
			}
			return sibling;
		}
		
		
		// print all nodes that do not have siblings 
		void printSingles(Node node)
	    {
	    // Base case
	    if (node == null)
	      return;
	  
	    // If this is an internal node, recur for left
	    // and right subtrees
	    if (node.left != null && node.right != null)
	    {
	        printSingles(node.left);
	        printSingles(node.right);
	    }
	  
	    // If left child is NULL and right
	    // is not, print right child
	    // and recur for right child
	    else if (node.right != null)
	    {
	        System.out.print(node.right.val + " ");
	        printSingles(node.right);
	    }
	  
	    // If right child is NULL and left
	    // is not, print left child
	    // and recur for left child
	    else if (node.left != null)
	    {
	        System.out.print( node.left.val + " ");
	        printSingles(node.left);
	    }
	}
		
		// Function to find out if two nodes are siblings
		static boolean CheckIfNodesAreSiblings(Node root,
		                                       int data_one,
		                                       int data_two)
		{
		    if (root == null)
		        return false;
		 
		    // Compare the two given nodes with
		    // the childrens of current node
		    if (root.left != null && root.right != null)
		    {
		        int left = root.left.val;
		        int right = root.right.val;
		 
		        if (left == data_one &&
		           right == data_two)
		            return true;
		        else if (left == data_two &&
		                right == data_one)
		            return true;
		    }
		 
		    // Check for left subtree
		    if (root.left != null)
		        CheckIfNodesAreSiblings(root.left,
		                                data_one,
		                                data_two);
		 
		    // Check for right subtree
		    if (root.right != null)
		        CheckIfNodesAreSiblings(root.right,
		                                data_one,
		                                data_two);
		    return true;
		}
	public static void main(String[] args) {
		// Construct binary tree
	    Node root = newNode(30);
	    root.left = newNode(10);
	    root.right = newNode(50);
	    root.left.left = newNode(3);
	    root.left.right = newNode(16);
	    root.right.left = newNode(40);
	    root.right.right = newNode(60);
	 
	    /*  The above code constructs this tree
	 
	            30
	         /      \
	       10        50
	      /  \      /  \
	     3   16   40    60
	*/
	 
	    // Function call
	   Node sibling = findSiblingOf(root,40);
	   System.out.println(sibling);

	}



}
