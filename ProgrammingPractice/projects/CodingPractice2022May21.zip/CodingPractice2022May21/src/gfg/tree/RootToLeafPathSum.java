package gfg.tree;

import java.util.ArrayList;

/**
 * Find all root to leaf path sum of a Binary Tree
Input:
                 30
              /      \
            10        50
           /  \      /  \
          3   16   40    60
Output: 43 56 120 140

 * @author rajeevkumar.pal
 *
 */
public class RootToLeafPathSum {

	// Structure of
	// binary tree node
	static class Node
	{
	    int val;
	    Node left, right;
	};
	 
	// Function to create new node
	static Node newNode(int data)
	{
	    Node temp = new Node();
	    temp.val = data;
	    temp.left = temp.right = null;
	    return temp;
	}
	 
	// Function that calculates the root to
	// leaf path sum of the BT using DFS
	static void dfs(Node root, int sum,
	                ArrayList<Integer> pathSum)
	{
	     
	    // Return if the node is NULL
	    if (root == null)
	        return;
	 
	    // Add value of the node to
	    // the path sum
	    sum += root.val;
	 
	    // Store the path sum if node is leaf
	    if (root.left == null &&
	       root.right == null)
	    {
	        pathSum.add(sum);
	        return;
	    }
	 
	    // Move to the left child
	    dfs(root.left, sum, pathSum);
	 
	    // Move to the right child
	    dfs(root.right, sum, pathSum);
	}
	 
	// Function that finds the root to leaf
	// path sum of the given binary tree
	static void findPathSum(Node root)
	{
	     
	    // To store all the path sum
	    ArrayList<Integer> pathSum = new ArrayList<>();
	 
	    // Calling dfs function
	    dfs(root, 0, pathSum);
	 
	    // Printing all the path sum
	    for(int num : pathSum)
	    {
	        System.out.print(num + " ");
	    }
	}
	 
	// Driver code
	public static void main(String[] args)
	{
	     
	    // Construct binary tree
	    Node root = newNode(30);
	    root.left = newNode(10);
	    root.right = newNode(50);
	    root.left.left = newNode(3);
	    root.left.right = newNode(16);
	    root.right.left = newNode(40);
	    root.right.right = newNode(60);
	 
	    /*  The above code constructs this tree
	 
	            30
	         /      \
	       10        50
	      /  \      /  \
	     3   16   40    60
	*/
	 
	    // Function call
	    findPathSum(root);
	}
}
