package gfg.tree;


/**
 * 
 Root to leaf path sum equal to a given number
 Given a binary tree and a number, return true if the tree has a root-to-leaf path such that adding up all the values along the path equals the given number. Return false if no such path can be found. 
 



For example, in the above tree root to leaf paths exist with the following sums.
21 –> 10 – 8 – 3 
23 –> 10 – 8 – 5 
14 –> 10 – 2 – 2
So the returned value should be true only for numbers 21, 23, and 14. For any other number, the returned value should be false.
 * @author rajeevkumar.pal
 *
 */

public class RootToLeafPathSumEqualToGivenNumber {
	static class Node {
	    int data;
	    Node left, right;
	 
	    Node(int item)
	    {
	        data = item;
	        left = right = null;
	    }
	}
	
	    Node root;
	 
	    /*
	     Given a tree and a sum,
	     return true if there is a path
	     from the root down to a leaf,
	     such that adding up all
	     the values along the path
	     equals the given sum.
	 
	     Strategy: subtract the node
	     value from the sum when
	     recurring down, and check to
	     see if the sum is 0 you reach the leaf node.
	     */
	 
	    boolean hasPathSum(Node node, int sum)
	    {
	      boolean ans = false;
	      int subSum = sum - node.data;
	      if(subSum == 0 && node.left == null && node.right == null)
	        return(ans = true);
	      if(node.left != null) 
	         
	        // ans || hasPathSum... has no utility if the ans is false
	        ans = ans || hasPathSum(node.left, subSum);       
	      
	      if(node.right != null)
	         
	        // But if it is true then we can avoid calling hasPathSum
	        // here as answer has already been found
	        ans = ans || hasPathSum(node.right, subSum);   
	      return(ans);
	    }
	 
	    // Driver Code
	    public static void main(String args[])
	    {
	        int sum = 21;
	 
	        /* Constructed binary tree is
	              10
	             /  \
	           8     2
	          / \   /
	         3   5 2
	        */
	        RootToLeafPathSumEqualToGivenNumber tree = new RootToLeafPathSumEqualToGivenNumber();
	        tree.root = new Node(10);
	        tree.root.left = new Node(8);
	        tree.root.right = new Node(2);
	        tree.root.left.left = new Node(3);
	        tree.root.left.right = new Node(5);
	        tree.root.right.left = new Node(2);
	 
	        if (tree.hasPathSum(tree.root, sum))
	            System.out.println(
	                "There is a root to leaf path with sum "
	                + sum);
	        else
	            System.out.println(
	                "There is no root to leaf path with sum "
	                + sum);
	    }
}
