package gfg.tree;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Print Left View of a Binary Tree
 Input : 
                 1
               /   \
              2     3
             / \     \
            4   5     6             
Output : 1 2 4

Method-1 (Using Recursion)
The left view contains all nodes that are first nodes in their levels. A simple solution is to do level order traversal and print the first node in every level.

Method-2 (Using Queue):

In this method, level order traversal based solution is discussed. If we observe carefully, we will see that our main task is to print the left most node of every level.
 So, we will do a level order traversal on the tree and print the leftmost node at every level. Below is the implementation of above approach:




Print Right View of a Binary Tree
 * @author rajeevkumar.pal
 *
 */
public class LeftViewofBinaryTree {

	static class Node {
	    int data;
	    Node left, right;
	 
	    public Node(int item)
	    {
	        data = item;
	        left = right = null;
	    }
	}
	    Node root;
	    static int max_level = 0;
	 
	    
	 // function to print left view of binary tree
	    private static void printLeftView(Node root)
	    {
	        if (root == null)
	            return;
	 
	        Queue<Node> queue = new LinkedList<>();
	        queue.add(root);
	 
	        while (!queue.isEmpty()) {
	            // number of nodes at current level
	            int n = queue.size();
	 
	            // Traverse all nodes of current level
	            for (int i = 1; i <= n; i++) {
	                Node temp = queue.poll();
	 
	                // Print the left most element at
	                // the level
	                if (i == 1)
	                    System.out.print(temp.data + " ");
	 
	                // Add left node to queue
	                if (temp.left != null)
	                    queue.add(temp.left);
	 
	                // Add right node to queue
	                if (temp.right != null)
	                    queue.add(temp.right);
	            }
	        }
	    }
	    
	    // recursive function to print left view
	    void leftViewUtil(Node node, int level)
	    {
	        // Base Case
	        if (node == null)
	            return;
	 
	        // If this is the first node of its level
	        if (max_level < level) {
	            System.out.print(" " + node.data);
	            max_level = level;
	        }
	 
	        // Recur for left and right subtrees
	        leftViewUtil(node.left, level + 1);
	        leftViewUtil(node.right, level + 1);
	    }
	 
	    // A wrapper over leftViewUtil()
	    void leftView()
	    {
	          max_level = 0;
	        leftViewUtil(root, 1);
	    }
	 
	    /* testing for example nodes */
	    public static void main(String args[])
	    {
	        /* creating a binary tree and entering the nodes */
	    	LeftViewofBinaryTree tree = new LeftViewofBinaryTree();
	        tree.root = new Node(10);
	        tree.root.left = new Node(2);
	        tree.root.right = new Node(3);
	        tree.root.left.left = new Node(7);
	        tree.root.left.right = new Node(8);
	        tree.root.right.right = new Node(15);
	        tree.root.right.left = new Node(12);
	        tree.root.right.right.left = new Node(14);
	           
	       
	 
	        tree.leftView();
	    }
}
