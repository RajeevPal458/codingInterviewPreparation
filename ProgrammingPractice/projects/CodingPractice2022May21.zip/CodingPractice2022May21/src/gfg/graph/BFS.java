package gfg.graph;

/**
 * Applications of Breadth First Traversal
 * 1) Shortest Path and Minimum Spanning Tree for unweighted graph:-
  In an unweighted graph, the shortest path is the path with least number of edges. With Breadth First, we always reach a vertex from given source using the minimum number of edges. Also, in case of unweighted graphs, any spanning tree is Minimum Spanning Tree and we can use either Depth or Breadth first traversal for finding a spanning tree. 

2) Peer to Peer Networks:- 
In Peer to Peer Networks like BitTorrent, Breadth First Search is used to find all neighbor nodes. 

3) Social Networking Websites:- 
In social networks, we can find people within a given distance ‘k’ from a person using Breadth First Search till ‘k’ levels. 

4) GPS Navigation systems:-
 Breadth First Search is used to find all neighboring locations. 
 
5) Broadcasting in Network: 
	In networks, a broadcasted packet follows Breadth First Search to reach all nodes. 
	
6) In Garbage Collection:-
 Breadth First Search is used in copying garbage collection using Cheney’s algorithm. Refer this and for details. 
 Breadth First Search is preferred over Depth First Search because of better locality of reference: 
 
7) Cycle detection in undirected graph:-
In undirected graphs, either Breadth First Search or Depth First Search can be used to detect cycle. We can use BFS to detect cycle in a directed graph also,

8) Ford–Fulkerson algorithm In Ford-Fulkerson algorithm, we can either use Breadth First or Depth First Traversal to find the maximum flow.
 Breadth First Traversal is preferred as it reduces worst case time complexity to O(VE2). 
 
9) To test if a graph is Bipartite We can either use Breadth First or Depth First Traversal. 

10 )Path Finding We can either use Breadth First or Depth First Traversal to find if there is a path between two vertices. 

11) Finding all nodes within one connected component:-
 We can either use Breadth First or Depth First Traversal to find all nodes reachable from a given node. 

 * @author rajeevkumar.pal
 *
 */

//Java program to print BFS traversal from a given source vertex.
//BFS(int s) traverses vertices reachable from s.
import java.io.*;
import java.util.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;


//This class represents a directed graph using adjacency list
//representation
class Graph3
{
	private int V; // No. of vertices
	private LinkedList<Integer> adj[]; //Adjacency Lists

	// Constructor
	Graph3(int v)
	{
		V = v;
		adj = new LinkedList[v];
		for (int i=0; i<v; ++i)
			adj[i] = new LinkedList();
	}

	// Function to add an edge into the graph
	void addEdge(int v,int w)
	{
		adj[v].add(w);
	}

	// prints BFS traversal from a given source s
	void BFS(int s)
	{
		// Mark all the vertices as not visited(By default
		// set as false)
		boolean visited[] = new boolean[V];

		// Create a queue for BFS
		LinkedList<Integer> queue = new LinkedList<Integer>();

		// Mark the current node as visited and enqueue it
		visited[s]=true;
		queue.add(s);

		while (queue.size() != 0)
		{
			// Dequeue a vertex from queue and print it
			s = queue.poll();
			System.out.print(s+" ");

			// Get all adjacent vertices of the dequeued vertex s
			// If a adjacent has not been visited, then mark it
			// visited and enqueue it
			Iterator<Integer> i = adj[s].listIterator();
			while (i.hasNext())
			{
				int n = i.next();
				if (!visited[n])
				{
					visited[n] = true;
					queue.add(n);
				}
			}
		}
	}

}
//This code is contributed by Aakash Hasija

public class BFS {

	static Scanner sc=new Scanner(System.in);
	static class Graph{
		static int MAX=100;
		static int n;
		static ArrayList<Integer>[] adj;
		static int initial=0;
		static int waiting=1;
		static int visited=2;
		static int NIL=-1;
		static int infinite=999999;
		static int[] pred;
		static int[] status;
		static int[] pathlen;
		static int sorce;
		public  Graph(int n){
			Graph.n=n;
			pred=new int[n];
			status=new int[n];
			pathlen=new int[n];
			adj=new ArrayList[n];
			
			for(int i=0;i<n;i++)
				adj[i]=new ArrayList<>();
		}
		public static void addEdge(int u,int v){
			adj[u].add(v);
		}
		public static void printGraph(){
			
			for(int i=0;i<adj.length;i++){
				ArrayList<Integer> list=adj[i];
				Iterator<Integer> it=list.listIterator();
				while(it.hasNext()){
					Integer v=it.next();
					System.out.println("Edge:-("+i+" , "+v+")");
				}
			}
		}
		public static void createGraph(int n){
			int orig=0,dest=0;
			int i=0;
				System.out.println("Edge :"+i+++" please inter all Edges by separate one space( )within three non negative number separated by comma(,) in sequences origin,destination)");
				String str1=sc.nextLine();
				String[] arr1=str1.split(" ");
				for(int k=0;k<arr1.length;k++){
					
					String str=arr1[k];
					String[] arr=str.split(",");
					if(arr.length==2){
						orig=Integer.parseInt(arr[0]);
						dest=Integer.parseInt(arr[1]);
						if(orig<0||dest<0)
						{
							System.out.println("its input for break !");
							break;
						}	
					}
					else{System.out.println("Wrong Input!  \nplease inter two non negative number separated by comma(,) in sequences ");}
					Graph.addEdge(orig, dest);
				}
		}
		static int front,rear;
		static int[] queue;
		static void initializeQueue(){
			front=-1;
			rear=-1;
			queue=new int[MAX];
			for(int i=0;i<MAX;i++)
				queue[i]=0;
		}
		static void inQue(int val){
			if(rear==MAX){
				System.out.println("queue is ovrflow!");
				return;
			}
			if(front==-1)
				front=0;
			rear+=1;
			System.out.println("rear:"+rear+"  n:"+n+" val:"+val+" size of queue: "+queue.length);
			queue[rear]=val;
		}
		static int deQueue(){
			if(front==-1||front==rear+1){
				System.out.println("Queue is underflow!");
				return -1;
			}
			int val=queue[front];
			front+=1;
			return val;
		}
		static boolean isEmpty(){
			if(rear==-1||front==rear+1)
				return true;
			else
				return false;
		}
		public static void findPathAndLength(int dest){
			System.out.println("Path Length of vertex "+dest+" from source "+sorce);
			int sortdis=0,u;
			int path[]=new int[MAX] ;
			int count=0;
			while(dest!=sorce){
				
				count++;
				
				path[count]=dest;
				u=pred[dest];
				//sortdis+=adj[source].get(dest).weight;
				dest=u;
			}
			count++;
			path[count]=sorce;
			System.out.println("Shortest path is:");
			for(int i=count;i>=1;i--){
				System.out.print(path[i]+" -->");
			}
			
			System.out.println();
			System.out.println("Distance of destination from source is:"+count+" "+pathlen[dest]);
		}
		private static void dfsUtil(int s) {
			
			inQue(s);
			status[s]=waiting;
			pathlen[s]=0;
			while(!isEmpty()){
				int source=deQueue();
				status[source]=visited;
				ArrayList<Integer> ad=adj[source];
					Iterator<Integer> it=ad.listIterator();
					while(it.hasNext()){
						int v=it.next();
						if((status[v]==initial)&&(pathlen[source]<pathlen[v])){
							inQue(v);
							pred[v]=source;
							pathlen[v]=pathlen[source]+1;
							status[v]=waiting;
						}
					}
			}
		}
		private static void dfs(int n) {
		// TODO Auto-generated method stub
			for(int v=0;v<n;v++){
				status[v]=initial;
				pred[v]=NIL;
				pathlen[v]=infinite;
			}
			initializeQueue();
			System.out.println("enter source vertex");
			int s=Integer.parseInt(sc.nextLine());
			sorce=s;
			dfsUtil(s);
		
		}
	}
	public static void main2(String[] args) {
		int s,v;
		System.out.println("enter number of vertices!");
		int n=Integer.parseInt(sc.nextLine());
		Graph g=new Graph(n);
		Graph.createGraph(n);
		Graph.printGraph();
		Graph.dfs(n);
		System.out.println("1");
		while(true){
			System.out.println("enter destination vertex for shortest path from given source to break enter -1 !");
			int dest=Integer.parseInt(sc.nextLine());
			
			if(dest>=n||dest<0)
				break;
			else if(Graph.sorce==dest)
				System.out.println("source and destination are same!");
			else if(g.pathlen[dest]==g.infinite)
				System.out.println("there is no path for this dest it might apear disconnected graph!");
			else
				Graph.findPathAndLength(dest);
			
		}
	}
	// Driver method to
	public static void main(String args[])
		{
			Graph3 g = new Graph3(4);

			g.addEdge(0, 1);
			g.addEdge(0, 2);
			g.addEdge(1, 2);
			g.addEdge(2, 0);
			g.addEdge(2, 3);
			g.addEdge(3, 3);

			System.out.println("Following is Breadth First Traversal "+
							"(starting from vertex 2)");

			g.BFS(2);
		}
}
