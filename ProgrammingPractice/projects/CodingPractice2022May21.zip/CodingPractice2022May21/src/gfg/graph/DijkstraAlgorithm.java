package gfg.graph;

/**
 * Dijkstra’s shortest path algorithm
 * https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-greedy-algo-7/
 * Given a graph and a source vertex in the graph, find the shortest paths from the source to all vertices in the given graph.
 * 
 * 
 * 
 * @author rajeevkumar.pal
 *
 */

//A Java program for Dijkstra's single source shortest path algorithm.
//The program is for adjacency matrix representation of the graph
import java.util.*;

import java.lang.*;
import java.io.*;


class DijkstraAlgorithmSelf {
	static Scanner sc=new Scanner(System.in);
	
	static class Edge{
		int dest;
		int weight;
		Edge(int v,int w){
			this.dest=v;
			this.weight=w;
		}
	}
	
	static class Graph{
		static boolean perm=true,temp=false;
		static int NIL=-1;
		static int infite=9999999; 
		static boolean[] status;;
		static int[] pred;
		static int[] pathlen;
		static ArrayList<Edge> adj[];
		static int n;
		
		Graph(int n){
			this.n=n;
			this.status=new boolean[n];
			this.pred=new int[n];
			this.pathlen=new int[n];
			this.adj=new ArrayList[n];
			for(int i=0;i<n;i++)
				adj[i]=new ArrayList<>();
		}
		public static void addEdge(int orig,int dest,int weight){
			Edge e=new Edge(dest,weight);
			adj[orig].add(e);
		}
		
		public static void printGraph(){
			
			for(int i=0;i<adj.length;i++){
				ArrayList<Edge> list=adj[i];
				Iterator<Edge> it=list.listIterator();
				while(it.hasNext()){
					Edge e=it.next();
					System.out.println("Edge:-("+i+" , "+e.dest+")  ->"+e.weight);
				}
			}
		}
		public static void createGraph(int n){
			int orig=0,dest=0,weight=0;
			int i=0;
				System.out.println("Edge :"+i+++" please inter all Edges by separate one space( )within three non negative number separated by comma(,) in sequences origin,destination,weight");
				String str1=sc.nextLine();
				String[] arr1=str1.split(" ");
				for(int k=0;k<arr1.length;k++){
					
					String str=arr1[k];
					String[] arr=str.split(",");
					if(arr.length==3){
						orig=Integer.parseInt(arr[0]);
						dest=Integer.parseInt(arr[1]);
						weight=Integer.parseInt(arr[2]);
						if(orig<0||dest<0||weight<0)
						{
							System.out.println("its input for break !");
							break;
						}	
					}
					else{System.out.println("Wrong Input!  \nplease inter three non negative number separated by comma(,) in sequences ");}
					Graph.addEdge(orig, dest, weight);
				}
		}
		
		public static void dijkstra(int source){
			int cur;
			System.out.println(n+" ststuslen:"+status.length);
			
			for(int i=0;i<n;i++){
				status[i]=temp;
				pred[i]=NIL;
				pathlen[i]=infite;
			}
			pathlen[source]=0;
			while (true) {
				cur=minPathLen();
			System.out.println("cur:"+cur);
				if(cur==NIL){
					return ;
				}
				status[cur]=perm;
				
				ArrayList<Edge> list=adj[cur];
				Iterator<Edge> it=list.listIterator();
				while(it.hasNext()){
					Edge e=it.next();
			System.out.println("4");
					if(!status[e.dest]){
						if(pathlen[cur]+e.weight<pathlen[e.dest]){
							pred[e.dest]=cur;
							pathlen[e.dest]=pathlen[cur]+e.weight;
						}
					}
				}
			}
		}
		public static void shortestPath(int source,int dest){
			System.out.println("shortest path from source "+source+" to dest "+dest);
			int i=dest;
			int count=0;
			while(true){
				System.out.print(i);
				if(i!=source)
					System.out.print(" <--> ");
				int pre=pred[i];
				if(pre==NIL)
				{
					System.out.println();
					System.out.println("sucessfully find complete path");
					break;
				}
				else
					i=pre;
				
				count++;
				if(count>n)
					break;
			}
		}
		public static int minPathLen(){
			int min=infite,k=NIL;
			for(int i=0;i<n;i++){
				if(!status[i]&&pathlen[i]<min){
					min=pathlen[i];
					k=i;
				}
			}
			return k;
		}
	}
	
	public static void main(String[] args) {
		int s,v;
		System.out.println("enter number of vertices!");
		int n=Integer.parseInt(sc.nextLine());
		Graph g=new Graph(n);
		Graph.createGraph(n);
		Graph.printGraph();
		System.out.println("enter source vertex");
		s=Integer.parseInt(sc.nextLine());
		
		Graph.dijkstra(s);
		
		while(true){
			System.out.println("enter destination vertex for shortest path from given source to break enter -1 !");
			int dest=Integer.parseInt(sc.nextLine());
			
			if(dest>=n||dest<0)
				break;
			else if(s==dest)
				System.out.println("source and destination are same!");
			else if(g.pathlen[dest]==g.infite)
				System.out.println("there is no path for this dest it might apear disconnected graph!");
			else
				Graph.shortestPath(s, dest);
			
		}
	}
}

class ShortestPath {
	// A utility function to find the vertex with minimum distance value,
	// from the set of vertices not yet included in shortest path tree
	static final int V = 9;
	int minDistance(int dist[], Boolean sptSet[])
	{
		// Initialize min value
		int min = Integer.MAX_VALUE, min_index = -1;

		for (int v = 0; v < V; v++)
			if (sptSet[v] == false && dist[v] <= min) {
				min = dist[v];
				min_index = v;
			}

		return min_index;
	}

	// A utility function to print the constructed distance array
	void printSolution(int dist[])
	{
		System.out.println("Vertex \t\t Distance from Source");
		for (int i = 0; i < V; i++)
			System.out.println(i + " \t\t " + dist[i]);
	}

	// Function that implements Dijkstra's single source shortest path
	// algorithm for a graph represented using adjacency matrix
	// representation
	void dijkstra(int graph[][], int src)
	{
		int dist[] = new int[V]; // The output array. dist[i] will hold
		// the shortest distance from src to i

		// sptSet[i] will true if vertex i is included in shortest
		// path tree or shortest distance from src to i is finalized
		Boolean sptSet[] = new Boolean[V];

		// Initialize all distances as INFINITE and stpSet[] as false
		for (int i = 0; i < V; i++) {
			dist[i] = Integer.MAX_VALUE;
			sptSet[i] = false;
		}

		// Distance of source vertex from itself is always 0
		dist[src] = 0;

		// Find shortest path for all vertices
		for (int count = 0; count < V - 1; count++) {
			// Pick the minimum distance vertex from the set of vertices
			// not yet processed. u is always equal to src in first
			// iteration.
			int u = minDistance(dist, sptSet);

			// Mark the picked vertex as processed
			sptSet[u] = true;

			// Update dist value of the adjacent vertices of the
			// picked vertex.
			for (int v = 0; v < V; v++)

				// Update dist[v] only if is not in sptSet, there is an
				// edge from u to v, and total weight of path from src to
				// v through u is smaller than current value of dist[v]
				if (!sptSet[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v])
					dist[v] = dist[u] + graph[u][v];
		}

		// print the constructed distance array
		printSolution(dist);
	}

}
//This code is contributed by Aakash Hasija

public class DijkstraAlgorithm {

	// Driver method
		public static void main(String[] args){
			/* Let us create the example graph discussed above */
			int graph[][] = new int[][] { { 0, 4, 0, 0, 0, 0, 0, 8, 0 },
										{ 4, 0, 8, 0, 0, 0, 0, 11, 0 },
										{ 0, 8, 0, 7, 0, 4, 0, 0, 2 },
										{ 0, 0, 7, 0, 9, 14, 0, 0, 0 },
										{ 0, 0, 0, 9, 0, 10, 0, 0, 0 },
										{ 0, 0, 4, 14, 10, 0, 2, 0, 0 },
										{ 0, 0, 0, 0, 0, 2, 0, 1, 6 },
										{ 8, 11, 0, 0, 0, 0, 1, 0, 7 },
										{ 0, 0, 2, 0, 0, 0, 6, 7, 0 } };
			ShortestPath t = new ShortestPath();
			t.dijkstra(graph, 0);
		}
}
