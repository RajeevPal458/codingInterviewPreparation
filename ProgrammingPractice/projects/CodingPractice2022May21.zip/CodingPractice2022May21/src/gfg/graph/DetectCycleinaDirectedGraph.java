package gfg.graph;

/**
 * 
 * Solution using Depth First Search or DFS

Approach: Depth First Traversal can be used to detect a cycle in a Graph. DFS for a connected graph produces a tree. 
There is a cycle in a graph only if there is a back edge present in the graph. A back edge is an edge that is from a node to itself (self-loop) or 
one of its ancestors in the tree produced by DFS. In the following graph, there are 3 back edges, marked with a cross sign. We can observe that 
these 3 back edges indicate 3 cycles present in the graph.

 * @author rajeevkumar.pal
 *
 */

//A Java Program to detect cycle in a graph
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class Graph4 {
	
	private final int V;
	private final List<List<Integer>> adj;

	public Graph4(int V)
	{
		this.V = V;
		adj = new ArrayList<>(V);
		
		for (int i = 0; i < V; i++)
			adj.add(new LinkedList<>());
	}
	
	// This function is a variation of DFSUtil() in
	// https://www.geeksforgeeks.org/archives/18212
	public boolean isCyclicUtil(int i, boolean[] visited,
									boolean[] recStack)
	{
		
		// Mark the current node as visited and
		// part of recursion stack
		if (recStack[i])
			return true;

		if (visited[i])
			return false;
			
		visited[i] = true;

		recStack[i] = true;
		List<Integer> children = adj.get(i);
		
		for (Integer c: children)
			if (isCyclicUtil(c, visited, recStack))
				return true;
				
		recStack[i] = false;

		return false;
	}

	public void addEdge(int source, int dest) {
		adj.get(source).add(dest);
	}

	// Returns true if the graph contains a
	// cycle, else false.
	// This function is a variation of DFS() in
	// https://www.geeksforgeeks.org/archives/18212
	public boolean isCyclic()
	{
		
		// Mark all the vertices as not visited and
		// not part of recursion stack
		boolean[] visited = new boolean[V];
		boolean[] recStack = new boolean[V];
		
		
		// Call the recursive helper function to
		// detect cycle in different DFS trees
		for (int i = 0; i < V; i++)
			if (isCyclicUtil(i, visited, recStack))
				return true;

		return false;
	}

}

//This code is contributed by Sagar Shah.

public class DetectCycleinaDirectedGraph {
	// Driver code
		public static void main(String[] args)
		{
			Graph4 graph = new Graph4(5);
			graph.addEdge(0, 1);
			graph.addEdge(0, 2);
			graph.addEdge(0, 3);
			graph.addEdge(1, 2);
			graph.addEdge(3, 4);
			graph.addEdge(4, 0);
			if(graph.isCyclic())
				System.out.println("Graph contains cycle");
			else
				System.out.println("Graph doesn't "
										+ "contain cycle");
		}
}
