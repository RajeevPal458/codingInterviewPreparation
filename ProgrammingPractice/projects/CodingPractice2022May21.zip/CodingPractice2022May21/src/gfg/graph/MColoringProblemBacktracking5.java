package gfg.graph;

/**
 * m Coloring Problem | Backtracking-5
 * https://www.geeksforgeeks.org/m-coloring-problem-backtracking-5/
 * Given an undirected graph and a number m, determine if the graph can be coloured with at most m colours such that no two adjacent vertices of the graph are colored with the same color. Here coloring of a graph means the assignment of colors to all vertices. 

Input-Output format: 

Input: 

A 2D array graph[V][V] where V is the number of vertices in graph and graph[V][V] is an adjacency matrix representation of the graph. A value graph[i][j] is 1 if there is a direct edge from i to j, otherwise graph[i][j] is 0.
An integer m is the maximum number of colors that can be used.
Output: 
An array color[V] that should have numbers from 1 to m. color[i] should represent the color assigned to the ith vertex. The code should also return false if the graph cannot be colored with m colors.

 * @author rajeevkumar.pal
 *
 */

class GFG1
{

	// Number of vertices in the graph
	static int V = 4;
	
	/* A utility function to print solution */
	static void printSolution(int[] color)
	{
		System.out.println("Solution Exists:" +
						" Following are the assigned colors ");
		for (int i = 0; i < V; i++)
		System.out.print(" " + color[i]);
		System.out.println();
	}
	
	// check if the colored
	// graph is safe or not
	static boolean isSafe(boolean[][] graph, int[] color)
	{
		// check for every edge
		for (int i = 0; i < V; i++)
		for (int j = i + 1; j < V; j++)
			if (graph[i][j] && color[j] == color[i])
			return false;
		return true;
	}
	
	/* This function solves the m Coloring
		problem using recursion. It returns
		false if the m colours cannot be assigned,
		otherwise, return true and prints
		assignments of colours to all vertices.
		Please note that there may be more than
		one solutions, this function prints one
		of the feasible solutions.*/
	static boolean graphColoring(boolean[][] graph, int m,
								int i, int[] color)
	{
		// if current index reached end
		if (i == V) {
	
		// if coloring is safe
		if (isSafe(graph, color))
		{
	
			// Print the solution
			printSolution(color);
			return true;
		}
		return false;
		}
	
		// Assign each color from 1 to m
		for (int j = 1; j <= m; j++)
		{
		color[i] = j;
	
		// Recur of the rest vertices
		if (graphColoring(graph, m, i + 1, color))
			return true;
		color[i] = 0;
		}
		return false;
	}
	
	// Driver code
	public static void main(String[] args)
	{
		
		/* Create following graph and
			test whether it is 3 colorable
			(3)---(2)
			| / |
			| / |
			| / |
			(0)---(1)
			*/
		boolean[][] graph = {
		{ false, true, true, true },
		{ true, false, true, false },
		{ true, true, false, true },
		{ true, false, true, false },
		};
		int m = 3; // Number of colors
	
		// Initialize all color values as 0.
		// This initialization is needed
		// correct functioning of isSafe()
		int[] color = new int[V];
		for (int i = 0; i < V; i++)
		color[i] = 0;
		if (!graphColoring(graph, m, 0, color))
		System.out.println("Solution does not exist");
	}
}

// This code is contributed by divyeh072019.

public class MColoringProblemBacktracking5 {

}
