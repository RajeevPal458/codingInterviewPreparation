package gfg.graph;

/**
 * https://www.geeksforgeeks.org/water-jug-problem-using-bfs/
 * Water Jug problem using BFS
 * 
 * You are given an m liter jug and a n liter jug. Both the jugs are initially empty. The jugs don’t have markings to allow measuring smaller quantities. 
 * You have to use the jugs to measure d liters of water where d is less than n. 
 * @author rajeevkumar.pal
 *
 */
public class WaterJugProblemUsingBFS {

}
