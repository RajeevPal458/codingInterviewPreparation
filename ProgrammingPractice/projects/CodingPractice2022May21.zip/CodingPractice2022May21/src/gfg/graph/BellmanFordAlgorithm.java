package gfg.graph;

/**
 * Bellman–Ford Algorithm 
 * https://www.geeksforgeeks.org/bellman-ford-algorithm-dp-23/
 * Given a graph and a source vertex src in graph, find shortest paths from src to all vertices in the given graph. The graph may contain negative weight edges. 
We have discussed Dijkstra’s algorithm for this problem. Dijkstra’s algorithm is a Greedy algorithm and time complexity is O((V+E)LogV) 
(with the use of Fibonacci heap). Dijkstra doesn’t work for Graphs with negative weights, Bellman-Ford works for such graphs. Bellman-Ford 
is also simpler than Dijkstra and suites well for distributed systems. But time complexity of Bellman-Ford is O(VE), which is more than Dijkstra. 


 * @author rajeevkumar.pal
 *
 */


//A Java program for Bellman-Ford's single source shortest path
//algorithm.
import java.util.*;
import java.lang.*;
import java.io.*;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;

class BellmanFordAlgorithmOld {
static Scanner sc=new Scanner(System.in);
	
	static class Edge{
		int dest;
		int weight;
		Edge(int v,int w){
			this.dest=v;
			this.weight=w;
		}
	}
	
	static class Graph{
		static boolean perm=true,temp=false;
		static int MAX=100;
		static int NIL=-1;
		static int infite=9999999; 
		static boolean[] status;;
		static int[] pred;
		static int[] pathlen;
		static boolean[] isPresent;
		static ArrayList<Edge> adj[];
		static int n;
		
		Graph(int n){
			this.n=n;
			this.status=new boolean[n];
			this.pred=new int[n];
			this.pathlen=new int[n];
			this.adj=new ArrayList[n];
			this.isPresent=new boolean[n];
			for(int i=0;i<n;i++)
				adj[i]=new ArrayList<>();
		}
		public static void addEdge(int orig,int dest,int weight){
			Edge e=new Edge(dest,weight);
			adj[orig].add(e);
		}
		
		public static void printGraph(){
			
			for(int i=0;i<adj.length;i++){
				ArrayList<Edge> list=adj[i];
				Iterator<Edge> it=list.listIterator();
				while(it.hasNext()){
					Edge e=it.next();
					System.out.println("Edge:-("+i+" , "+e.dest+")  ->"+e.weight);
				}
			}
		}
		public static void createGraph(int n){
			int orig=0,dest=0,weight=0;
			int i=0;
				System.out.println("Edge :"+i+++" please inter all Edges by separate one space( )within three non negative number separated by comma(,) in sequences origin,destination,weight(may be negative)");
				String str1=sc.nextLine();
				String[] arr1=str1.split(" ");
				for(int k=0;k<arr1.length;k++){
					
					String str=arr1[k];
					String[] arr=str.split(",");
					if(arr.length==3){
						orig=Integer.parseInt(arr[0]);
						dest=Integer.parseInt(arr[1]);
						weight=Integer.parseInt(arr[2]);
						if(orig<0||dest<0)
						{
							System.out.println("its input for break !");
							break;
						}	
					}
					else{System.out.println("Wrong Input!  \nplease inter three non negative number separated by comma(,) in sequences ");}
					Graph.addEdge(orig, dest, weight);
				}
		}
		static int front,rear;
		static int[] queue;
		static void inQue(int val){
			if(rear==MAX){
				System.out.println("queue is ovrflow!");
				return;
			}
			if(front==-1)
				front=0;
			rear+=1;
			System.out.println("rear:"+rear+"  n:"+n+" val:"+val+" size of queue: "+queue.length);
			queue[rear]=val;
		}
		static int deQueue(){
			if(front==-1||front==rear+1){
				System.out.println("Queue is underflow!");
				return -1;
			}
			int val=queue[front];
			front+=1;
			return val;
		}
		static boolean isEmpty(){
			if(rear==-1||front==rear+1)
				return true;
			else
				return false;
		}
		static void initializeQueue(){
			front=-1;
			rear=-1;
			queue=new int[MAX];
			for(int i=0;i<MAX;i++)
				queue[i]=0;
		}
		public static int bellmanFord(int source){
			int count=0,k=0,cur;
			for(int i=0;i<n;i++){
				pathlen[i]=infite;
				isPresent[i]=false;
				pred[i]=NIL;
			}
			initializeQueue();
			inQue(source);
			pathlen[source]=0;
			isPresent[source]=true;
			while(!isEmpty()){
				
				cur=deQueue();
				System.out.println("cur:"+cur);
				isPresent[cur]=false;
				if(source==cur)
					k++;
				if(k>n)
					return -1;
				ArrayList<Edge> list=adj[cur];
				Iterator<Edge> it=list.listIterator();
				while(it.hasNext()){
					Edge e=it.next();
			System.out.println("e.dest :"+e.dest+"  e.w: "+e.weight);
						if(pathlen[cur]+e.weight<pathlen[e.dest]){
							System.out.println("1");
							pred[e.dest]=cur;
							System.out.println("2");
							pathlen[e.dest]=pathlen[cur]+e.weight;
							System.out.println("3");
							if(!isPresent[e.dest])
							{System.out.println("4");
								inQue(e.dest);
								System.out.println("5");
								isPresent[e.dest]=true;
								System.out.println("6");
							}
						}
				}
			}
			return 1;
		}
		
		public static void shortestPath(int source,int dest){
			int sortdis=0,u;
			int path[]=new int[MAX] ;
			int count=0;
			while(source!=dest){
				
				count++;
				
				path[count]=dest;
				u=pred[dest];
				//sortdis+=adj[source].get(dest).weight;
				dest=u;
			}
			count++;
			path[count]=source;
			System.out.println("Shortest path is:");
			for(int i=count;i>=1;i--){
				System.out.print(path[i]+" -->");
			}
			//System.out.println("Shortest Distence:"+sortdis);
			
		}
	}
	
	public static void main(String[] args) {
		int s,v;
		System.out.println("enter number of vertices!");
		int n=Integer.parseInt(sc.nextLine());
		Graph g=new Graph(n);
		Graph.createGraph(n);
		Graph.printGraph();
		
		System.out.println("enter source vertex");
		
		s=Integer.parseInt(sc.nextLine());
		
		if(Graph.bellmanFord(s)<0)
			System.out.println("there is a cycle !");
		else
			System.out.println("Success!");
		
		while(true){
			System.out.println("enter destination vertex for shortest path from given source to break enter -1 !");
			int dest=Integer.parseInt(sc.nextLine());
			
			if(dest>=n||dest<0)
				break;
			else if(s==dest)
				System.out.println("source and destination are same!");
			else if(g.pathlen[dest]==g.infite)
				System.out.println("there is no path for this dest it might apear disconnected graph!");
			else
				Graph.shortestPath(s, dest);
			
		}
	}
}

//A class to represent a connected, directed and weighted graph
class Graph6 {
	// A class to represent a weighted edge in graph
	class Edge {
		int src, dest, weight;
		Edge(){
			src = dest = weight = 0;
		}
	};

	int V, E;
	Edge edge[];

	// Creates a graph with V vertices and E edges
	Graph6(int v, int e)
	{
		V = v;
		E = e;
		edge = new Edge[e];
		for (int i = 0; i < e; ++i)
			edge[i] = new Edge();
	}

	// The main function that finds shortest distances from src
	// to all other vertices using Bellman-Ford algorithm. The
	// function also detects negative weight cycle
	void BellmanFord(Graph6 graph, int src)
	{
		int V = graph.V, E = graph.E;
		int dist[] = new int[V];
		// Step 1: Initialize distances from src to all other
		// vertices as INFINITE
		for (int i = 0; i < V; ++i)
			dist[i] = Integer.MAX_VALUE;
		
		dist[src] = 0;

		// Step 2: Relax all edges |V| - 1 times. A simple
		// shortest path from src to any other vertex can
		// have at-most |V| - 1 edges
		for (int i = 1; i < V; ++i) {
			for (int j = 0; j < E; ++j) {
				int u = graph.edge[j].src;
				int v = graph.edge[j].dest;
				int weight = graph.edge[j].weight;
				if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v])
					dist[v] = dist[u] + weight;
			}
		}

		// Step 3: check for negative-weight cycles. The above
		// step guarantees shortest distances if graph doesn't
		// contain negative weight cycle. If we get a shorter
		// path, then there is a cycle.
		for (int j = 0; j < E; ++j) {
			int u = graph.edge[j].src;
			int v = graph.edge[j].dest;
			int weight = graph.edge[j].weight;
			if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v]) {
				System.out.println("Graph contains negative weight cycle");
				return;
			}
		}
		printArr(dist, V);
	}

	// A utility function used to print the solution
	void printArr(int dist[], int V)
	{
		System.out.println("Vertex Distance from Source");
		for (int i = 0; i < V; ++i)
			System.out.println(i + "\t\t" + dist[i]);
	}

}
//Contributed by Aakash Hasija

public class BellmanFordAlgorithm {

	// Driver method to test above function
		public static void main(String[] args)
		{
			int V = 5; // Number of vertices in graph
			int E = 8; // Number of edges in graph

			Graph6 graph = new Graph6(V, E);

			// add edge 0-1 (or A-B in above figure)
			graph.edge[0].src = 0;
			graph.edge[0].dest = 1;
			graph.edge[0].weight = -1;

			// add edge 0-2 (or A-C in above figure)
			graph.edge[1].src = 0;
			graph.edge[1].dest = 2;
			graph.edge[1].weight = 4;

			// add edge 1-2 (or B-C in above figure)
			graph.edge[2].src = 1;
			graph.edge[2].dest = 2;
			graph.edge[2].weight = 3;

			// add edge 1-3 (or B-D in above figure)
			graph.edge[3].src = 1;
			graph.edge[3].dest = 3;
			graph.edge[3].weight = 2;

			// add edge 1-4 (or B-E in above figure)
			graph.edge[4].src = 1;
			graph.edge[4].dest = 4;
			graph.edge[4].weight = 2;

			// add edge 3-2 (or D-C in above figure)
			graph.edge[5].src = 3;
			graph.edge[5].dest = 2;
			graph.edge[5].weight = 5;

			// add edge 3-1 (or D-B in above figure)
			graph.edge[6].src = 3;
			graph.edge[6].dest = 1;
			graph.edge[6].weight = 1;

			// add edge 4-3 (or E-D in above figure)
			graph.edge[7].src = 4;
			graph.edge[7].dest = 3;
			graph.edge[7].weight = -3;

			graph.BellmanFord(graph, 0);
		}
}
