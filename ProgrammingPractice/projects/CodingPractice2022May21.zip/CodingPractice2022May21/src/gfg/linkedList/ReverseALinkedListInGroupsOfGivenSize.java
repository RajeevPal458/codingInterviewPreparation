package gfg.linkedList;

/**
 * Reverse a Linked List in groups of given size | Set 1
 * https://www.geeksforgeeks.org/reverse-a-list-in-groups-of-given-size/
 * 
 * Given a linked list, write a function to reverse every k nodes (where k is an input to the function). 

Example: 

Input: 1->2->3->4->5->6->7->8->NULL, K = 3 
Output: 3->2->1->6->5->4->8->7->NULL 
 * @author rajeevkumar.pal
 *
 */
public class ReverseALinkedListInGroupsOfGivenSize {

	Node head; // head of list
	 
    /* Linked list Node*/
    class Node {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
 
    Node reverse(Node head, int k)
    {
        if(head == null)
          return null;
        Node current = head;
        Node temp = null;
        Node prev = null;
 
        int count = 0;
 
        /* Reverse first k nodes of linked list */
        while (count < k && current != null) {
            temp = current.next;
            current.next = prev;
            prev = current;
            current = temp;
            count++;
        }
 
        /* next is now a pointer to (k+1)th node
           Recursively call for the list starting from
           current. And make rest of the list as next of
           first node */
        if (temp != null)
            head.next = reverse(temp, k);
 
        // prev is now head of input list
        return prev;
    }
    
 // utility function to reverse k nodes in the list
     Node reverse1(Node head, int k)
    {
        // If head is NULL or K is 1 then return head
        if (head == null || head.next == null)
            return head;
 
        // creating dummy node
        Node dummy = new Node(-1);
        dummy.next = head;
 
        // Initializing three points prev, curr, next
        Node prev = dummy;
        Node curr = dummy;
        Node next = dummy;
 
        // Calculating the length of linked list
        int count = 0;
        while (curr != null) {
            count++;
            curr = curr.next;
        }
 
        // Iterating till next is not NULL
        while (next != null) {
            curr = prev.next; // Curr position after every
                              // reverse group
            next = curr.next; // Next will always next to
                              // curr
            int toLoop
                = count > k
                      ? k
                      : count - 1; // toLoop will set to
                                   // count - 1 in case of
                                   // remaining element
 
            for (int i = 1; i < toLoop; i++) {
                // 4 steps as discussed above
                curr.next = next.next;
                next.next = prev.next;
                prev.next = next;
                next = curr.next;
            }
            prev = curr; // Setting prev to curr
            count -= k; // Update count
        }
        return dummy.next; // dummy -> next will be our new
                           // head for output linked
        // list
    }
 
    /* Utility functions */
 
    /* Inserts a new Node at front of the list. */
    public void push(int new_data)
    {
        /* 1 & 2: Allocate the Node &
                  Put in the data*/
        Node new_node = new Node(new_data);
 
        /* 3. Make next of new Node as head */
        new_node.next = head;
 
        /* 4. Move the head to point to new Node */
        head = new_node;
    }
 
    /* Function to print linked list */
    void printList()
    {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
 
    /* Driver program to test above functions */
    public static void main(String args[])
    {
    	ReverseALinkedListInGroupsOfGivenSize llist = new ReverseALinkedListInGroupsOfGivenSize();
 
        /* Constructed Linked List is 1->2->3->4->5->6->
           7->8->8->9->null */
        llist.push(9);
        llist.push(8);
        llist.push(7);
        llist.push(6);
        llist.push(5);
        llist.push(4);
        llist.push(3);
        llist.push(2);
        llist.push(1);
 
        System.out.println("Given Linked List");
        llist.printList();
 
        llist.head = llist.reverse(llist.head, 3);
 
        System.out.println("Reversed list");
        llist.printList();
    }
}
