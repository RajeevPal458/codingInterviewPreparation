package gfg.linkedList;

public class AddToNumber {

	static class Node{

        int data;

        Node next;

        public Node() {

            super();

            // TODO Auto-generated constructor stub
        }

        public Node(int data) {

            super();

            this.data = data;

            this.next = null;

        }

		@Override
		public String toString() {
			return "Node [data=" + data + ", next=" + next + "]";
		}

        

    }

    

    public static void main(String[] args) {

        // TODO Auto-generated method stub  //[2,4,9], l2 = [5,6,4]

        Node node = new Node(2);

        node.next = new Node(4);

        node.next.next = new Node(9);

        

        

        Node node1 = new Node(5);

        node1.next = new Node(6);

        node1.next.next = new Node(4);

        

        addTwoList(node, node1);

        printList(node);
        
        System.out.println();

        printList(node1);
        
        System.out.println();
        
        Node res = addTwoList2(node, node1);
        
        printList(res);
    }

    

    public static void printList(Node node) {

        Node ptr = node;
        while (ptr!=null) {
            System.out.print(ptr.data+" ");
            ptr = ptr.next;

        }

        

    }

    

    public static Node addTwoList(Node l1 , Node l2) {

        Node ptr1 = l1;
        Node ptr2 = l2;
            int size1 = 0;
            int size2 =0;
            while (ptr1!=null) {
                ptr1= ptr1.next;
                size1++;
            }
            while (ptr2!=null) {
                ptr2= ptr2.next;
                size2++;
            }
            System.out.println(size1+"::"+size2);
            if(size1>size2) {
                ////[2,4,9], l2 = [5,6,4]
                ptr1 = l1;
                ptr2 = l2;
                int carrif=0;
                while (ptr1!=null) {
                    int data1 = ptr1.data;
                    int data2=0;
                    if(ptr2!=null)
                     data2 = ptr2.data;
                    int rem = 0;
                    rem = (data1+data2+carrif)%10;
                    carrif = (data1+data2+carrif)/10;
                    ptr1.data = rem;
                    
                    if(ptr2!=null)
                       ptr2 = ptr2.next;
                    
                    if(ptr1.next==null&&carrif>0) {
                    	ptr1.next = new Node(carrif);
                    	ptr1 =null;
                    }else {
                    ptr1=ptr1.next;
                    }
                }
                return l1;
            }else {
                ptr1 = l1;
                ptr2 = l2;
                int carrif=0;
                while (ptr2!=null) {
                    int data1=0;
                    if(ptr1!=null)
                    	data1 = ptr1.data;
                    int data2 = ptr2.data;
                    int rem = 0;
                    rem = (data1+data2+carrif)%10;
                    carrif = (data1+data2+carrif)/10;
                    ptr2.data = rem;
                    
                    if(ptr1!=null)
                    	ptr1 = ptr1.next;
                    
                    if(ptr2.next==null&&carrif>0) {
                    	ptr2.next = new Node(carrif);
                    	ptr2=null;
                    }else
                    	ptr2 = ptr2.next;
                }
                return l2;

            }
    }
    
    
    public static Node addTwoList2(Node l1 , Node l2) {
    	
    	Node ptr1 = l1;
    	Node ptr2 = l2;
    	Node res = new Node(0);
    	
    	Node temp = res;
    	int carif=0;
    	while (ptr1!=null || ptr2!=null) {
    		
			int d1 = (ptr1!=null)?ptr1.data:0;
			int d2 = (ptr2!=null)?ptr2.data:0;
			int sum = d1+d2+carif;
			int rem = sum%10;
			carif = sum/10;
			
			temp.next = new Node(rem);
			temp = temp.next;
			
			ptr1 = (ptr1!=null)?ptr1.next:null;
			ptr2 = (ptr2!=null)?ptr2.next:null;
		}
    	if(carif>0)
    		temp.next=new Node(carif);
    	
    	return res.next;
    }
    
    
    public static Node addTwoList3(Node l1 , Node l2) {
    	
    	Node ptr1 = l1;
    	Node ptr2 = l2;
    	Node res = new Node(0);
    	
    	Node temp = res;
    	int carif=0;
    	while (ptr1!=null || ptr2!=null) {
    		
			int d1 = (ptr1!=null)?ptr1.data:0;
			int d2 = (ptr2!=null)?ptr2.data:0;
			int sum = d1+d2+carif;
			int rem = sum%10;
			carif = sum/10;
			
			temp.next = new Node(rem);
			temp = temp.next;
			
			ptr1 = (ptr1!=null)?ptr1.next:null;
			ptr2 = (ptr2!=null)?ptr2.next:null;
		}
    	if(carif>0)
    		temp.next=new Node(carif);
    	
    	return res.next;
    }
 
 

}

