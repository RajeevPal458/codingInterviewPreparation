package gfg.linkedList;

import java.util.Stack;

import gfg.linkedList.FindTheMiddleOfGivenLinkedList.Node;

/**
 * Given some resources in the form of linked list you have to canceled out all the resources whose sum up to 0(Zero) and return the remaining list.

E.g-->> 6 -6 8 4 -12 9 8 -8

the above example lists which gets canceled :
6 -6
8 4 -12
8 -8
o/p : 9
case 3 : 4 6 -10 8 9 10 -19 10 -18 20 25
O/P : 20 25
 * @author rajeevkumar.pal
 *
 */
public class DeleteElementsInLinkedListWhoseSumEqualTozero {

	Node head;  // head of list
	 
    /* Linked list Node*/
    class Node
    {
        int value;
        Node next;
        Node(int data)
        {
            this.value = data;
            next = null;
        }
		@Override
		public String toString() {
			return ""+value;
		}
        
    }
    
    /* Inserts a new Node at front of the list. */
    public void push(int new_data)
    {
        /* 1 & 2: Allocate the Node &
                  Put in the data*/
        Node new_node = new Node(new_data);
 
        /* 3. Make next of new Node as head */
        new_node.next = head;
 
        /* 4. Move the head to point to new Node */
        head = new_node;
    }
	
	// Note: does not compile! assumes negative numbers are after positive numbers in list
	Node removeCancellableNodes(Node listHead)
	{
		if (listHead == null) return null; // or listHead
		
		Stack<Node> stack = new Stack<Node>();
		
		Node node = listHead; 
		
		while(node != null)
		{
			if (node.value < 0)
			{
				int sum = Math.abs(node.value);
				Node ptr=null;
	            while (!stack.isEmpty())
				{
					Node temp = stack.pop();
					sum -= temp.value;
					temp = null;
					if (sum == 0 && !stack.isEmpty())
					{
						ptr = stack.peek();
						break;
					}
				}
	            if(ptr!=null)
	            	ptr.next = node.next;
	            else
	            	listHead=node.next;
			}
			else
			{
				stack.push(node);
			}
			node = node.next;
		}
		
		return listHead;
	}
	
	public static void main(String[] args) {
		DeleteElementsInLinkedListWhoseSumEqualTozero dl = new DeleteElementsInLinkedListWhoseSumEqualTozero();
		
		//4 6 -10 8 9 10 -19 10 -18 20 25
		dl.push(25);
		dl.push(20);
		dl.push(-18);
		dl.push(10);
		dl.push(-19);
		dl.push(10);
		dl.push(10);
		dl.push(9);
		dl.push(8);
		dl.push(-10);
		dl.push(6);
		dl.push(4);
		
		dl.printList(dl.head);
		
		System.out.println();
		
		Node remain = dl.removeCancellableNodes(dl.head);
		
		dl.printList(remain);
	}

	private void printList(Node hd) {
		// TODO Auto-generated method stub
		Node ptr=hd;
		while (ptr!=null) {
			System.out.print(""+ptr.value+" ");
			ptr = ptr.next;
		}
	}
}
