package gfg.linkedList;

/*
 * Merge a linked list into another linked list at alternate positions
 if first list is 5->7->17->13->11 and second is 12->10->2->4->6, the first list should become 5->12->7->10->17->2->13->4->11->6 and second list should become empty
 
 */
public class MergeLinkedList1 {

	 Node head;  // head of list
	 
	    /* Linked list Node*/
	    class Node
	    {
	        int data;
	        Node next;
	        Node(int d) {data = d; next = null; }
			@Override
			public String toString() {
				return "Node [data=" + data + ", next=" + next + "]";
			}
	        
	    }
	 
	    /* Inserts a new Node at front of the list. */
	    void push(int new_data)
	    {
	        /* 1 & 2: Allocate the Node &
	                  Put in the data*/
	        Node new_node = new Node(new_data);
	 
	        /* 3. Make next of new Node as head */
	        new_node.next = head;
	 
	        /* 4. Move the head to point to new Node */
	        head = new_node;
	    }
	    /* Function to print linked list */
	    void printList()
	    {
	        Node temp = head;
	        while (temp != null)
	        {
	           System.out.print(temp.data+" ");
	           temp = temp.next;
	        }
	        System.out.println();
	    }  
	    
	    static Node merge(Node h1, Node h2)
	    {
	        if (h1 == null)
	            return h2;
	        if (h2 == null)
	            return h1;
	  
	        // start with the linked list
	        // whose head data is the least
	        if (h1.data < h2.data) {
	            h1.next = merge(h1.next, h2);
	            return h1;
	        }
	        else {
	            h2.next = merge(h1, h2.next);
	            return h2;
	        }
	    }
	  
	    
	    private void merge(MergeLinkedList1 llist2) {
			// TODO Auto-generated method stub
			Node list1 = head;
			Node list2 = llist2.head;
			
			while (list2!=null) {
				Node temp = list1.next;
				list1.next = list2;
				
				Node temp2 = list2.next;
				
				list2.next = temp;
				
				if(temp==null) {
					list1 = list1.next;
				}else {
					list1 = list1.next.next;
				}
				list2 = temp2;
			}
			llist2.head=list2;
			
		}
	/* Driver program to test above functions */
    public static void main(String args[])
    {
    	MergeLinkedList1 llist1 = new MergeLinkedList1();
    	MergeLinkedList1 llist2 = new MergeLinkedList1();
        llist1.push(3);
        llist1.push(2);
        llist1.push(1);
 
        System.out.println("First Linked List:");
        llist1.printList();
 
        llist2.push(8);
        llist2.push(7);
        llist2.push(6);
        llist2.push(5);
        llist2.push(4);
 
        System.out.println("Second Linked List:");
        llist2.printList();
 
        llist1.merge(llist2);
 
        System.out.println("Modified first linked list:");
        llist1.printList();
 
        System.out.println("Modified second linked list:");
        llist2.printList();
    }
}
