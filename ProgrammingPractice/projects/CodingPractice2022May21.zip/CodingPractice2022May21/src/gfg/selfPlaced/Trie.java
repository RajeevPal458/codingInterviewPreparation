package org.gfg.dsa.selfPlaced;

// insert , search  , delete  , prefix search , Lexicographical order of words
public class Trie {

	static Node trie = new Node();
	static class Node{
		Node[] child = new Node[26];
		boolean end = false;
	}
	
	static Node root = new Node();
	static class TrieNode{
		Node[] child = new Node[2];
		boolean end = false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		insertIntrie("geeks");
		insertIntrie("geek");
		insertIntrie("bad");
		insertIntrie("bat");
		
		printTrie(trie, "");
		
		System.out.println();
		
		System.out.println("search word , exist:"+searchWorld("bads"));
		
		String del = "bad";
		System.out.println("deleted word : "+del);
		deleteWorld("bad");
		printTrie(trie, "");
		
	}
	
	public static void insertIntrie(String str) {
		Node ptr =trie;
		for (int i = 0; i < str.length(); i++) {
			int index = str.charAt(i)-'a';
			
			Node node =ptr.child[index];
			if(node==null) {
				ptr.child[index] = new Node();
			}
			 ptr =ptr.child[index];
		}
		ptr.end = true;
	}
	
	public static boolean searchWorld(String str) {
		boolean res = false;
		
		Node ptr =trie;
		for (int i = 0; i < str.length(); i++) {
			int index = str.charAt(i)-'a';
			
			Node node =ptr.child[index];
			if(node==null) {
				return false;
			}
			 ptr =ptr.child[index];
		}
		return ptr.end;
	}
	
	private static void deleteWorld(String str) {
		// TODO Auto-generated method stub
		Node root =deleteWorldUtill(trie, str, 0);
		
		trie = root;
	}

	public static Node deleteWorldUtill(Node trie , String key , int keylen) {
		
		Node ptr = trie;
		if(trie==null)
			return null;
		
		if(key.length()== keylen) {
			trie.end =false;
			if(isEmpty(trie)) {
				trie = null;
			}
			
			return trie;
		}
		
		int index = key.charAt(keylen) -'a' ;
		trie.child[index] = deleteWorldUtill(trie.child[index], key, keylen+1);
		
		if(isEmpty(trie) && trie.end==false) {
			trie = null;
		}
		
		return trie;
	}
	
	private static boolean isEmpty(Node trie) {
		// TODO Auto-generated method stub
		boolean flag =true;
		for(int i=0;i<trie.child.length;i++) {
			if(trie.child[i]!=null) {
				flag=false;
				break;
			}
				
		}
		return flag;
	}

	public static void printTrie(Node trie , String res) {
		Node ptr = trie;
		if(trie==null)
			return;
		
		if(ptr.end==true) {
			System.out.print(res+" ");
		}
		
		for (int i = 0; i < ptr.child.length; i++) {
			
			if(ptr.child[i]!=null) {
				char ch = (char)(i+'a' ) ;
				printTrie(ptr.child[i], res+ch);
			}
				
		}
	}
	
	// count distinct rows in a matrix all arr[i][j] are 0's or 1's
	// input arr[] = { {1,0,0} ,{1,1,1},{1,0,0},{1,1,1} }
	
	
	
	
}
