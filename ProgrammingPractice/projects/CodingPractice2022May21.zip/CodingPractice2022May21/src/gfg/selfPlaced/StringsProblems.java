package org.gfg.dsa.selfPlaced;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringsProblems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "bacdebgacbfv" ; String ptr = "abc" ;
		
		//System.out.println(":Anagram string starting index :"+getAllAnagramString(str, ptr));
		System.out.println(findAnagrams1(str, ptr));
		
		String str1 = "ABCD" ;  String ptr1 = "AD" ; 
		System.out.println("ptr1 is subsequence of str1 : "+isSubSequence(str1, ptr1, str1.length(), ptr1.length()));
		System.out.println("ptr1 is subsequence of str1 recursive solution : "+isSubSequenceRecursive(str1, ptr1, str1.length(), ptr1.length()));
		
		
		
		
		
		
		
		
		String s ="string";
		System.out.println("Laxico Graphic rank :"+laxicographicRankOfString(s, s.length()));
		
		String s1 = "abcdabc";
		System.out.println("Langest distinct substring : -"+longestSubString(s1, s1.length()));
		
		System.out.println("o(n) , Langest distinct substring : -"+longestSubString1(s1, s1.length()));
	}
	
	
	// given string str and other string ptr  , find all ptr's anagram matching strings in str
	// string str= "bacdebgacbfv" and String ptr = "abc" ;
	// output [0,7] starting index of anagram string .
	public static List<Integer> getAllAnagramString(String str , String ptr){
		
		List<Integer> list = new ArrayList<Integer>();
		
		int n = str.length();
		int m = ptr.length();
		
		int[] temp = new int[m];
		
		for(int i=0;i<m;i++) {
			temp[ptr.charAt(i) - 'a']++;
		}
		
		System.out.println(Arrays.toString(temp));
		
		int[] currArr = new int[m];
		
		boolean flag = true;
		for(int i=0;i<n-m+1;i++) {
			
			int j=i;
			int end = j+m;
			
			// copy temp to currarr 
			for(int k=0;k<m;k++) {
				currArr[k] = temp[k];
			}
			//System.out.println("j:"+j);
			//end
			while (j < end) {
				if((str.charAt(j)-'a') >=m || currArr[str.charAt(j)-'a'] < 0) {
					flag = false;
					//System.out.println("break "+j);
					break;
				}else {
					currArr[str.charAt(j)-'a']--;
				}
				j++;
			}
			if(flag) {
				list.add(i);
			}
			flag = true;
		}
		return list;
	}
	
	public static List<Integer> findAnagrams(String s, String p) {
	    List<Integer> res=new ArrayList<>();
	    
	    if(p.length()>s.length()) return res;
	    
	    int n=p.length(),m=s.length();
	    
	    int freq[]=new int[26];

	    for(int i=0;i<n;i++){
	        freq[p.charAt(i)-'a']++;
	        freq[s.charAt(i)-'a']--;
	    }
	    
	    System.out.println(Arrays.toString(freq));
	    
	    if(isValid(freq)) res.add(0);

	    for(int i=n;i<m;i++){
	        freq[s.charAt(i-n)-'a']++;
	        freq[s.charAt(i)-'a']--;
	        if(isValid(freq)) res.add(i-n+1);
	    }
	    return res;
	    
	}

	public static boolean isValid(int freq[]){
	    for(int i=0;i<26;i++){
	        if(freq[i]!=0) return false;
	    }
	    return true;
	}
	
	public static List<Integer> findAnagrams1(String s, String p) {
        int start=0;
        if(s.length()<p.length()) return new ArrayList<>();
        
        List<Integer> answer = new ArrayList<>();
        int[] sArray = s.chars().map(i->i-'a').toArray(); //For String "abcz"; sArray=[0,1,2,25] 
        
        int[] hashTable = new int[26];
        
        for(int i=0;i<p.length();i++) hashTable[p.charAt(i)-'a']++;
        
        int end = p.length()-1;
        
        for(int i=0;i<p.length();i++) --hashTable[sArray[i]]; //Inital window
        
        while(end<s.length()-1){
            if(isZeros26(hashTable)) answer.add(start);
            ++hashTable[sArray[start++]];
            --hashTable[sArray[++end]];
        }
        if(isZeros26(hashTable)) answer.add(start); //Last window
        return answer;
    }
    public static boolean isZeros26(int[] arr){
        int z = 0;
        for(int i: arr) if(i==0) z++;
        return z==26;
    }
    
    // check if String is subsequencec of other string 
    // String str = "ABCD" ;  String ptr = "AD" ; so here ptr is subsequence of str 
    //
    public static boolean isSubSequence(String str , String ptr , int m , int n) {
    	
    	if(m<n) {
    		return false ;
    	}
    	
    	int j=0;
    	for(int i=0;i<m;i++) {
    		
    		if(str.charAt(i) == ptr.charAt(j)) {
    			j++;
    		}
    	}
    	if(j==n) {
    		return true;
    	}else {
    		return false;
    	}
    	
    }
    // check if String is subsequencec of other string 
    // String str = "ABCD" ;  String ptr = "AD" ; so here ptr is subsequence of str 
    // recursive Solution
    public static boolean isSubSequenceRecursive(String str , String ptr , int m , int n) {
    	
    	if(n==0)
    		return true;
    	if(m==0 && n!=0)
    		return false;
    	
    	if(str.charAt(m-1) == ptr.charAt(n-1)) {
    		return isSubSequenceRecursive(str, ptr, m-1, n-1);
    	}else {
    		return isSubSequenceRecursive(str, ptr, m-1, n);
    	}
    	
    }
    
    
 // checkb if two string anagram each other
    
    
    // left most repeated character
    
    // left most non repeating char
    // reverse words of string
    
    // pattern searching problems
    //KMP , Rabin karp ,boyer moore Algo , suffix tree , z algo
    
    //  check if string is ratations of other cancate s1 with self
    
    
    
    
    // Laxicographic rank of string
    // String str = "STRING"   GINRST 5!, I....,N....,R....,STRING
    public static int laxicographicRankOfString(String str , int n) {
    	int res =1;
    	int fact = fact(n);
    	//System.out.println("len:-"+n+" , factorial : "+fact);
    	int[] arr = new int[26] ;
    	
    	for(int i=0; i<n; i++) {
    		arr[str.charAt(i)-'a']++;
    	}
    	//System.out.println(Arrays.toString(arr));
    	for(int i=1;i<26;i++) {
    		arr[i]  +=arr[i-1];
    	}
    	//System.out.println(Arrays.toString(arr));
    	for(int i=0; i<n; i++) {
    		fact = fact/(n-i);
    		res = res + arr[str.charAt(i) -'a'-1] * fact ;
    		//System.out.println("arr[str.charAt(i)-1] "+(arr[str.charAt(i)-'a'-1])+": fact:"+fact);
    		for(int j=str.charAt(i)-'a';j<26;j++) {
        		arr[j]--;
        	}
    		//System.out.println(Arrays.toString(arr));
    	}
    	return res;
    }
    public static int fact(int n) {
    	if(n==1) return 1;
    	
    	return n*fact(n-1);
    }
    
    // find longest substring with distinct character ..
    // intput String str = "abcdabc" ; output : 4 , String s = "aaa"; , output : 1;
    public static int longestSubString(String str , int n) {
    	int maxlen =0;
    	int nextmax = 0;
    	int[] count = new int[26];
    	for(int i=0;i<n;i++) {
    		for(int j=i+nextmax;j<n;j++ ) {
    			
    			if(count[str.charAt(j)-'a'] >0)
    				break;
    			else{
    				
    				if(maxlen < j-i+1) {
    					maxlen=j-i+1;
    				}
    				count[str.charAt(j)-'a']++;
    			}
    		}
    		nextmax=maxlen-i-1;
    	}
    	return maxlen;
    }
    public static boolean hasAllDistinctChar(String str,int j,int k) {
    	boolean flag = true;
    	
    	int[] count = new int[26];
    	
    	for(int i=j;i<=k;i++) {
    		if(count[str.charAt(i)-'a'] ==0)
    			count[str.charAt(i)-'a']++;
    		else {
    			flag = false; 
    			break;
    		}
    	}
    	
    	
    	return flag;
    }
    
 // find longest substring with distinct character ..
    // intput String str = "abcdabc" ; output : 4 , String s = "aaa"; , output : 1;
 // other approach 
    
    public static int longestSubString1(String str , int n) {
    	int res =0;
    	
    	int[] pre = new int[256];
    	
    	Arrays.fill(pre, -1);
    	int i=0;
    	for(int j=0;j<n;j++) {
    		i= Math.max(i, pre[str.charAt(j)]+1);
    		int maxend = j-i+1;
    		res = Math.max(res, maxend);
    		pre[str.charAt(j)] = j;
    	}
    	return res;
    }
    
    
    
    

}
