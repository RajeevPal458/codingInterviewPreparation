package org.gfg.dsa.selfPlaced;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class SearchingProblems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,4,6,8,12,15,20,24};
		int item = 12;
		System.out.println("iterative searched item index "+binarySearchIterative(arr, arr.length, item));
		
		System.out.println("recursive searched item index "+binarySearchRecursive(arr,0, arr.length-1, item));
		
		int arr1[] = {5,10,10,20,20,} ; int item1 = 10;
		System.out.println("index of first occurrence of item "+firstOccurOfEle(arr1,arr1.length, item1));
		
		System.out.println("index of last occurrence of item "+lastOccurOfEle(arr1,arr1.length, item1));
				
		int arr2[] = {5,10,10,20,20,20}  ; 
		int item2 = 20;
		System.out.println("count occurrences of given item "+countOccurOfGivenEle(arr2,arr2.length, item2));
			
		 int[] arr3 = {0,0,0,1,1,1,1} ;
		 System.out.println("count ones in given binary array  "+countOnes(arr3,arr3.length));
		 
		 int num =26;
		 System.out.println("find square root of a number  "+squareRoot(num));
		 
		 int[] arr4 = {1,4,6,8,12,15,20,24,25,27,29,30,35,39,41};
		 int item4 = 15;
		 System.out.println(" searched item index from infinite data "+searchInInfinitData(arr4, item4));
		 
		 int[] arr5 = {100,500,10,20,30,40,50} ;
		 //int searchNum =500;
		 int searchNum = 40;
		 System.out.println(" Search in sorted rotated array "+searchInSortedRotatedArr(arr5, arr5.length, searchNum));
		 
		 int arr6[] = {10,20,15,5,23,90 ,67} ;
		 //int arr6[] = {5,10,20,15,7};
		 System.out.println("Find Peek element "+findPeekElements(arr6, arr6.length));
		 
		 //unsorted array case
		 int arr7[] = {3,5,9,2,8,10,11}; 
		 int x= 17;
		 
		 System.out.println("  is Pair Exist sum of x :  "+isPaireExistOfX1(arr7, arr7.length, x));
		 
		 // sorted array case
		 int[] arr8 = {1,4,6,8,12,15,20,24,25,27,29,30,35,39,41};
		 int x1 = 30;
		 System.out.println("is  pair exists that's sum is equal to given x1 : "+isPaireExistOfX2(arr8, arr8.length, x1));
	
		 // sorted array case
		 int[] arr9 = {1,4,6,8,12,15,20,24,25,27,29,30,35,39,41};
		 int x2 = 54;
		 System.out.println("is  Triplet exists that's sum is equal to given x2 : "+isTripletExistOfX2(arr9, arr9.length, x2));
	
		 // sorted array case
		 int[] arr10 = {1,4,6,8,12,15,20,24,25,27,29,30,35,39,41};
		 System.out.println("is  Triplet exists in given form a2+b2=c2 : "+isTripletExistInGivenForm(arr10, arr10.length));
		 
		 int  arr11[] = {1,3,2,4,6,5,7,3} ;
		 System.out.println("repeating element :"+findDuplicate(arr11, arr11.length));
		 
		 int  arr12[] = {0,2,1,3,5,4,6,2} ;
		 System.out.println("0 repeating element :"+findDuplicate1(arr12, arr12.length));
		 
		 int[] arr13 = {10,20,30,40,50,60};
		 int students = 3 ;
		 System.out.println("Minimum pages naive :- "+allocateBooks(arr13, arr13.length,students));
		 
		 System.out.println("Minimum pages binary:- "+allocateBooks2(arr13, arr13.length,students));
	}
	
	// binary search iterative and recursive
	// it requires  array sorted
	public static int binarySearchIterative(int[] arr,int n,int item) {
		int st =0;
		int ed = n-1;
		int index =-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(item < arr[mid]) {
				ed = mid -1;
			}else if(item > arr[mid]) {
				st = mid+1;
			}else {
				index = mid;
				break;
			}
		}
		return index;
	}
	
	// binary search iterative and recursive
	// it requires  array sorted
	public static int binarySearchRecursive(int[] arr,int st , int ed,int item) {
		
				if(st>ed) return -1;
				
				int mid = (st+ed)/2 ;
				
				if(item < arr[mid]) {
					return binarySearchRecursive(arr, st, mid-1, item);
				}else if(item > arr[mid]) {
					return binarySearchRecursive(arr, mid+1, ed, item);
				}else {
					return mid;
				}
	}
	
	// given sorted array find index of first occurrence of element 
	// I/P: arr[] = {5,10,10,20,20,}  , search = 20
	// O/P : index : 3
	// modified binary search
	public static int firstOccurOfEle(int[] arr , int n,int item) {
		int st =0;
		int ed = n-1;
		int index =-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(item < arr[mid]) {
				ed = mid -1;
			}else if(item > arr[mid]) {
				st = mid+1;
			}else {
				if(mid==0 || arr[mid] != arr[mid-1]) {
					index = mid;
					break;
				}else {
					ed = mid-1;
				}
			}
		}
		return index;
	}
	
	// given sorted array find index of last occurrence of given element 
	// I/P: arr[] = {5,10,10,20,20,}  , search = 20
	// O/P : index : 4
	// modified binary search
	public static int lastOccurOfEle(int[] arr , int n,int item) {
		int st =0;
		int ed = n-1;
		int index =-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(item < arr[mid]) {
				ed = mid -1;
			}else if(item > arr[mid]) {
				st = mid+1;
			}else {
				if(mid==n-1 || arr[mid] != arr[mid+1]) {
					index = mid;
					break;
				}else {
					st = st+1;
				}
			}
		}
		return index;
	}
	
	// given sorted array find count of occurrences of given element 
	// I/P: arr[] = {5,10,10,20,20,20}  , search = 20
	// O/P : index : 3
	// modified binary search
	public static int countOccurOfGivenEle(int[] arr , int n,int item) {
		int startIndex = firstOccurOfEle(arr, n, item);
		int endIndex = lastOccurOfEle(arr, n, item);
		
		return endIndex -startIndex +1;
	}
	
	// count one's in a sorted binary array 
	// I/P: int[] arr = {0,0,0,1,1,1,1} ;
	public static int countOnes(int[] arr , int n) {
		
		int st =0;
		int ed = n-1;
		int res =-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(arr[mid]==0) {
				st = mid +1;
			}else {
				if(mid==0 || arr[mid-1]==0) {
					res = n-mid;
					break;
				}else {
					ed = mid - 1;
				}
			}
		}
		return res;
	}
	
	// find square root of a number if it perfect square value or return floor value of square root number
	// I/P : 16 , O/P : 4  ; I/P: 10 , O/P: 3;
	// you can't use square root function to calculate 
	public static int squareRoot( int num) {
		
		int st =1;
		int ed = num;
		int res =-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			int midsqr = mid*mid ;
			if(midsqr == num) {
				res = mid;
				break;
			}else if(midsqr > num) {
				ed = mid - 1;
			}else {
				st =mid+1;
				res = mid;
			}
		}
		return res;
	}


	// Search in an infinite sorted array 
	// unbounded binary search
	public static int searchInInfinitData(int[] arr , int item) {
		
		if(arr[0]==item) return 0;
		
		int i=1;
		while(arr[i] < item)
			i = i*2;
		if(arr[i]==item) return i;
		
		return binarySearchRecursive(arr, i/2+1, i-1,item);
	}
	
	// Search in an sorted rotated array 
	// unbounded binary search
	// I/P int[] arr = {100,500,10,20,30,40,50} ;
	// searchNum =500;
	// searchNum = 40;
	//o{logn}
	public static int searchInSortedRotatedArr(int[] arr , int n, int item) {
		int st =0;
		int ed = n-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(arr[mid] == item) return mid;
			
			if(arr[st] < arr[mid]) {
				if(item >= arr[st] && item < arr[mid]) {
					ed = mid -1;
				}else {
					st = mid +1;
				}
			}else {
				if(item > arr[mid] && item <= arr[ed]) {
					st = mid +1;
				}else {
					ed = mid -1;
				}
			}
		}
		return -1;
		
	}
	
	// find peek element , element that is larger from its neighbor 
	// input arr[] = {5,10,20,15,7};  arr[] = {10,20,15,5,23,90 ,67} ; output : 20 or 90
	// output- 20
	public static int findPeekElements(int[] arr , int n) {
		if(n==1)
			return arr[0];
		if(n==2) {
			if(arr[0]>arr[1]) {
				return arr[0];
			}else {
				return arr[1];
			}
		}
		int st =0;
		int ed = n-1;
		while (st<=ed) {
			int mid = (st+ed)/2 ;
			
			if(mid ==0 && arr[mid]>arr[mid+1] || mid ==n-1 && arr[mid]>arr[mid-1]) {
				return arr[mid];
			}
			if(arr[mid] > arr[mid-1] && arr[mid] > arr[mid+1]) return arr[mid];
			
			if(mid>0 && arr[mid-1] >= arr[mid]) {
				ed = mid-1;
			}else {
				st = mid+1;
			}
		}
		return -1;
		
	}
	
	
	// To pointer approach.
	// Given an unsorted array and a number x we need to find if there is a pair in array with equal to given x
	// input arr[] = {3,5,9,2,8,10,11}; and x= 17
	// output: yes 
	// approach 1st using HashSet
	public static boolean isPaireExistOfX1(int[] arr, int n,int x) {
		boolean flag = false;
		
		HashSet<Integer> set = new HashSet<Integer>();
		
		for(int i=0;i<n;i++) {
			if(set.contains(x-arr[i])) {
				flag = true;
				System.out.println("Pair ("+(x-arr[i])+","+arr[i]+" ) = "+x);
			}
			set.add(arr[i]);
		}
		return flag;
	}
	
	// To pointer approach.
	// Given an sorted array and a number x we need to find if there is a pair in array with equal to given x
	// input arr[] = {3,5,9,2,8,10,11}; and x= 17
	// output: yes 
	// approach 2nd using start and end vars
	public static boolean isPaireExistOfX2(int[] arr, int n , int x) {
			boolean flag = false;
			
			int st = 0;
			int ed =n-1;
			
			while (st<ed) {
				if(arr[st]+arr[ed]==x) {
					System.out.println("Pair ("+(arr[st])+","+arr[ed]+" ) = "+x);
					st++;
					flag = true;
				}else if(arr[st]+arr[ed] < x) {
					st++;
				}else if(arr[st]+arr[ed] > x) {
					ed--;
				}
			}
		return flag;	
			
	}
	
	// given a sorted array and a sum , find if there is a triplet with given sum
	// input arr[] = {3,5,9,2,8,10,11}; and x= 17
	// output: yes 
	// approach 2nd using start and end vars
	
	// second case if array is given unsorted so you use same approach after sorting in o(nlogn)  other approach also can be use like hashing
	public static boolean isTripletExistOfX2(int[] arr, int n , int x) {
			boolean flag = false;
			
			for(int i=0; i< n;i++) {
				int st = i+1;
				int ed =n-1;
				while (st<ed) {
					//if(st==i) st++;
					//if(ed==i) ed--;
					
					if(arr[i]+arr[st]+arr[ed]==x) {
						System.out.println("Triplet ("+arr[i]+","+arr[st]+","+arr[ed]+" ) = "+x);
						st++;
						flag = true;
						//break;
					}else if(arr[i]+arr[st]+arr[ed] < x) {
						st++;
					}else if(arr[i]+arr[st]+arr[ed] > x) {
						ed--;
					}
				}
				//if(flag) break;
			}
		return flag;	
				
	}
	
	// find if there is a triplet a,b,c such that  a2 +b2 = c2  form 
	// input arr[] = {3,5,9,2,8,10,11}; and x= 17
	// output: yes 
	// case one if array sorted , approach 2nd using start and end vars
	
	public static boolean isTripletExistInGivenForm(int[] arr, int n) {
			boolean flag = false;
			
			for(int i=n-1; i>1;i--) {
				int x = arr[i];
				int st = 0;
				int ed =i-1;
				while (st<ed) {
					int a =pow(arr[st], 2);
					int b =pow(arr[ed], 2);
					int c =pow(x, 2);
					
					if(a+b==c) {
						System.out.println("Triplet ("+(arr[st])+"+"+arr[ed]+" ) = "+x);
						st++;
						flag = true;
					}else if(a+b <c) {
						st++;
					}else if(a+b>c) {
						ed--;
					}
				}
			
			}
		return flag;	
					
	}

	private static int pow(int x, int n) {
		// TODO Auto-generated method stub
				if(n==1)
					return x;
				if(n==0)
					return 1;
				return x*pow(x, n-1);
	}

    // others same types problems 
	// 1) count pair's of given sum.
	// 2) count triplet's of given sum.
	//-------------------------------------------------------
	
	
	// Meadian of two sorted arrays 
	
	
	
	// Find repeating elements in array 
	// input arr[] = {1,3,2,4,6,5,7,3} ;   only one element is repeating in this array ,  output =3;
	// ideas 1) use tow loop to find duplicate , 2) sort array and loop from start and end and check n ==n-1 , 3) use temp array and use array element as index 
	// here using 4th approach 
	// 1 <= arr[i] < n-1
	public static int findDuplicate(int[] arr , int n) {
		
		int slow = arr[0];
		int fast = arr[0];
		do{
			slow = arr[slow];
			fast = arr[arr[fast]];
		}while (slow != fast) ;
		System.out.println("fast "+fast);
		slow = arr[0];
		while (slow!= fast) {
			slow = arr[slow];
			fast = arr[fast];
		}
		
		System.out.println("repeating element is :"+slow);
		return fast;
	}
	
	// input arr[] = {0,2,1,3,5,4,6,2} ; only one element is repeating in this array  output =3;  
	// ideas 1) use tow loop to find duplicate , 2) sort array and loop from start and end and check n ==n-1 , 3) use temp array and use array element as index 
	// here using 4th approach 
	// 0 <= arr[i] < n-1
	public static int findDuplicate1(int[] arr , int n) {
			
			int slow = arr[0]+1;
			int fast = arr[0]+1;
			do{
				slow = arr[slow]+1;
				fast = arr[arr[fast]+1]+1;
			}while (slow != fast) ;
			System.out.println("fast "+fast);
			slow = arr[0]+1;
			while (slow!= fast) {
				slow = arr[slow]+1;
				fast = arr[fast]+1;
			}
			
			System.out.println("0 repeating element is :"+(slow-1));
			return fast-1;
	}
	
	
	// allocate minimum number of pages (Naive method)
	// given n books with arr[i] pages each and  k student to read books so allocate these book to both students in a way so pages read by both students difference should be less books can be read contiguous only not random.
	// int[] arr = {10,20,30,40}; students =2 ,  output : 60
	//{10,20,30,40,50,60} , students =3 ,  output : 90
	public static int allocateBooks(int[] arr , int n , int kstud) {
		
		if(kstud == 1) return sum(arr, 0, n-1);
		if(n==1) return arr[0];
		
		int res = Integer.MAX_VALUE;
		for(int i=1;i<n;i++) {
			res = Math.min(res, Math.max(allocateBooks(arr, i, kstud-1), sum(arr,i,n-1)));
		}
		
	return res;
		
	}

	private static int sum(int[] arr, int st, int n) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=st ; i<=n;i++)
			sum +=arr[i];
		
		return sum;
	}
	
	// allocate minimum number of pages (Binary search)
	// given n books with arr[i] pages each and  k student to read books so allocate these book to both students in a way so pages read by both students difference should be less books can be read contiguous only not random.
	// int[] arr = {10,20,10,30}; students =2 ,  output : 40

	public static int allocateBooks2(int[] arr , int n , int kstud) {
		
		int sum =0;
		int max = Integer.MIN_VALUE;
		
		for(int i=0 ;i< n ;i++) {
			sum +=arr[i];
			max = Math.max(max, arr[i]);
		}
		
		int low = max ; int high =sum; 	int res =0;
		
		while (low<=high) {
			
			int mid = (low+high)/2 ;
			
			if(isFeasible(arr,n,kstud,mid)) {
				res = mid;
				high = mid-1;
			}else {
				low = mid+1;
			}
		}
	return res;
		
	}

	private static boolean isFeasible(int[] arr, int n, int k, int ans) {
		// TODO Auto-generated method stub
		int req =1,sum=0;
		
		for(int i=1;i<n;i++) {
			if(sum+arr[i]>ans) {
				req++;
				sum = arr[i];
			}else {
				sum +=arr[i];
			}
		}
		return req <=k;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}








