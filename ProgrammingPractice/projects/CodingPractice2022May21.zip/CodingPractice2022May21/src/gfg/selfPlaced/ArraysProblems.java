package org.gfg.dsa.selfPlaced;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ArraysProblems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {5,-2,3,4} ;
		System.out.println("Max sum:o(n^2) =>"+maxCircularSum(arr, arr.length));
		
		System.out.println("Max sum:o(n) =>"+maxCircularSum1(arr, arr.length));
		
		int arr1[] = {8 ,3,4,8,8} ;
		System.out.println(": majority element index :"+majorityElements(arr1, arr1.length));
		
		System.out.println();
		int arr2[] = {1,1,0,0,0,1};
		minflip(arr2, arr2.length);
		System.out.println();
		
		int arr3[] = {1,8,30,-5,20,7}; int k = 3;
		System.out.println("Max sum of k consecutive elements :"+maxSumOfKconsecutiveInt(arr3, arr3.length, k));
		
		int arr4[] = {1,4,20,3,10,5}; int sum = 33;
		findSubArrayWithGivenSum(arr4, arr4.length, sum);
		
		int arr5[] = {2,8,3,9,6,5,4};
		getSumInGivenRange(arr5 , arr5.length ,0,2);  
		getSumInGivenRange(arr5 , arr5.length ,1,3);
		
		getSumInGivenRange(arr5 , arr5.length ,2,6); 
		
		int arr6[] = {3,4,8,-9,20,6}; 
		checkForEquilibriumPoint(arr6, arr6.length);
		
		
		int L[] ={1,2,5,15} ; int R[] ={5,8,7,18} ; 
		findMaxAppearingEle(L, R, L.length);
		
		int L1[] ={1,2,3} ; int R1[] ={3,5,7} ; 
		findMaxAppearingEle2(L, R, L.length , 20);
		
	}
	
	// kadane's Algorithm
	public static int maxSumKadanes(int[] arr ,int n) {
		//System.out.println("kadanes : "+Arrays.toString(arr));
		int maxsum =0;
		
		int currsum=0;
		for(int i=0;i<n;i++) {
			currsum +=arr[i];
			
			if(currsum<0) 
				currsum = 0;
			else
				maxsum = Math.max(maxsum, currsum);
			
		}
		
		//System.out.println("kadanes maxsum: "+maxsum);
		return maxsum;
	}
	
	// maximum circular sum subArray 
	// arr[] = {5,-2,3,4} 
	// total subArrays = {}{5} {5,-2},{5,-2,3} {5,-2,3,4}{-2} {-2,3} {-2,3,4} {-2,3,4,5} {3} {3,4} {3,4,5}{3,4,5,-2} {4} {4,5} {4,5,-2} {4,5,-2,3} ;
	// time complexity = o(n^2) ;
	public static int maxCircularSum(int[] arr , int n) {
		int res =0;
		for(int i=0;i<n;i++) {
			int curr_max =arr[i];
			int curr_sum = arr[i];
			
			for(int j=1;j<n;j++) {
				int index = (i+j)%n;
				curr_sum +=arr[index];
				curr_max = Math.max(curr_max, curr_sum);
			}
			res = Math.max(res, curr_max);
		}
		
		return res;
	}
	
	// maximum circular sum subArray 
	// arr[] = {5,-2,3,4} 
	// total subArrays = {}{5} {5,-2},{5,-2,3} {5,-2,3,4}{-2} {-2,3} {-2,3,4} {-2,3,4,5} {3} {3,4} {3,4,5}{3,4,5,-2} {4} {4,5} {4,5,-2} {4,5,-2,3} ;
	// time complexity = o(n) ;
	//Concept to solve :--
		// 1) find max sum of normal subArray using kaddane's algorithm
	    // 2) find maximum sum of circular subArray
				//so How to find it---
					//1) the idea is if you find minimum sum of subarrays and subtract from total sum then you will get actual circular subarray sum
	public static int maxCircularSum1(int[] arr , int n) {
		int res =0;
		
		int normalMaxSumSubArr = maxSumKadanes(arr, n);
		
		int totalSum = Arrays.stream(arr).sum();
		
		//System.out.println(":normalMaxSumSubArr:"+normalMaxSumSubArr+":totalSum:"+totalSum);
		// now revert array by replacing signs so i can find max subarray sum instead of min sum subarray and then add it with total sum instead of substracting
		for(int i=0;i<n;i++) {
			arr[i] = arr[i]*-1 ;
		}
		//System.out.println(Arrays.toString(arr));
		
		int maxSumForMin = maxSumKadanes(arr, n);
		 
		int circularSubArrSum = totalSum + maxSumForMin;
		
		//System.out.println(":maxSumForMin:"+maxSumForMin+":circularSubArrSum:"+circularSubArrSum);
		
		res = Math.max(normalMaxSumSubArr, circularSubArrSum);
		
		return res;
	}
	
	// find majority elements in given Array 
	// any element in array will be majority if it occures more then n/2 times in array
	// i/p : arr[] = {8 ,3,4,8,8} so o/p :- 8
	// so first approach in o(n^2) find each elements frequency and check if any freq > n/2 return thats value
	// other approach o(n) use maurice voting algorithm 
	public static int majorityElements(int[] arr , int n) {
		int resIndex =0;
		int countRes =1;
		
		// first face find max occurance index
		for(int i=1;i<n;i++) {
			if(arr[resIndex] == arr[i]) {
				countRes++;
			}else {
				countRes--;
			}
			
			if(countRes==0) {
				resIndex=i;
				countRes =1;
			}
		}
		
		// check is it actualy majority index
		countRes=0;
		for(int i=0;i<n;i++) {
			if(arr[resIndex] == arr[i])
				countRes++;
		}
		
		if(countRes <= (n/2))
			return -1;
		
		return resIndex;
	}
	
	// given binary array find minimum consecutive flip
	// find minimum number of flip required to make all array element same (flip means change consecutive zeros to ones or change consecutive ones to zeros to make all elements same) 
	// i/p :- arr[] = {1,1,0,0,0,1}  , o/p :- from index 2 to 4
	//arr1[] = (1,1,0,0,1,0,0} or may be {1,1,1,1} or may be {0,0,0,0}
	// first approach count groups of ones and zeros and then compare if ones groups less then zeros groups then print all groups start and end index ;
	
	// other approach idea is if array start with 1's and end also at 1's then min filip will be of zeros and vise versa, if array start with 1's and end with 0's so both's flips will be equals so 
	// if we count second groups flips from beginning so that will be answer always
	public static void  minflip(int[] arr , int n) {
		
		for(int i=1; i<n ;i++) {
			if(arr[i] != arr[i-1]) {
				if(arr[i]!=arr[0]) {
					System.out.print("From "+i +" to ");
				}else {
					System.out.println( (i-1) +" end");
				}
			}
		}
		if(arr[n-1] != arr[0])
			System.out.println( (n-1) +" end");
		
	}
	
		
	
	// sliding window technique 
	// given an array of  integers and a number k find the maximum  sum of k consecutive integers
	// i/p : arr[] = {1,8,30,-5,20,7} and k = 3
	// o/p : 45
	// first approach is to solve in tow loop o(n^2) time complexity
	// second approach to solve in o(n) time complexity using sliding window technique .
	public static int maxSumOfKconsecutiveInt(int[] arr , int n, int k) {
		
		int maxsum=0;
		for(int i=0;i<k;i++) {
			maxsum +=arr[i];
		}
		
		int currsum =maxsum;
		for(int i=k;i<n;i++) {
			currsum  +=arr[i]-arr[i-k];
			maxsum = Math.max(maxsum, currsum);
		}
		
		return maxsum;
	}
	
	// given an unsorted non negative integer array and sum find out is there any sub array with given sum .
	// I/P : int arr[] = {1,4,20,3,10,5} ; int sum = 33;
	public static void findSubArrayWithGivenSum(int[] arr , int n ,int sum) {
		
		int currsum=0;
		int st =0;
		boolean flag =true;
		for(int i=0;i<n;i++) {
			if(currsum+arr[i]< sum) {
				currsum += arr[i];
			}else if(currsum+arr[i] > sum) {
				currsum  +=arr[i];
				
				while (currsum > sum) {
					currsum -= arr[st++]; 
				}
				if(currsum == sum) {
					System.out.println("start "+st+" end "+i);
					flag =false;
					break;
				}
					
			}else {
				System.out.println("start "+st+" end "+i); 
				flag =false;
				break;
			}
			
		}
		if(flag) {
			System.out.println("No sub array found with given sum");
		}
	}
	
	
	// N-bonacci number , Print first M  N-bonacci number
	// as fibonacci means t(n) = t(n-1) +t(n-2) same as for tri-binacci t(n) = t(n-1) + t(n-2) + t(n-3)
	// I/P : n =3 , m= 8;
	// O/P :  0 0 1 1 2 4 7 1 3
	//
	// 2)  count distinct alements in every window of size z
	// I/P int arr[] = {1 ,2 ,1 ,3 ,4,3,3} ; int k =4 ,  O/P :  3 4 3 2   (its count of unique number )
	

	
	//-------------------------------------------------------------------------------------------------------
	
	public static int[] prefixSumArray(int[] arr , int n) {
		int[] sumarr = new int[n];
		int sum =0;
		for(int i=0;i<n;i++) {
			sum +=arr[i];
			sumarr[i] = sum;
		}
		return sumarr;
	}
	
	// Prefix Sum 
	// Given a fixed array and multiple queries of following types on the array . how to efficiently perform these queries .
	// I/P: arr[] = {2,8,3,9,6,5,4}
	// getSum(0,2);  getSum(1,3);  getSum(2,6); 
	// O/P : 13 ,20 ,27
	public static int getSumInGivenRange(int[] arr , int n,int l,int r) {
		int[] preffix = prefixSumArray(arr, n);
		int sum=0;
		if(l==0) {
			sum = preffix[r];
		}else {
			sum = preffix[r]-preffix[l-1];
		}
		
		System.out.println("sum of given range : ("+l+","+r+" )=>"+sum);
		
		return sum;
		
	}
	
	// preffix sum  problems
	// given an array of integer find if it is has an equilibrium point 
	// I/P : arr[] = {3,4,8,-9,20,6};   here left of 20 sum is 6 and right of 20 also so it has an equilibrium point
	// O/P : yes
	// first approach you can solve it by prefix and suffix array
	// other approach solve by taking total sum to get right array sum and maintain left sum
	public static int checkForEquilibriumPoint(int[] arr, int n) {
		int point =-1;
		int sum = Arrays.stream(arr).sum();
		int left = arr[0];
		int right =0;
		for(int i=1;i<n;i++) {
			right = sum -left -arr[i];
			if(left == right) {
				point =i;
				break;
			}
			left +=arr[i];
		}
		if(point>0)
			System.out.println(":equilibrium point : Yes , index :"+point);
		else
			System.out.println(":equilibrium point : No ");

		return point;
	}
	
	
	// preffix sum  problems
	// given n ranges find the maximum appearing elements in these ranges
	// I/P: L[] ={1,2,5,15} , R[] {5,8,7,18} ;  where Li < Ri ranges => (1,5) , (2,8)...
	// O/P: 5
	// First Approach take a hash map and visit through all ranges and count frequency of all then check for max freq
	public static int findMaxAppearingEle(int[] L , int[] R , int n) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		int max=0;
		int maxval=-1;
		for(int i=0;i<n;i++) {
			int x=  L[i];
			int y = R[i];
			
			for(int j=x ; j<=y;j++) {
				map.put(j, map.containsKey(j)? map.get(j)+1:1);
				if(map.get(j)>max) {
					max = map.get(j);
					maxval = j;
				}
			}
		}
		
		System.out.println(" max occurence value is :"+maxval);
		return maxval;
	}
	
	// preffix sum  problems
		// given n ranges find the maximum appearing elements in these ranges
		// I/P: L[] ={1,2,5,15} , R[] {5,8,7,18} ;  where Li < Ri ranges => (1,5) , (2,8)...
		// O/P: 5
		// Other approach if range values are fixed like L[i]>=0 and L[i] <=10000
		public static int findMaxAppearingEle2(int[] L , int[] R , int n , int maxLi) {
			int[] temp = new int[maxLi+1] ;
			
			Arrays.fill(temp, 0);
			
			for(int i=0;i<n ;i++) {
				temp[L[i]]++;
			}
			int maxRi =0;
			for(int i=0;i<n ;i++) {
				temp[R[i]+1]--;
				if(R[i]>maxRi)
					maxRi = R[i];
			}
			
			int maxfreq=0;
			int maxval=0;
			for(int i=1;i<=maxRi ;i++) {
				temp[i] +=temp[i-1];
				if(temp[i]>maxfreq) {
					maxfreq = temp[i];
					maxval = i;
				}
				
			}
			
			
			System.out.println("using other approach max occurence value is :"+maxval +":temp:"+Arrays.toString(temp));
			return maxval;
		}
		
	
	//preffix sum  problems
	// check if given array can be divided into three parts of equal sum 
	
	
	//preffix sum  problems
	// check if there is a sub array of sum zero
	
	
	
	
	//preffix sum  problems
	// check if there is a sub array of zero sum ,  it may have multiple variations and cases like array may have positive with nigative values
	
	
	
	
	
	//preffix sum  problems
	//find the longest sub array with equal zeros and ones 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
