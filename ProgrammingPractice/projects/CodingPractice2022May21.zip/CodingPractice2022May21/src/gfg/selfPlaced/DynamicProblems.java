package org.gfg.dsa.selfPlaced;

public class DynamicProblems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	
	// 0/1 knapsake problem 
	// coin change count combinations
	// Edit distance
	// longest common subsequence problem
	//minimum insertion , deletion and replace to convert s1 into s2 string
	// sortest common supersequence .
	// longest pelindromic subsequence.
	// longest repeating subsequence.
	

}
