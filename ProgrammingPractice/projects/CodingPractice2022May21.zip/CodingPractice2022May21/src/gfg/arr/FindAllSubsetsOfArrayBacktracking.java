package gfg.arr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 * https://www.geeksforgeeks.org/backtracking-to-find-all-subsets/
 * Backtracking to find all subsets
 * 
 * 
 * Time Complexity: O(n. 2^n). 
Total number of subsets generated are 2^n, So Time Complexity is O(2^n). If we include the time taken to copy the subset vector into the res vector the time taken will be equal to the size of the subset vector.
Space Complexity: O(n . 2^n). 
We are using a vector of vectors to store 2^n subsets in which each has an approximate length of n. Hence, the Space Complexity comes out to be O(n. 2^n).
Auxiliary Space: O(n) There can be at max n recursion calls at a particular time, which would consume O(n) stack space. 


https://www.geeksforgeeks.org/count-unique-subsequences-of-length-k/
 * @author rajeevkumar.pal
 *
 */
public class FindAllSubsetsOfArrayBacktracking {

	private static List<List<Integer>> allsubset =null;
	 // Driver code
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,2,3,4};
		int k=2;
		//findAllSubArrayOfSizeK(arr,k);
		subsetBitwise(arr, arr.length);
	}

	private static void findAllSubArrayOfSizeK(int[] arr, int k) {
		int n1 = arr.length;
		allsubset = new ArrayList<>();
		
		subsetUtill(arr, n1, new ArrayList<Integer>(), 0, k);
		
	      // Comparator is used so that all subset get
	      // sorted in ascending order of values
	        Collections.sort(allsubset, (o1, o2) -> {
	            int n = Math.min(o1.size(), o2.size());
	            for (int i = 0; i < n; i++) {
	                if (o1.get(i) == o2.get(i)){
	                    continue;
	                }else{
	                    return o1.get(i) - o2.get(i);
	                }
	            }
	            return 1;
	        });
	        
		for(List<Integer> subset:allsubset) {
			System.out.println(subset);
		}
		System.out.println("Total count :-"+allsubset.size());
	}


	private static void subsetUtill(int[] arr , int n,List<Integer> currsubset,int index,int k) {
		
		if(currsubset.size() == k) {
			allsubset.add(currsubset);
			return;
		}
		
		if(index>=n) return;
		
		subsetUtill(arr, n, new ArrayList<Integer>(currsubset), index+1, k);
		
		List<Integer> list = new ArrayList<Integer>(currsubset);
		list.add(arr[index]);
		
		subsetUtill(arr, n, list, index+1, k);
		
		
	}
	
	static void combinationUtil(int arr[], int n, int r,
			int index, int data[], int i){
		// Current combination is ready to be printed,
		// print it
		if (index == r) {
			for (int j = 0; j < r; j++)
				System.out.print(data[j] + " ");
			System.out.println("");
			return;
		}
		// When no more elements are there to put in data[]
		if (i >= n)
			return;
		
		// current is included, put next at next
		// location
		data[index] = arr[i];
		combinationUtil(arr, n, r, index + 1,
						data, i + 1);
		
		// current is excluded, replace it with
		// next (Note that i+1 is passed, but
		// index is not changed)
		combinationUtil(arr, n, r, index, data, i + 1);
	}
	
	public static void subsetBitwise(int[] arr , int n) {
		
		for(int i=0;i<Math.pow(2, n);i++) {
			int count =0;
			String str ="";
			String str1 ="";
			for(int j=0;j<n;j++) {
				
				if((i & (1<<j)) >0) {
					count++;
					str =str.concat(arr[j]+" ");
					str1 =str1.concat(j+" ");
				}
				
			}
			if(count==3)
			System.out.println(str +":i:"+i +":j:"+str1);
		}
	}

}

