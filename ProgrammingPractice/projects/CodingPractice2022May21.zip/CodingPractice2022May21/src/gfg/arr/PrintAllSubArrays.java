package gfg.arr;

/**
 * 
 * Subarray/Substring vs Subsequence and Programs to Generate them
 * https://www.geeksforgeeks.org/subarraysubstring-vs-subsequence-and-programs-to-generate-them/
 * 
 * @author rajeevkumar.pal
 *
 */
public class PrintAllSubArrays {

	 static int arr[] = new int[]{1, 2, 3, 4};
     
	    // Prints all subarrays in arr[0..n-1]
	    static void subArray( int n)
	    {
	        // Pick starting point
	        for (int i=0; i <n; i++)
	        {
	            // Pick ending point
	            for (int j=i; j<n; j++)
	            {
	                // Print subarray between current starting
	                // and ending points
	                for (int k=i; k<=j; k++)
	                    System.out.print(arr[k]+" ");
	                System.out.println();
	            }
	        }
	    }
	     
	    static void subArray2( int n)
	    {
	        // Pick starting point
	        for (int i=0; i <n; i++)
	        {
	        	String str="";
	            // Pick ending point
	            for (int j=i; j<n; j++)
	            {
	                // Print subarray between current starting
	                // and ending points
	            	str +=arr[j]+" ";
	                System.out.println(str);
	            }
	        }
	    } 
	    
	    // Driver method to test the above function
	    public static void main(String[] args) 
	    {
	        System.out.println("All Non-empty Subarrays");
	        subArray2(arr.length);
	          
	    }
}
