package gfg.arr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

/**
 * Minimum number of swaps required to sort an array
 * https://www.geeksforgeeks.org/minimum-number-swaps-required-sort-array/
 * Given an array of n distinct elements, find the minimum number of swaps required to sort the array.
 * Examples: 

Input: {4, 3, 2, 1}
Output: 2
Explanation: Swap index 0 with 3 and 1 with 2 to 
              form the sorted array {1, 2, 3, 4}.

Input: {1, 5, 4, 3, 2}
Output: 2
 * @author rajeevkumar.pal
 *
 */
public class MinimumNumberOfSwapsRequiredToSortArray {

	
	static class Pair<T,T1>{
		T key;
		T1 value;
		
		public Pair(T key, T1 value) {
			super();
			this.key = key;
			this.value = value;
		}
		public T getKey() {
			return key;
		}
		public void setKey(T key) {
			this.key = key;
		}
		public T1 getValue() {
			return value;
		}
		public void setValue(T1 value) {
			this.value = value;
		}
		@Override
		public String toString() {
			return "Pair [key=" + key + ", value=" + value + "]";
		}
		
		
		
	}
	// Function returns the 
    // minimum number of swaps
    // required to sort the array
    public static int minSwaps(int[] arr)
    {
        int n = arr.length;
  
        // Create two arrays and 
        // use as pairs where first
        // array is element and second array
        // is position of first element
        ArrayList<Pair <Integer, Integer> > arrpos =
                  new ArrayList <Pair <Integer, 
                                      Integer> > ();
        for (int i = 0; i < n; i++)
             arrpos.add(new Pair <Integer, 
                               Integer> (arr[i], i));
  
        // Sort the array by array element values to
        // get right position of every element as the
        // elements of second array.
        arrpos.sort(new Comparator<Pair<Integer, 
                                         Integer>>()
        {
            @Override
            public int compare(Pair<Integer, Integer> o1,
                               Pair<Integer, Integer> o2)
            {
                if (o1.getKey() > o2.getKey())
                    return 1;
                else if (o1.getKey() < o2.getKey())
                    return -1;
                else
                    return 1;
            }
        });
  
        // 3 1 5 2 4 , count =2 , visited :-  1 3 0
        // 1 3 5 2 4 , 1 2 5 3 4 , 1 2 
        // To keep track of visited elements. Initialize
        // all elements as not visited or false.
        Boolean[] vis = new Boolean[n];
        Arrays.fill(vis, false);
  
        // Initialize result
        int ans = 0;
        //[Pair [key=1, value=3], Pair [key=2, value=2], Pair [key=3, value=1], Pair [key=4, value=0]]
        System.out.println(Arrays.toString(arr));
        System.out.println(arrpos);
        // Traverse array elements
        for (int i = 0; i < n; i++)
        {
            // already swapped and corrected or
            // already present at correct pos
            if (vis[i] || arrpos.get(i).getValue() == i)
                continue;
  
            // find out the number of  node in
            // this cycle and add in ans
            int cycle_size = 0;
            int j = i;
            int temp =arr[j];
            while (!vis[j])
            {
                vis[j] = true;
  
                // move to next node
                int x = arrpos.get(j).getValue();
                cycle_size++;
               if(vis[x])
            	   arr[j]=temp;
               else
            	   arr[j]=arr[x];
                j=x;
            }
            // Update answer by adding current cycle.
            if(cycle_size > 0)
            {
                ans += (cycle_size - 1);
            }
        }
  
        System.out.println("sorted array:-"+Arrays.toString(arr));
        // Return result
        return ans;
    }
    
 // Function returns the
    // minimum number of swaps
    // required to sort the array
    public static int minSwaps1(int[] nums)
    {
        int len = nums.length;
        HashMap<Integer, Integer> map = new HashMap<>();
        for(int i=0;i<len;i++)
            map.put(nums[i], i);
              
        Arrays.sort(nums);   
          
          // To keep track of visited elements. Initialize
        // all elements as not visited or false.
        boolean[] visited = new boolean[len];
        Arrays.fill(visited, false);
          
          // Initialize result
        int ans = 0;
        for(int i=0;i<len;i++) {
            
              // already swapped and corrected or
            // already present at correct pos
            if(visited[i] || map.get(nums[i]) == i)
                continue;
                  
            int j = i, cycle_size = 0;
            while(!visited[j]) {
                visited[j] = true;
                  
                  // move to next node
                j = map.get(nums[j]);
                cycle_size++;
            }
              
              // Update answer by adding current cycle.
            if(cycle_size > 0) {
                ans += (cycle_size - 1);
            }
        }
        return ans;
    }
    
    
 // Return the minimum number
    // of swaps required to sort the array
    public int minSwaps(int[] arr, int N)
    {
  
        int ans = 0;
        int[] temp = Arrays.copyOfRange(arr, 0, N);
  
        // Hashmap which stores the
        // indexes of the input array
        HashMap<Integer, Integer> h
            = new HashMap<Integer, Integer>();
  
        Arrays.sort(temp);
        for (int i = 0; i < N; i++) 
        {
            h.put(arr[i], i);
        }
        for (int i = 0; i < N; i++) 
        {
  
            // This is checking whether
            // the current element is
            // at the right place or not
            if (arr[i] != temp[i]) 
            {
                ans++;
                int init = arr[i];
  
                // If not, swap this element
                // with the index of the
                // element which should come here
                swap(arr, i, h.get(temp[i]));
  
                // Update the indexes in
                // the hashmap accordingly
                h.put(init, h.get(temp[i]));
                h.put(temp[i], i);
            }
        }
        return ans;
    }
    
    public void swap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    
 // Return the minimum number
    // of swaps required to sort the array
    public int minSwaps2(int[] arr, int N)
    {
        int ans = 0;
        int[] temp = Arrays.copyOfRange(arr, 0, N);
        Arrays.sort(temp);
        for (int i = 0; i < N; i++) 
        {
  
            // This is checking whether
            // the current element is
            // at the right place or not
            if (arr[i] != temp[i]) 
            {
                ans++;
  
                // Swap the current element
                // with the right index
                // so that arr[0] to arr[i] is sorted
                swap(arr, i, indexOf(arr, temp[i]));
            }
        }
        return ans;
    }
    
    public int indexOf(int[] arr, int ele)
    {
        for (int i = 0; i < arr.length; i++) 
        {
            if (arr[i] == ele) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args)
    {
        int []a = {4,3,2,1};
        MinimumNumberOfSwapsRequiredToSortArray g = new MinimumNumberOfSwapsRequiredToSortArray();
        System.out.println(g.minSwaps(a));
    }
  
}
