package gfg.arr;

import java.util.TreeSet;

/**
 * https://www.geeksforgeeks.org/subarray-whose-sum-is-closest-to-k/
 * Subarray whose sum is closest to K
 * Given an array of positive and negative integers and an integer K. The task is to find the subarray which has its sum closest to k. In case of multiple answers, print anyone. 

Note: Closest here means abs(sum-k) should be minimal. 

Input: a[] = { 2, 2, -1, 5, -3, -2 }, K = 7 
Output: 6 
Here the output can be 6 or 8 
The subarray {2, 2, -1, 5} gives sum as 8 which has abs(8-7) = 1 which is same as that of the subarray {2, -1, 5} which has abs(6-7) = 1. 
 * @author rajeevkumar.pal
 *
 */
public class SubarraywhosesumIsClosesttoK {

	// Driver Code
	  public static void main(String[] args)
	  {
	    int a[] = { 2, 2, -1, 5, -3, -2 };
	    int n = a.length;
	    int k = 7;
	 
	    System.out.print(closestSubarraySumToKBruetforce(a, n, k));
	  }

	private static int closestSubarraySumToKBruetforce(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		
		int diff = Integer.MAX_VALUE;
		int sum =0;
		for(int i=0;i<n;i++) {
			int currsum =0;
			for(int j=i;j<n;j++) {
				
				 currsum = currsum +arr[j];
				int currdiff =Math.abs(k-currsum);
				
				if(currdiff ==0) {
					sum =currsum;
					break;
				}else if(currdiff< diff) {
					sum = currsum;
					diff = currdiff;
				}
				
			}
		}
		
		return sum;
	}
	
	
	
	// Function to find the sum of subarray
	  // whose sum is closest to K
	  static int closestSubarraySumToK1(int a[], int n, int k)
	  {
	 
	    // Declare a set
	    TreeSet<Integer> s = new TreeSet<>();
	 
	    // initially consider the
	    // first subarray as the first
	    // element in the array
	    int presum = a[0];
	 
	    // insert
	    s.add(a[0]);
	 
	    // Initially let this difference
	    // be the minimum
	    int mini = Math.abs(a[0] - k);
	 
	    // let this be the sum
	    // of the subarray
	    // to be searched initially
	    int sum = presum;
	 
	    // iterate for all the array elements
	    for (int i = 1; i < n; i++) {
	 
	      // calculate the prefix sum
	      presum += a[i];
	 
	      // find the closest subarray
	      // sum to by using lower_bound
	      Integer it = s.lower(presum - k);
	 
	      // if it is the first element
	      // in the set
	      if (it == s.first()) {
	 
	        // get the prefix sum till start
	        // of the subarray
	        int diff = it;
	 
	        // if the subarray sum is closest to K
	        // than the previous one
	        if (Math.abs((presum - diff) - k) < mini) {
	 
	          // update the minimal difference
	          mini = Math.abs((presum - diff) - k);
	 
	          // update the sum
	          sum = presum - diff;
	        }
	      }
	 
	      // if the difference is
	      // present in between
	      else if (it == s.last()) {
	 
	        // get the prefix sum till start
	        // of the subarray
	        int diff = it;
	 
	        // if the subarray sum is closest to K
	        // than the previous one
	        if (Math.abs((presum - diff) - k) < mini) {
	 
	          // update the minimal difference
	          mini = Math.abs((presum - diff) - k);
	 
	          // update the sum
	          sum = presum - diff;
	        }
	 
	        // also check for the one before that
	        // since the sum can be greater than
	        // or less than K also
	        it--;
	 
	        // get the prefix sum till start
	        // of the subarray
	        diff = it;
	 
	        // if the subarray sum is closest to K
	        // than the previous one
	        if (Math.abs((presum - diff) - k) < mini) {
	 
	          // update the minimal difference
	          mini = Math.abs((presum - diff) - k);
	 
	          // update the sum
	          sum = presum - diff;
	        }
	      }
	 
	      // if there exists no such prefix sum
	      // then the current prefix sum is
	      // checked and updated
	      else {
	 
	        // if the subarray sum is closest to K
	        // than the previous one
	        if (Math.abs(presum - k) < mini) {
	 
	          // update the minimal difference
	          mini = Math.abs(presum - k);
	 
	          // update the sum
	          sum = presum+1;
	        }
	      }
	 
	      // insert the current prefix sum
	      s.add(presum);
	    }
	 
	    return sum;
	  }

}
