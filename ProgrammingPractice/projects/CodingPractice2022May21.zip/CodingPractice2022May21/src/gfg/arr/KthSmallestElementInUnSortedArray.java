package gfg.arr;

import java.util.Arrays;
import java.util.Collections;
import java.util.PriorityQueue;

/**
 * 
 * https://www.geeksforgeeks.org/kth-smallestlargest-element-unsorted-array/
 * K’th Smallest/Largest Element in Unsorted Array | Set 1
 * @author rajeevkumar.pal
 *
 */

public class KthSmallestElementInUnSortedArray {
	 public static void main(String[] args){
	        int[] arr = { 12, 3, 5, 7, 19, 1, 2, 3, 4 };
	        int n = arr.length;
	        int k = 4;
	        kthsmallest(arr, n, k);
	        
	        int kthSmallest = kthSmallest(arr, k);
	        System.out.println("kthSmallest:-"+kthSmallest);
	 }
	 
	 public static int kthSmallest(Integer[] arr,int k){
		// Sort the given array
		Arrays.sort(arr);
		
		// Return k'th element in
		// the sorted array
		return arr[k - 1];
	}
	 
	 public static void kthsmallest(int[] arr , int n ,int k) {
		 
		 PriorityQueue<Integer> queue = new PriorityQueue<Integer>(Collections.reverseOrder());
		 
		 for(int i=0;i<n;i++) {
			 
			 queue.add(arr[i]);
			 
			 if(queue.size()>k) {
				 queue.remove();
			 }
			 
			 //if(!queue.contains(arr[i]))
		 }
		 System.out.println(queue +" ,Kth smallest element:-"+queue.peek());
	 }
	 
	 static int count(int [] nums, int mid)
	    {
	        // function to calculate number of elements less than equal to mid
	            int cnt = 0;
	              
	            for(int i = 0; i < nums.length; i++)
	               if(nums[i] <= mid)
	                  cnt++;
	              
	            return cnt;
	    }
	          
	      
	    static int kthSmallest(int [] nums, int k)
	    {
	            int low = Integer.MAX_VALUE;
	            int high = Integer.MIN_VALUE;
	            //calculate minimum and maximum the array.
	            for(int i = 0; i < nums.length; i++)
	            {
	                low = Math.min(low, nums[i]);
	                high = Math.max(high, nums[i]);
	            }
	            //Our answer range lies between minimum and maximum element of the array on which Binary Search is Applied
	            while(low < high)
	            {
	                int mid = low + (high - low) / 2;
	               /*if the count of number of elements in the array less than equal to mid is less than k
	                 then increase the number. Otherwise decrement the number and try to find a better answer.
	               */
	                if(count(nums, mid) < k)
	                   low = mid + 1;
	                     
	                else
	                    high = mid;
	            }
	              
	            return low;
	    }
}
