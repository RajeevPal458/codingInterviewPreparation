package gfg.arr;

import java.util.ArrayList;
import java.util.List;

/***
 * Check loop in array according to given constraints
 * Given an array arr[0..n-1] of positive and negative numbers we need to find if there is a cycle in array with given rules of movements.
 *  If a number at an i index is positive, then move arr[i]%n forward steps, i.e., next index to visit is (i + arr[i])%n. Conversely, 
 *  if it’s negative, move backward arr[i]%n steps i.e., next index to visit is (i – arr[i])%n. Here n is size of array. If value of arr[i]%n is zero, then 
 *  it means no move from index i.
 * @author rajeevkumar.pal
 *
 */
public class DetectCycleInArr {

	public static void main(String[] args) {
		 int arr[] = {2, -1, 1, 2, 2};
		 //int arr[] = {1, 1, 1, 1, 1, 1};
		 //int arr[] = {1, 2} ;
		 
		    int n = arr.length;
		    if (isCycle(arr, n))
		        System.out.println("YES");
		    else
		    	System.out.println("NO");
	}

	private static boolean isCycle(int[] arr, int n) {
		
		List<Integer> list=new ArrayList<Integer>();
		int nextind=0;
		
		list.add(new Integer(nextind));
		
		boolean flag =false;
		int i=0 ;
		while(true){
			if(arr[i]<0) {
				nextind=( (n+1)-(i-(-1*arr[i])+n)%n );
			}else {
				nextind=(i+arr[i]+n)%n;  // (5)/2
			}
			System.out.println(":nextind:"+nextind +"::"+list.toString());
			if(list.contains(new Integer(nextind)))
			{
				flag= true;
				break;
			}
			list.add(new Integer(nextind));
			
			i=nextind ;
		}
		
		return flag;
	}
}

