package gfg.arr;

import java.util.Arrays;
import java.util.Scanner;

//Check if it is possible to reach end of given Array by Jumping
/**
 * Problem
Given an array with positive integers as elements indicating the maximum length of a jump which can be made from any position in the array. 
Check if it is possible to have a jumps combination so that you can eventually reach the end of given array. Print "true" if it is possible, 
otherwise, print "false".
Input :
[1, 5, 2, 1, 0, 2, 0]
Output :
true
 * @author rajeevkumar.pal
 *
 */
public class CheckIfItIsPossibleToReachEndOfGivenArrayByJumping {

	public static void main(String[] args) {
		 
        //int[]arr = {2,3,1,1,4};
		int[]arr = {2,3,1,1,4};
        System.out.println(solve(arr));
        
        System.out.println(minJumps2(arr,0,arr.length-1));
 
    }
	
	public static boolean solve(int cp, int[] arr) {
        /* base case : if the current position of the pointer
         * is at last element of the array which indicates
         * that we have reached the end of the array, then
         * we can return true from here*/
        if (cp == arr.length-1) {
            return true;
        }
        /* if maximum jump which we can make from current
         * position is zero, then there is no way we can
         * reach end of array using the current combination
         * of jumps, hence return false from here */
        if (arr[cp] == 0) {
            return false;
        }
        boolean rv = false;
 
        /* start from current position, and make all the jumps of
         * possible length, and make a recursive call which
         * eventually changes our current position */
        for (int jump = 1; jump <= arr[cp]; jump++) {
            if(cp + jump < arr.length){
                /* here we use logical 'or' operator because any true
                 * result is sufficient enough to  prove that a jumps
                 * combination exists with which we can reach end of
                 * given array*/
                rv = rv || solve(cp + jump, arr);
            }
        }
        return rv;
    }
	
	
	
	public static boolean solve(int[] arr) {
        /* dp array to store the result of every index, that is,
         * if they are reachable or not, true indicates that there
         * exists one or more jump combinations to reach that index,
         * and no jump combination exist in case of a false*/
        boolean[] dp = new boolean[arr.length];
 
        /* first index is always reachable, as this is the position
         * we start from*/
        dp[0] = true;
 
        /*finding result for every index*/
        for (int currPos = 0; currPos < arr.length; currPos++) {
            /* if the index we are currently at is not reachable from
             * 0th index, then we obviously can not make further jumps
             * from this position.
             * Also, number of jumps possible from the current position
             * needs to be greater than zero, as in case of zero, we can
             * not move to any other position by making a jump*/
            if (dp [currPos] && arr [currPos] > 0) {
                int maxJumps = arr[currPos];
                /* mark all the reachable positions from current position
                 * true because, if they can be reached from an intermediate
                 * spot, and that intermediate spot can be reached from zero,
                 * then the jumped position will also be reachable from zeroth
                 * index*/
                for (int jump = 1; jump <= maxJumps; jump++) {
                    if(currPos + jump < dp.length)
                    {
                        dp[currPos+jump] =  true;
                    }
                }
                
                System.out.println(Arrays.toString(dp));
            }
        }
 
        /*return the result of last index of the array if it is reachable
         * from zeroth index or not*/
        return dp [arr.length-1];
    }
	
	// Returns minimum number of
    // jumps to reach arr[h] from arr[l]  {3,2,1,0,4}
    static boolean minJumps2(int arr[], int l, int h)
    {
        // Base case: when source
        // and destination are same
    	if(l>h) return false;
    	
        if (h == l)
            return true;
 
        // When nothing is reachable
        // from the given source
        if (arr[l] == 0)
            return false;
 
        // Traverse through all the points
        // reachable from arr[l]. Recursively
        // get the minimum number of jumps
        // needed to reach arr[h] from these
        // reachable points.
        for (int i = arr[l]; i>0;i--) {
            if (minJumps2(arr, l+i, h))
                return true;
        }
        return false;
    }
}
