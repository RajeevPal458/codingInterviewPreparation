package gfg.arr;

/**
 * Find maximum (or minimum) sum of a subarray of size k
 * https://www.geeksforgeeks.org/find-maximum-minimum-sum-subarray-size-k/
 * Given an array of integers and a number k, find the maximum sum of a subarray of size k. 

Examples: 

Input  : arr[] = {100, 200, 300, 400}
         k = 2
Output : 700

 * @author rajeevkumar.pal
 *
 */
public class FindMaxSumOfASubarrayOfSizek {

	/* Driver program to test above function */
    public static void main(String[] args)
    {
        int arr[] = {100, 200, 300, 400}; // {1, 4, 2, 10, 2, 3, 1, 0, 20};
        int k = 2;
        int n = arr.length;
        System.out.println(maxSum(arr, n, k));
    }

	private static int maxSum(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int res =0;
		int sum =0;
		int currSum=0;
		
		for(int i=0;i<k;i++) {
			sum +=arr[i];
		}
		res =sum;
		currSum =sum;
		for(int i=k;i<n;i++) {
			
			currSum +=arr[i] -arr[i-k];
			
			res =Math.max(currSum, res);
		}
		
		return res;
	}
    
}
