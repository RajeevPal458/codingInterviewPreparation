package gfg.arr;

/**
 * Subarray whose absolute sum is closest to K
 * https://www.geeksforgeeks.org/subarray-whose-absolute-sum-is-closest-to-k/
 * 
 * @author rajeevkumar.pal
 *
 */
..
public class SubarrayWhoseAbsoluteSumisClosesttoK {

	public static int[] getSubArray(int[] arr, int n,int K){
		int i = -1;
		int j = -1;
		int currSum = 0;
		
		// Starting index, ending index, Deviation
		int [] result = { i, j,
		  Math.abs(K -
		  Math.abs(currSum)) };
		
		// Iterate i and j to get all subarrays
		for(i = 0; i < n; i++){
			currSum = 0;
			
			for(j = i; j < n; j++){
				
				currSum += arr[j];
				int currDev = Math.abs(K -
				      Math.abs(currSum));
				
				// Found sub-array with less sum
				if(currDev < result[2])
				{
					result[0] = i;
					result[1] = j;
					result[2] = currDev;
				}
				
				// Exactly same sum
				if(currDev == 0)
				return result;
			}
		}
		return result;
	}
	
	static class Pair
	{
	    int f, s, t;
	 
	    Pair(int f, int s, int t)
	    {
	        this.f = f;
	        this.s = s;
	        this.t = t;
	    }
	};
	 
	// Function to return the index
	static Pair getSubArrayLinear(int []arr, int n, int K)
	{
	    int currSum = 0;
	    int prevDif = 0;
	    int currDif = 0;
	     
	    Pair result = new Pair(
	        -1, -1, Math.abs(K - Math.abs(currSum)));
	    Pair resultTmp = result;
	    int i = 0;
	    int j = 0;
	     
	    while (i<= j && j<n)
	    {
	         
	        // Add Last element tp currSum
	        currSum += arr[j];
	         
	        // Save Difference of previous Iteration
	        prevDif = currDif;
	         
	        // Calculate new Difference
	        currDif = K - Math.abs(currSum);
	         
	        // When the Sum exceeds K
	        if (currDif <= 0)
	        {
	            if (Math.abs(currDif) < Math.abs(prevDif))
	            {
	                 
	                // Current Difference greater
	                // in magnitude. Store Temporary
	                // Result
	                resultTmp = new Pair(i, j, currDif);
	            }
	            else
	            {
	                 
	                // Difference in Previous was lesser
	                // In previous, Right index = j-1
	                resultTmp = new Pair(i, j - 1, prevDif);
	                      
	                // In next iteration, Left Index Increases
	                // but Right Index remains the Same
	                // Update currSum and i Accordingly
	                currSum -= (arr[i] + arr[j]);
	                 
	                i += 1;
	            }
	        }
	         
	        // Case to simply increase Right Index
	        else
	        {
	            resultTmp = new Pair(i, j, currDif);
	            j += 1;
	        }
	          
	        if (Math.abs(resultTmp.t) < Math.abs(result.t))
	        {
	             
	            // Check if lesser deviation found
	            result = resultTmp;
	        }
	    }
	    return result;
	}
	//Driver Code
	public static void main(String[] args){
		int[] arr = { 2, 2, -1, 5, -3, -2 };
		int n = arr.length;
		int K = 7;
		
		// Array to store return values
		int[] ans = getSubArray(arr, n, K);
		
		if(ans[0] == -1)
		{
			System.out.println("The empty array " +
		       "shows minimum Deviation");
		}
		else
		{
			for(int i = ans[0]; i <= ans[1]; i++)
				System.out.print(arr[i] + " ");
		}
		
		Pair ans1 = getSubArrayLinear(arr, n, K);
		
		System.out.println();
		for(int i = ans1.f; i <= ans1.s; i++)
			System.out.print(arr[i] + " ");
		System.out.print(ans1.t + " ");
		
		System.out.println();
	
	
	
	
	
	}
}
