package gfg.arr;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Eg: Array= [ 5,3,5,7,8] and k=3 , The answer is 2 as [3,5,7] and [5,7,8] are the answer.
 * Count the number of strictly increasing subarray of a specified size k in an array of size N .
 * 
 * int[] arr = {1,2,1,3,2,3};
 * @author rajeevkumar.pal
 *
 */
public class FindAllIncreasingSubarraysOfSizek {

static int arr[] = new int[]{5,3,5,7,8};
	
	static int countIncreasing(int n)
	{
		// Initialize count of subarrays as 0
		int cnt = 0;
	
		// Pick starting point
		for (int i=0; i<n; i++)
		{
			// Pick ending point
			for (int j=i+1; j<n; j++)
			{
				if (arr[j] > arr[j-1])
					cnt++;
	
				// If subarray arr[i..j] is not strictly
				// increasing, then subarrays after it , i.e.,
				// arr[i..j+1], arr[i..j+2], .... cannot
				// be strictly increasing
				else
					break;
			}
		}
		return cnt;
	}
	
	static void printAllIncreasing(int[] arr, int n,int k)
	{
	//{5,3,5,7,8}
		List<Integer> list = new LinkedList<Integer>();
		list.add(arr[0]);
		for(int i=1;i<n;i++) {
			
			if(list.size() ==k) {
				System.out.println(list);
				list.remove(0);
			}
			if(arr[i] > arr[i-1]) {
				list.add(arr[i]);
			}else {
				list = new LinkedList<Integer>();
				list.add(arr[i]);
			}
			
		}
		if(list.size()==k) {
			System.out.println(list);
		}
		
		
	}

	// Driver method to test the above function
	public static void main(String[] args)
	{
		System.out.println("Count of strictly increasing subarrays is " +
											countIncreasing(arr.length));
		
		printAllIncreasing(arr, arr.length, 3);
	}

}
