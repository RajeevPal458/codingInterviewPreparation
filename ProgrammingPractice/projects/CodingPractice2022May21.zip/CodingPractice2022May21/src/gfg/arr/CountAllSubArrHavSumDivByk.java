package gfg.arr;

import java.util.HashMap;
import java.util.Map;

/**
 * Count all sub-arrays having sum divisible by k
 * @author rajeevkumar.pal
 *
 */
public class CountAllSubArrHavSumDivByk {

	public static void main(String[] args) {
		int arr[] = {4, 5, 0, -2, -3, 1};
	    int k = 5;
	    int n = arr.length;
	    System.out.println(subCount(arr, n, k));
	    
	    int arr1[] = {4, 5, 0, -12, -23, 1};
	    int k1 = 5;
	    int n1 = arr1.length;
	    System.out.println(subCount(arr1, n1, k1));
	}

	private static int subCount(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int resSum=0;
		int currSum=0;
		// <Reminder , count>
		//Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		int[] mod = new int[k];
		
		
		for(int i=0 ;i< n; i++) {
			
			currSum += arr[i];
			//System.out.println(":currSum:"+currSum);
			// as the sum can be negative, taking modulo twice
			int indexRem =((currSum % k) + k) % k;
			if(indexRem==0&&mod[indexRem]==0) {
				resSum+=1;
			}else if(mod[indexRem] >0){
				resSum +=mod[indexRem] ;
			}
			
			mod[indexRem]++;
		}
		
		
		return resSum;
	}
	
	private static int subCount1(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		int resSum=0;
		int currSum=0;
		// <Reminder , count>
		//Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		int[] mod = new int[k];
		
		
		for(int i=0 ;i< n; i++) {
			
			currSum += arr[i];
			//System.out.println(":currSum:"+currSum);
			// as the sum can be negative, taking modulo twice
			int indexRem =((currSum % k) + k) % k;
			if(indexRem==0&&mod[indexRem]==0) {
				resSum+=1;
			}else if(mod[indexRem] >0){
				resSum +=mod[indexRem] ;
			}
			
			mod[indexRem]++;
		}
		
		
		return resSum;
	}
		
}
