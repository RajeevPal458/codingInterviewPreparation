package gfg.arr;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Check if the end of the Array can be reached from a given position
 * https://www.geeksforgeeks.org/check-if-the-end-of-the-array-can-be-reached-from-a-given-position/
 * 
 * Given an array arr[] of N positive integers and a number S, the task is to reach the end of the array from index S. We can only move from current index i 
 * to index (i + arr[i]) or (i – arr[i]). If there is a way to reach the end of the array then print “Yes” else print “No”.

Examples: 

Input: arr[] = {4, 1, 3, 2, 5}, S = 1 
Output: Yes 
Explanation: 
initial position: arr[S] = arr[1] = 1. 
Jumps to reach the end: 1 -> 4 -> 5 
Hence end has been reached. 

 * @author rajeevkumar.pal
 *
 */
public class checkIfEndOfTheArrCanBeReached {

	public static void main(String[] args) {
		int[] arr = {10, 5, 3, 4, 3, 5, 6}; //{4, 1, 3, 2, 5};
		int S = 1 ;
		int n = arr.length;
		if(isReachedEnd(arr ,arr.length-1,S)) {
			System.out.println("true");
			
		}else {
			System.out.println("true");
		}
		 solve(arr, n, S);
	}

	private static boolean isReachedEnd(int[] arr , int n, int i) {
		// TODO Auto-generated method stub
		if(i>n|| n<i || i<0) return false;
		
		if(i==n) {
			return true;
		}
		
		if(isReachedEnd(arr , n, (i + arr[i])) || isReachedEnd(arr , n, (i-arr[i]))) {
			return true;
		}
		
		return false;
	}
	
	// Function to check if we can reach to
	// the end of the arr[] with possible moves
	static void solve(int arr[], int n, int start)
	{
	 
	    // Queue to perform BFS
	    Queue<Integer> q = new LinkedList<>();
	 
	    // Initially all nodes(index)
	    // are not visited.
	    boolean []visited = new boolean[n];
	 
	    // Initially the end of
	    // the array is not reached
	    boolean reached = false;
	 
	    // Push start index in queue
	    q.add(start);
	 
	    // Until queue becomes empty
	    while (!q.isEmpty())
	    {
	 
	        // Get the top element
	        int temp = q.peek();
	 
	        // Delete popped element
	        q.remove();
	 
	        // If the index is already
	        // visited. No need to
	        // traverse it again.
	        if (visited[temp] == true)
	            continue;
	 
	        // Mark temp as visited
	        // if not
	        visited[temp] = true;
	         
	        if (temp == n - 1)
	        {
	 
	            // If reached at the end
	            // of the array then break
	            reached = true;
	            break;
	        }
	 
	        // If temp + arr[temp] and
	        // temp - arr[temp] are in
	        // the index of array
	        if (temp + arr[temp] < n)
	        {
	            q.add(temp + arr[temp]);
	        }
	 
	        if (temp - arr[temp] >= 0)
	        {
	            q.add(temp - arr[temp]);
	        }
	    }
	 
	    // If reaches the end of the array,
	    // Print "Yes"
	    if (reached == true)
	    {
	        System.out.print("Yes");
	    }
	 
	    // Else print "No"
	    else
	    {
	        System.out.print("No");
	    }
	}
}
