package gfg.arr;

/**
 * Minimize cost to reach end of an array by two forward jumps or one backward jump in each move
 * Given an array arr[] consisting of N positive integers, the task is to find the minimum cost required to either cross the array or reach the end of the array by only moving to indices (i + 2) and (i – 1) from the ith index.

https://www.geeksforgeeks.org/minimize-cost-to-reach-end-of-an-array-by-two-forward-jumps-or-one-backward-jump-in-each-move/
Examples:

https://www.geeksforgeeks.org/check-if-the-end-of-the-array-can-be-reached-from-a-given-position/

Input: arr[] = {5, 1, 2, 10, 100}
Output: 18
Explanation:
Optimal cost path (0 based indexing): 0 → 2 → 1 → 3 → 5
Therefore, the minimum cost = 5 + 2 + 1 + 10 = 18.

 * @author rajeevkumar.pal
 *
 */
public class MinimumCostToReachEndOfTheArray {
..

	//Function to find the minimum cost
	// to reach the end of an array
	static void minCost(int arr[], int n)
	{
	   
	    // Base Case: When N < 3
	    if (n < 3) {
	        System.out.println(arr[0]);
	        return;
	    }
	
	    // Store the results in table
	    int dp[] = new int[n];
	
	    // Initialize base cases
	    dp[0] = arr[0];
	    dp[1] = dp[0] + arr[1] + arr[2];
	
	    // Iterate over the range[2, N - 2]
	    // to construct the dp array
	    for (int i = 2; i < n - 1; i++)
	        dp[i] = Math.min(dp[i - 2] + arr[i],
	                       dp[i - 1] + arr[i] + arr[i + 1]);
	
	    // Handle case for the last index, i.e. N - 1
	    dp[n - 1] = Math.min(dp[n - 2], dp[n - 3] + arr[n - 1]);
	
	    // Print the answer
	    System.out.println(dp[n - 1]);
	}
	
	// Driver Code
	public static void main(String[] args)
	{
	    int arr[] = { 9, 4, 6, 8, 5 };
	    int N = arr.length;
	    minCost(arr, N);
	}
}
