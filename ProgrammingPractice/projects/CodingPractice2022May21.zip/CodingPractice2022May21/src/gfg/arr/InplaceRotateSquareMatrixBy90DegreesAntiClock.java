package gfg.arr;

import java.util.Arrays;

public class InplaceRotateSquareMatrixBy90DegreesAntiClock {

	public static void main(String[] args)
    {
        int[][] mat =
        {
            { 1, 2, 3, 4 },
            { 5, 6, 7, 8 },
            { 9, 10, 11, 12 },
            { 13, 14, 15, 16 }
        };
 
        for (int[] r: mat) {
            System.out.println(Arrays.toString(r));
        }
        System.out.println("---after rotate ------");
        rotate(mat);
 
        for (int[] r: mat) {
            System.out.println(Arrays.toString(r));
        }
    }

	private static void rotate(int[][] mat) {
		// TODO Auto-generated method stub
		int m=mat.length -1;
		int n = mat[0].length-1 ;
		
		for(int i=0;i<=n/2;i++) {
			
			for(int j=0;j<=m;j++) {
				int temp = mat[j][i];
				mat[j][i] = mat[j][n-i] ;
				mat[j][n-i] = temp;
			}
		}
		
		
		for (int[] r: mat) {
            System.out.println(Arrays.toString(r));
        }
		
		System.out.println();
		for (int i = 0; i <= n; i++)
        {
            for (int j = 0; j < i; j++)
            {
                int temp = mat[i][j];
                mat[i][j] = mat[j][i];
                mat[j][i] = temp;
            }
        }
		
		
	}
}
