package gfg.arr;

/**
 * Count of subarrays whose maximum element is greater than k
 * Input : arr[] = {1, 2, 3} and k = 2.
Output : 3
All the possible subarrays of arr[] are 
{ 1 }, { 2 }, { 3 }, { 1, 2 }, { 2, 3 }, 
{ 1, 2, 3 }.
Their maximum elements are 1, 2, 3, 2, 3, 3.
There are only 3 sub arrays whose maximum elements > 2.
 * @author rajeevkumar.pal
 *
 */
public class CountSubArraysWhoseMaxElemGtrThenK {

	 // Driver code
    public static void main(String[] args){
 
        int arr[] = { 1, 2, 3 };
        int k = 2;
        int n = arr.length;
        System.out.print(countSubarray(arr, n, k));
        
    }

	private static int countSubarray(int[] arr, int n, int k) {
		// TODO Auto-generated method stub
		
		int countLessK = 0;
		
		for(int i=0;i<n;i++) {
			if(arr[i]<=k) {
				countLessK++ ;
			}
		}
		
		int subset1 = countLessK*(countLessK+1)/2;
		int subset2 = n*(n+1)/2;
		
		
		return (subset2 -subset1);
	}

}
