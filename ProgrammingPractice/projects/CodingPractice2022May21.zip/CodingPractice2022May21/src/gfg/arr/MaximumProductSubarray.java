package gfg.arr;

/**
 * https://www.geeksforgeeks.org/maximum-product-subarray/
 * Maximum Product Subarray
 * Given an array that contains both positive and negative integers, find the product of the maximum product subarray. Expected Time complexity is O(n) and only O(1) extra space can be used.

Examples:

Input: arr[] = {6, -3, -10, 0, 2}
Output:   180  // The subarray is {6, -3, -10}
 * @author rajeevkumar.pal
 *
 */
public class MaximumProductSubarray {

	
	// Driver Code
    public static void main(String[] args)
    {
        int arr[] = { 1, -2, -3, 0, 7, -8, -2 };
        System.out.println("Maximum Sub array product is "
                           + maxSubarrayProduct(arr));
        
        System.out.println("Maximum Sub array product is "
                +  maxSubarrayProduct(arr, arr.length));
        //int[] arr = { 1, -2, -3, 0, 7, -8, -2 };
        //int n = arr.length;
        //System.out.printf("Maximum Sub array product is %d",maxSubarrayProduct(arr, n));
    }

	private static int maxSubarrayProduct(int[] arr) {
		// TODO Auto-generated method stub
		int maxxprod=Integer.MIN_VALUE;
		
		for(int i=0;i<arr.length;i++) {
			int currProd=arr[i];
			for(int j=i+1;j<arr.length;j++) {
				
				currProd *=arr[j];
				if(maxxprod < currProd) {
					maxxprod = currProd;
				}
			}
		}
		return maxxprod;
	}
	
	/*
	 * Efficient Solution:
		The following solution assumes that the given input array always has a positive output. The solution works for all cases mentioned above. 
		It doesn’t work for arrays like {0, 0, -20, 0}, {0, 0, 0}.. etc. The solution can be easily modified to handle this case. 
		It is similar to Largest Sum Contiguous Subarray problem. The only thing to note here is, maximum product can also be obtained by 
		minimum (negative) product ending with the previous element multiplied by this element. For example, in array {12, 2, -3, -5, -6, -2}, 
		when we are at element -2, the maximum product is multiplication of, minimum product ending with -6 and -2. 
	 */
	
	// Utility functions to get
    // minimum of two integers
    static int min(int x, int y) {
      return x < y ? x : y;
    }
 
    // Utility functions to get
    // maximum of two integers
    static int max(int x, int y) {
      return x > y ? x : y;
    }
 
    /* Returns the product of
    max product subarray.
    Assumes that the given
    array always has a subarray
    with product more than 1
    
    Modified kadane algo
     *
     */
    static int maxSubarrayProduct1(int arr[])
    {
        int n = arr.length;
        // max positive product
        // ending at the current
        // position
        int max_ending_here = 1;
 
        // min negative product
        // ending at the current
        // position
        int min_ending_here = 1;
 
        // Initialize overall max product
        int max_so_far = 0;
        int flag = 0;
 
        /* Traverse through the array. Following
        values are maintained after the ith iteration:
        max_ending_here is always 1 or some positive product
                        ending with arr[i]
        min_ending_here is always 1 or some negative product
                        ending with arr[i] */
        for (int i = 0; i < n; i++)
        {
            /* If this element is positive, update
               max_ending_here. Update min_ending_here only
               if min_ending_here is negative */
            if (arr[i] > 0)
            {
                max_ending_here = max_ending_here * arr[i];
                min_ending_here
                    = min(min_ending_here * arr[i], 1);
                flag = 1;
            }
 
            /* If this element is 0, then the maximum
            product cannot end here, make both
            max_ending_here and min_ending _here 0
            Assumption: Output is alway greater than or
            equal to 1. */
            else if (arr[i] == 0)
            {
                max_ending_here = 1;
                min_ending_here = 1;
            }
 
            /* If element is negative. This is tricky
            max_ending_here can either be 1 or positive.
            min_ending_here can either be 1 or negative.
            next min_ending_here will always be prev.
            max_ending_here * arr[i]
            next max_ending_here will be 1 if prev
            min_ending_here is 1, otherwise
            next max_ending_here will be
                        prev min_ending_here * arr[i] */
            else {
                int temp = max_ending_here;
                max_ending_here
                    = max(min_ending_here * arr[i], 1);
                min_ending_here = temp * arr[i];
            }
 
            // update max_so_far, if needed
            if (max_so_far < max_ending_here)
                max_so_far = max_ending_here;
        }
 
        if (flag == 0 && max_so_far == 0)
            return 0;
        return max_so_far;
    }
    
    
 // Java program to find Maximum Product Subarray
    
    // Returns the product
    // of max product subarray.
    static int maxSubarrayProduct(int arr[],int n){
   
      // max positive product
      // ending at the current position
      int max_ending_here = arr[0];
   
      // min negative product ending
      // at the current position
      int min_ending_here = arr[0];
   
      // Initialize overall max product
      int max_so_far = arr[0];
   
      // /* Traverse through the array.
      // the maximum product subarray ending at an index
      // will be the maximum of the element itself,
      // the product of element and max product ending previously
      // and the min product ending previously. */
      for(int i=1;i<n;i++){
        int temp = Math.max(Math.max(arr[i], arr[i] * max_ending_here), arr[i] * min_ending_here);
        
        min_ending_here = Math.min(Math.min(arr[i], arr[i] * max_ending_here), arr[i] * min_ending_here);
        max_ending_here = temp;
        max_so_far = Math.max(max_so_far, max_ending_here);
      }
   
      return max_so_far;
    } 
    
    
    //Maximum product of a triplet
    
    
   
}
