package gfg.arr;

/**
 * Print all sequences of given length
 * https://www.geeksforgeeks.org/print-all-sequences-of-given-length/
 * 
 * @author rajeevkumar.pal
 *
 */
public class PrintAllSequencesOfGivenLength {

	/* A utility function that prints a given arr[] of length size*/
	static void printArray(int arr[], int size)
	{
	    for(int i = 0; i < size; i++)
	        System.out.print(arr[i] + " ");
	System.out.println();
	    return;
	}
	 
	
	/* A function that uses printSequencesRecur() to prints all sequences
	from 1, 1, ..1 to n, n, ..n */
	static void printSequences(int n, int k)
	{
	    int arr[] = new int[k];
	    printSequencesRecur(arr, n, k, 0);
	 
	return ;
	}
	/* The core function that recursively generates and prints all sequences of
	length k */
	static void printSequencesRecur(int arr[], int n, int k, int index)
	{
	int i;
	if (k == 0)
	{
	    printArray(arr, index);
	}
	if (k > 0)
	{
	    for(i = 1; i<=n; ++i)
	    {
	        arr[index] = i;
	        printSequencesRecur(arr, n, k-1, index+1);
	    }
	}
	}
	 
	 
	/* The core function that generates and prints all sequences of length k */
	static void printSeqRecur(int num, int pos, int k, int n)
	{
	    if (pos == k) {
	        System.out.print(num + " ");
	        return;
	    }
	    for (int i = 1; i <= n; i++) {
	        printSeqRecur(num * 10 + i, pos + 1, k, n);
	    }
	}
	 
	/* A function that uses printSequencesRecur() to prints all sequences
	from 1, 1, ..1 to n, n, ..n */
	static void printSequences1(int n, int k)
	{
	    printSeqRecur(0, 0, k, n);
	}
	
	
	/* Driver Program to test above functions */
	public static void main(String[] args)
	{
	    int n = 3;
	    int k = 2;
	    printSequences1(n, k);
	}
	
}
