package gfg.arr;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
/**
 * 
 * Find whether an array is subset of another array
 * https://www.geeksforgeeks.org/find-whether-an-array-is-subset-of-another-array-set-1/
 * 
 * @author rajeevkumar.pal
 *
 */
public class FindWhetherAnArrayIsSubsetOfAnotherArray {
	
	// Driver Code
	public static void main(String[] args)
	{
		int arr1[] = { 11, 1, 13, 21, 3, 7 };
		int arr2[] = { 11, 3, 7, 1 };

		int m = arr1.length;
		int n = arr2.length;
		if (isSubset(arr1, arr2, m, n))
			System.out.println("arr2 is a subset of arr1");
		else
			System.out.println("arr2 is not a subset of arr1");
	}
		
	/* Return true if arr2[] is a subset of arr1[] */
	static boolean isSubset(int arr1[],
							int arr2[], int m,
							int n)
	{
		int i = 0, j = 0;

		if (m < n)
			return false;

		Arrays.sort(arr1); // sorts arr1
		Arrays.sort(arr2); // sorts arr2

		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		
		while (i < n && j < m) {
			if (arr1[j] < arr2[i])
				j++;
			else if (arr1[j] == arr2[i]) {
				j++;
				i++;
			}
			else if (arr1[j] > arr2[i])
				return false;
		}

		if (i < n)
			return false;
		else
			return true;
	}
	
	/* Return true if arr2[] is a subset of arr1[] */
    static boolean isSubset2(int arr1[],
                            int arr2[], int m,
                            int n)
    {
        HashSet<Integer> hset = new HashSet<>();
 
        // hset stores all the values of arr1
        for (int i = 0; i < m; i++) {
            if (!hset.contains(arr1[i]))
                hset.add(arr1[i]);
        }
 
        // loop to check if all elements
        //  of arr2 also lies in arr1
        for (int i = 0; i < n; i++)
        {
            if (!hset.contains(arr2[i]))
                return false;
        }
        return true;
    }
    
    public static void isSubset3 ()
    {
   
      int arr1[] = { 11, 1, 13, 21, 3, 7 };
      int arr2[] = { 11, 3, 7, 1 };
      int m=arr1.length;
      int n=arr2.length;
   
      Set<Integer> s = new HashSet<Integer>();
      for (int i = 0; i < m; i++)
      {
        s.add(arr1[i]);
      }
      int p = s.size();
      for (int i = 0; i < n; i++)
      {
        s.add(arr2[i]);
      }
   
      if (s.size() == p)
      {
        System.out.println("arr2[] is subset of arr1[] " + "\n");
      }
      else
      {
        System.out.println("arr2[] is not subset of arr1[] " + "\n" );
      }
    }

}