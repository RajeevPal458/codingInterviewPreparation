package gfg.arr;

import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Given an integer array nums, return the length of the longest strictly increasing subsequence.
A subsequence is a sequence that can be derived from an array by deleting some or no elements without changing the order of the remaining elements. 
For example, [3,6,2,7] is a subsequence of the array [0,3,1,6,2,2,7].
 * @author rajeevkumar.pal
 *https://www.geeksforgeeks.org/longest-increasing-subsequence-dp-3/
 *https://www.youtube.com/watch?v=S9oUiVYEq7E
 *
 *https://www.geeksforgeeks.org/longest-increasing-subsequence-dp-3/#:~:text=The%20Longest%20Increasing%20Subsequence%20(LIS)%20problem%20is%20to%20find%20the,50%2C%2060%2C%2080%7D.
 *
 */
public class LongestIncreasingSubsequence {
..
	static int[][] dp;
	static int[][] pointer;
	static final int s1=1,s2=2;
	
	/* lis() returns the length of the longest
    increasing subsequence in arr[] of size n */
    static int lis1(int arr[], int n)
    {
        SortedSet<Integer> hs = new TreeSet<Integer>();
        // Storing and Sorting unique elements.
        for (int i = 0; i < n; i++)
            hs.add(arr[i]);
        int lis[] = new int[hs.size()];
        int k = 0;
        // Storing all the unique values in a sorted manner.
        for (int val : hs) {
            lis[k] = val;
            k++;
        }
        int m = k, i, j;
        int dp[][] = new int[m + 1][n + 1];
 
        // Storing -1 in dp multidimensional array.
        for (i = 0; i < m + 1; i++) {
            for (j = 0; j < n + 1; j++) {
                dp[i][j] = -1;
            }
        }
 
        // Finding the Longest Common Subsequence of the two
        // arrays
        for (i = 0; i < m + 1; i++) {
            for (j = 0; j < n + 1; j++) {
                if (i == 0 || j == 0) {
                    dp[i][j] = 0;
                }
                else if (arr[j - 1] == lis[i - 1]) {
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                }
                else {
                    dp[i][j]
                        = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        return dp[m][n];
    }
    
	public static void longestsubSequence(int[] arr , int n){
		
		int[] col=arr;
		
		int[] row = new int[n];
		for(int i=0;i< n;i++) {
			row[i] = col[i];
		}
		Arrays.sort(row);
		
		System.out.println(Arrays.toString(row));
		System.out.println(Arrays.toString(col));
		int clen=n;
		int rlen=n;
		
		
		// now find longest common subsequence array between row arr and col arr 
		
		dp=new int[rlen][clen];
		pointer=new int[rlen][clen];
		dp[0][0]=0;
		//pointer[0][0]=-1;
		
		System.out.println();
		for(int i=0;i<rlen;i++){
			for(int j=0;j<clen;j++){
				if(row[i]==col[j]){
					
					if(i==0&&j==0)
						dp[i][j]=1;
					else
						if(i>0&&j>0)
							dp[i][j]=dp[i-1][j-1]+1;
					pointer[i][j]=s1/s2;
				}
				else{
					if(i>0&&j>0){
						if(dp[i][j-1]>dp[i-1][j]){
							dp[i][j]=dp[i][j-1];
							pointer[i][j]=s1;
						}
						else{
							dp[i][j]=dp[i-1][j];
							pointer[i][j]=s2;
						}
					}
					if((i==0)&&(j>0)){
						dp[i][j]=dp[i][j-1];
						pointer[i][j]=s1;
					}
					else if((j==0)&&(i>0)){
						dp[i][j]=dp[i-1][j];
						pointer[i][j]=s2;
					}	
				}
			}
		}
		
		int i=rlen-1;
		int j=clen-1;
		String sb="";
		while(i>=0&&j>=0){
			switch(pointer[i][j]){
			
				case s1/s2:sb =col[j]+" "+sb;
							i--;j--;break;
				case s1: j--;break;
				
				case s2: i--;break;
			}
		}
		//for(int p=sb.length()-1;i>=0;i--)
		System.out.println(sb);
		
	}
	
	static int CeilIndex(int temp[], int l, int r, int key)
    {
        while(l<=r){
        	
        	int mid=l+(r-l)/2;
        	if(temp[mid]<key)
        		l=mid+1;
        	else if(temp[mid]>key)
        		r=mid;
        	if(l==r)
        		return l;
        }
        return r;
    }
	static int LongestIncreasingSubsequenceLength(int A[], int length)
    {
       return 0;
    }
	
 //{3,4,-1,5,8,2,3,12,7,9,10};
	private static void lis(int[] arr, int length) {
		
		int temp[]=new int[length];
		int end=0;
		temp[end]=0;
		for(int i=1;i<length;i++){
			
			if(arr[temp[end]]<arr[i])
			{
				temp[++end]=i;
			}
			else{
				int j=0;
				while(j<=end&&arr[i]>arr[temp[j]]) j++;
					
				temp[j]=i;
			}
		}
		for(int i=0;i<=end;i++)
			System.out.print(arr[temp[i]]+" ");
		
		System.out.println();
		System.out.println("length of longest increasing sub sequence:"+(end+1));
	}
	
	 /* lis() returns the length of the longest
    increasing subsequence in arr[] of size n */
	 static void lisubsequence(int arr[], int n){
	     int lis[] = new int[n];
	     int i, j, max = 0;
	
	     /* Initialize LIS values for all indexes */
	     for (i = 0; i < n; i++)
	         lis[i] = 1;
	
	     /* Compute optimized LIS values in
	        bottom up manner */
	     for (i = 1; i < n; i++)
	         for (j = 0; j < i; j++)
	             if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
	                 lis[i] = lis[j] + 1;
	
	     /* Pick maximum of all LIS values */
	     for (i = 0; i < n; i++)
	         if (max < lis[i])
	             max = lis[i];
	
	     System.out.println("length of longest increasing sub sequence:"+max);
	     
	 }
	
	public static void main(String[] args) {
		int[] arr={3,4,-1,5,8,2};
		int[] arr2={3,4,-1,5,8,2,3,12,7,9,10};
		int n = arr.length;
		//lis(arr,n);
		
		//lisubsequence(arr, n);
		
		LongestIncreasingSubsequenceLength(arr, n);
		
		longestsubSequence(arr2, n);
		
		
	}
}
