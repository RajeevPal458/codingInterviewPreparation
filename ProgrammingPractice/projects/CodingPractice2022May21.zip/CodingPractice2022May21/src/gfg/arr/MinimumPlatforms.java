package gfg.arr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Given arrival and departure times of all trains that reach a railway station. Find the minimum number of platforms required for the railway station so that no train is kept waiting.
Consider that all the trains arrive on the same day and leave on the same day. Arrival and departure time can never be the same for a train but we can have arrival time of one train equal to departure time of the other. At any given instance of time, same platform can not be used for both departure of a train and arrival of another train. In such cases, we need different platforms.


Example 1:

Input: n = 6 
arr[] = {0900, 0940, 0950, 1100, 1500, 1800}
dep[] = {0910, 1200, 1120, 1130, 1900, 2000}
Output: 3
Explanation: 
Minimum 3 platforms are required to 
safely arrive and depart all trains.



// C++ program to implement the above approach
#include <bits/stdc++.h>
using namespace std;

// Function to find the minimum number
// of platforms required
int findPlatform(int arr[], int dep[], int n)
{
	// Store the arrival and departure time
	vector<pair<int, int> > arr2(n);

	for (int i = 0; i < n; i++) {
		arr2[i] = { arr[i], dep[i] };
	}

	// Sort arr2 based on arival time
	sort(arr2.begin(), arr2.end());

	priority_queue<int, vector<int>, greater<int> > p;
	int count = 1;
	p.push(arr2[0].second);

	for (int i = 1; i < n; i++) {

		// Check if arrival time of current train
		// is less than or equals to depature time
		// of previous train
		if (p.top() >= arr2[i].first) {
			count++;
		}
		else {
			p.pop();
		}
		p.push(arr2[i].second);
	}

	// Return the number of train required
	return count;
}

// Driver Code
int main()
{
	int arr[] = { 900, 940, 950, 1100, 1500, 1800 };
	int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
	int n = sizeof(arr) / sizeof(arr[0]);
	cout << findPlatform(arr, dep, n);
	return 0;
}
-
 * @author rajeevkumar.pal
 *
 */
public class MinimumPlatforms{
	static class Train implements Comparable<Train>{
		int arr;
		int dep;
		public Train(int arrival, int dep) {
			super();
			this.arr = arrival;
			this.dep = dep;
		}
		@Override
		public String toString() {
			return "Train [arrival=" + arr + ", dep=" + dep + "]";
		}
		@Override
		public int compareTo(Train obj) {
			// TODO Auto-generated method stub
			if(this.dep> obj.dep)
				return 1;
			else if(this.dep < obj.dep)
				return -1;
			return 0;
		}
		
	}
	
	public static void main(String[] args) {
		
		List<Train> list = new ArrayList<MinimumPlatforms.Train>();
		int arr[] = {900, 940, 950, 1100, 1500, 1800};
		int dep[] = {910, 1200, 1120, 1130, 1900, 2000};
		
		System.out.println("  -------ans ---- "+findPlatform(arr, dep, arr.length));;
//		
//		int n = arr.length;
//		for(int i=0;i<n;i++) {
//			list.add(new Train(arr[i], dep[i]));
//		}
//		
//		Collections.sort(list);
//		System.out.println(list);
//		
//		int count =1;
//		Train train= list.get(0);
//		int predep =train.dep;
//		
//		List<Integer> deparr = new ArrayList<Integer>();
//		
//		for(int i=1 ;i<list.size();i++) {
//			train= list.get(i);
//			if(train.arr > predep) {
//				predep = train.dep;
//				continue;
//			}else {
//				int ind=-1;
//				for(int j=0;j<deparr.size();i++) {
//					if(deparr.get(j)<train.arr) {
//						predep = train.dep;
//						ind =j;
//					}
//				}
//				if(ind!=-1) {
//					deparr.remove(ind);
//					continue;
//				}
//				
//				deparr.add(train.dep);
//				count++;
//				predep = train.dep;
//			}
//			
//		}
//		// solution need  to be corrected 
		System.out.println("Required plateform:-");
		
	}
	
	static class Pair<A,D> implements Comparable<Pair<A,D>>{
		
		A arr;
		D dip;
		
		public Pair(A arr, D dip) {
			super();
			this.arr = arr;
			this.dip = dip;
		}

		@Override
		public int compareTo(Pair<A, D> o) {
			// TODO Auto-generated method stub
			if((int)this.arr > (int)o.arr) return +1;
			else if((int)this.arr < (int)o.arr) return -1;
			else return 0;
		}

		@Override
		public String toString() {
			return "Pair [arr=" + arr + ", dip=" + dip + "]";
		}
		
		
		
	}
	public static int findPlatform(int arr[], int dep[], int n)
	{
		// Store the arrival and departure time
		List<Pair<Integer, Integer> > arr2 = new ArrayList<MinimumPlatforms.Pair<Integer,Integer>>();

		for (int i = 0; i < n; i++) {
			arr2.add(new Pair<>( arr[i], dep[i] ));
		}

		// Sort arr2 based on arival time
		Collections.sort(arr2);

		PriorityQueue<Integer> p = new PriorityQueue<Integer>();
		int count = 1;
		p.add(arr2.get(0).dip);

		for (int i = 1; i < n; i++) {

			// Check if arrival time of current train
			// is less than or equals to depature time
			// of previous train
			if (p.peek() >= arr2.get(i).arr) {
				count++;
			}
			else {
				p.remove();
			}
			p.add(arr2.get(i).dip);
		}

		// Return the number of train required
		return count;
	}
	
	
}
