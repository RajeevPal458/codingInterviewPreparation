import java.util.ArrayList;
import java.util.List;

public class TesterMain {
	private static List<List<Integer>> allsubset =null;
	 // Driver code
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,2,1,3,2,3};
		int k=3;
		findAllSubArrayOfSizeK(arr,k);
	}

	private static void findAllSubArrayOfSizeK(int[] arr, int k) {
		int n = arr.length;
		allsubset = new ArrayList<>();
		
		subsetUtill(arr, n, new ArrayList<Integer>(), 0, k);
		
		for(List<Integer> subset:allsubset) {
			System.out.println(subset);
		}
		
	}

	

	private static void subsetUtill(int[] arr , int n,List<Integer> currsubset,int index,int k) {
		
		if(currsubset.size() == k) {
			allsubset.add(currsubset);
			return;
		}
		
		if(index>=n) return;
		
		subsetUtill(arr, n, new ArrayList<Integer>(currsubset), index+1, k);
		
		List<Integer> list = new ArrayList<Integer>(currsubset);
		list.add(arr[index]);
		
		subsetUtill(arr, n, list, index+1, k);
		
		
	}
}
