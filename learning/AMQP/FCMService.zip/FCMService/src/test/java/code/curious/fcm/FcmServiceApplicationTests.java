package code.curious.fcm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
