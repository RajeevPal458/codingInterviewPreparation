package org.spring.security.oauth2.SpringSecurityOAuth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOAuth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
