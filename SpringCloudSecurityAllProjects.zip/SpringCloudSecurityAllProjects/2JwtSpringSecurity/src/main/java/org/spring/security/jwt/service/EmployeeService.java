package org.spring.security.jwt.service;

import java.util.List;

import org.spring.security.jwt.model.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployees();

}
