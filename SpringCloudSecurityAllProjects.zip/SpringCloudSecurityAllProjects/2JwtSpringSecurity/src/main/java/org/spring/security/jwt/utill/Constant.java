package org.spring.security.jwt.utill;

public interface Constant {
	
	public static final String EMPLOYEE_SERVICE_RESOURCE ="employeeService";
	public static final String USER_DETAILS_SERVICE_RESOURCE ="userDetailsService";
	
}
